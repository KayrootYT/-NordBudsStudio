package com.kayroot.nordbudsstudio;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_BLUETOOTH = 400;
    private static final UUID BATTERY_SERVICE = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb");
    private static final UUID BATTERY_LEVEL = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scanning = false;
    private TextView statusPill, deviceName, deviceSub, leftBattery, rightBattery, caseBattery, hardwareStatus, presetStatus;
    private Button scanButton, disconnectButton, bassButton, balancedButton, vocalButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        View root = findViewById(R.id.root);
        root.setAlpha(0f); root.setTranslationY(18f);
        root.animate().alpha(1f).translationY(0f).setDuration(650).setInterpolator(new DecelerateInterpolator()).start();
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = manager == null ? null : manager.getAdapter();
        if (bluetoothAdapter == null) {
            hardwareStatus.setText("Bluetooth is not available on this device.");
            scanButton.setEnabled(false);
        }
        scanButton.setOnClickListener(v -> requestPermissionsThenScan());
        disconnectButton.setOnClickListener(v -> disconnect());
        bassButton.setOnClickListener(v -> selectPreview("Bass+"));
        balancedButton.setOnClickListener(v -> selectPreview("Balanced"));
        vocalButton.setOnClickListener(v -> selectPreview("Vocal"));
    }

    private void bindViews() {
        statusPill=findViewById(R.id.statusPill); deviceName=findViewById(R.id.deviceName);
        deviceSub=findViewById(R.id.deviceSub); leftBattery=findViewById(R.id.leftBattery);
        rightBattery=findViewById(R.id.rightBattery); caseBattery=findViewById(R.id.caseBattery);
        hardwareStatus=findViewById(R.id.hardwareStatus); presetStatus=findViewById(R.id.presetStatus);
        scanButton=findViewById(R.id.scanButton); disconnectButton=findViewById(R.id.disconnectButton);
        bassButton=findViewById(R.id.bassButton); balancedButton=findViewById(R.id.balancedButton);
        vocalButton=findViewById(R.id.vocalButton);
    }

    private boolean hasBluetoothPermissions() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED &&
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED);
    }

    private void requestPermissionsThenScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasBluetoothPermissions()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLUETOOTH);
        } else startScan();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) granted = false;
            if (granted) startScan();
            else { hardwareStatus.setText("Nearby devices permission denied. Allow it and retry."); toast("Nearby devices permission is required."); }
        }
    }

    private void startScan() {
        if (bluetoothAdapter == null) return;
        try {
            if (!bluetoothAdapter.isEnabled()) { hardwareStatus.setText("Turn Bluetooth on in Android settings, then retry."); toast("Please turn Bluetooth on."); return; }
            scanner = bluetoothAdapter.getBluetoothLeScanner();
            if (scanner == null) { hardwareStatus.setText("BLE scanner unavailable. Check Bluetooth and retry."); return; }
            scanning = true; scanButton.setEnabled(false);
            hardwareStatus.setText("Scanning BLE devices for 12 seconds. Put earbuds in pairing mode.");
            scanner.startScan(scanCallback);
            handler.postDelayed(() -> {
                if (scanning) { stopScan(); hardwareStatus.setText("Scan finished. If earbuds were not found, put them in pairing mode and retry."); }
            }, 12000);
        } catch (SecurityException e) {
            hardwareStatus.setText("Bluetooth permission missing. Allow Nearby devices and retry."); scanButton.setEnabled(true);
        } catch (Exception e) {
            hardwareStatus.setText("Could not start BLE scan: " + e.getClass().getSimpleName()); scanButton.setEnabled(true);
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String name = null;
            try { name = device.getName(); if (name == null && result.getScanRecord()!=null) name=result.getScanRecord().getDeviceName(); }
            catch (SecurityException ignored) { }
            if (name == null) name = "Unknown BLE device";
            final String foundName=name; final BluetoothDevice foundDevice=device;
            if (foundName.toLowerCase(Locale.ROOT).contains("nord buds 3") || foundName.toLowerCase(Locale.ROOT).contains("oneplus")) {
                stopScan();
                runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
                    .setTitle("Bluetooth device found").setMessage(foundName + "\n\nConnect to this device?")
                    .setNegativeButton("Cancel", (d,w)->{}).setPositiveButton("Connect",(d,w)->connect(foundDevice,foundName)).show());
            }
        }
        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> { stopScan(); hardwareStatus.setText("BLE scan failed (code " + errorCode + ")."); });
        }
    };

    private void stopScan() {
        try { if (scanner!=null && scanning && hasBluetoothPermissions()) scanner.stopScan(scanCallback); }
        catch (Exception ignored) { }
        scanning=false;
        runOnUiThread(() -> scanButton.setEnabled(true));
    }

    private void connect(BluetoothDevice device, String name) {
        try {
            if (gatt!=null) { gatt.close(); gatt=null; }
            deviceName.setText(name); deviceSub.setText("Connecting over BLE…");
            hardwareStatus.setText("Connecting and discovering standard GATT services…");
            gatt = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? device.connectGatt(this,false,gattCallback,BluetoothDevice.TRANSPORT_LE)
                : device.connectGatt(this,false,gattCallback);
        } catch (SecurityException e) { hardwareStatus.setText("Bluetooth connect permission is required."); }
        catch (Exception e) { hardwareStatus.setText("Connection failed: " + e.getClass().getSimpleName()); }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt bluetoothGatt,int status,int newState) {
            runOnUiThread(() -> {
                if (newState==android.bluetooth.BluetoothProfile.STATE_CONNECTED && status==BluetoothGatt.GATT_SUCCESS) {
                    statusPill.setText("●  BLE CONNECTED"); deviceSub.setText("BLE connected • checking services");
                    hardwareStatus.setText("Connected. Discovering GATT services; proprietary controls are not enabled.");
                    try { if (hasBluetoothPermissions()) bluetoothGatt.discoverServices(); }
                    catch (SecurityException e) { hardwareStatus.setText("Connected, but permission prevented service discovery."); }
                } else if (newState==android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                    statusPill.setText("●  NOT CONNECTED"); deviceSub.setText("Disconnected");
                    leftBattery.setText("—"); rightBattery.setText("—"); caseBattery.setText("Case battery: unavailable");
                    hardwareStatus.setText("Device disconnected (GATT status " + status + ").");
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt bluetoothGatt,int status) {
            if (status!=BluetoothGatt.GATT_SUCCESS) { runOnUiThread(() -> hardwareStatus.setText("GATT discovery failed (code " + status + ").")); return; }
            BluetoothGattService service=bluetoothGatt.getService(BATTERY_SERVICE);
            if (service==null) {
                runOnUiThread(() -> { hardwareStatus.setText("Standard Battery Service not exposed by this device."); caseBattery.setText("Case battery: not reported by standard BLE"); });
                return;
            }
            BluetoothGattCharacteristic level=service.getCharacteristic(BATTERY_LEVEL);
            if (level==null) { runOnUiThread(() -> hardwareStatus.setText("Battery Service found, but Battery Level characteristic is missing.")); return; }
            try { bluetoothGatt.readCharacteristic(level); }
            catch (SecurityException e) { runOnUiThread(() -> hardwareStatus.setText("Permission prevented battery reading.")); }
        }
        @Override public void onCharacteristicRead(BluetoothGatt bluetoothGatt,BluetoothGattCharacteristic characteristic,int status) {
            if (BATTERY_LEVEL.equals(characteristic.getUuid()) && status==BluetoothGatt.GATT_SUCCESS) {
                byte[] value=characteristic.getValue(); final int level=(value!=null && value.length>0)?value[0]&0xFF:-1;
                runOnUiThread(() -> {
                    if (level>=0 && level<=100) {
                        leftBattery.setText(level+"%"); rightBattery.setText(level+"%");
                        caseBattery.setText("Device-reported standard battery: "+level+"% (endpoint not identified)");
                        hardwareStatus.setText("Battery read succeeded. Standard BLE does not identify left/right/case separately.");
                    } else hardwareStatus.setText("Invalid battery characteristic value.");
                });
            }
        }
    };

    private void disconnect() {
        try { if (gatt!=null) { gatt.disconnect(); gatt.close(); gatt=null; } }
        catch (Exception ignored) { }
        statusPill.setText("●  NOT CONNECTED"); deviceSub.setText("Connect your earbuds to begin");
        leftBattery.setText("—"); rightBattery.setText("—");
        caseBattery.setText("Case battery: unavailable until reported by device");
        hardwareStatus.setText("Disconnected by user.");
    }

    private void selectPreview(String preset) {
        presetStatus.setText("Selected preview: "+preset+" • demo only");
        toast(preset+" preview selected. No earbud command sent.");
        View target=findViewById(R.id.presetStatus);
        target.setScaleX(0.96f); target.setScaleY(0.96f);
        target.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
    }

    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_SHORT).show(); }

    @Override protected void onDestroy() {
        stopScan();
        if (gatt!=null) { try { gatt.close(); } catch (Exception ignored) { } gatt=null; }
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
