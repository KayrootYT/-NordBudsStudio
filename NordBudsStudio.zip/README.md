# Nord Buds Studio

Native Android companion app starter for OnePlus Nord Buds 3. Java + XML, target SDK 35 (Android 16 compatibility), minimum SDK 26.

## Included
- Premium dark glass-inspired dashboard and entrance animation.
- Runtime Bluetooth permissions for Android 12+.
- BLE scanning, user-confirmed connection, GATT service discovery.
- Reads standard Bluetooth Battery Service if the device exposes it.
- Demo audio preset buttons are clearly labelled demo-only and do not send proprietary earbud commands.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Hardware limitations
ANC, Transparency, vendor EQ, touch remapping and case battery are not claimed to work. These require a verified protocol for this exact earbud model. Standard Battery Service, if exposed, may only report one endpoint and does not necessarily distinguish left/right/case.

## GitHub APK build
1. Upload the contents of this project to the repository (not the enclosing folder).
2. Keep `.github/workflows/android-apk.yml` at that exact path.
3. Open Actions and run **Build Nord Buds Studio APK**, or push to `main`/`master`.
4. Download the `NordBudsStudio-debug-apk` artifact from the successful run.

The workflow uses Ubuntu 22.04, JDK 17, Gradle 8.11.1 and Android SDK platform 35. No Gradle wrapper is required because Gradle is installed by the workflow.

## Local build
Open the project in Android Studio, allow Gradle sync, then run `assembleDebug`. The APK path is `app/build/outputs/apk/debug/app-debug.apk`.
