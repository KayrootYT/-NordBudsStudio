# Nord Buds Studio — Android (Java + XML)

Independent Android companion app experiment for OnePlus Nord Buds 3 / Nord Buds 3 Pro. Not affiliated with OnePlus.

## Implemented in this build
- Android BLE scan and device selection
- GATT connection and OPOv1 service/characteristic discovery
- OPO HELLO + REGISTER session initialization
- ANC on, ANC off, Transparency command sequence using write-without-response
- Battery query and parser for the published OPOv1 response layout
- EQ status query and response logging
- Notification subscription on available notify/indicate characteristics
- Android 12+ Bluetooth permissions and Android 16/API 36 target
- GitHub Actions debug APK workflow

## Important compatibility status
Public reverse-engineering documentation confirms this OPOv1 command sequence on Nord Buds 3 Pro and lists Nord Buds 3 as likely compatible, not confirmed. The authentication token and packet values are from that public reference. The exact firmware on this user's Nord Buds 3 (`110.110.100`) has not yet been tested. A command being sent is not proof that the buds accepted it; check the earbuds' actual mode and response status.

The app does **not** claim that every feature is implemented. Dual connection, Game Mode, Find My Earbuds sound, touch gesture remapping, EQ preset writing, and firmware update are not enabled as working controls because device-specific commands and safe behavior have not been verified. Firmware flashing is deliberately disabled to avoid bricking the earbuds.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 36) or run:

```bash
gradle --no-daemon clean assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions: push to `main`/`master`, or run **Actions → Android APK Build → Run workflow**. Download the `NordBudsStudio-debug-apk` artifact.

## First use
1. Pair the buds in Android Bluetooth settings.
2. Put both buds out of the case and keep them close to the phone.
3. Open Nord Buds Studio, grant Bluetooth permissions, scan and select the buds.
4. Wait for OPO service discovery/session initialization.
5. Test ANC / Off / Transparency and physically confirm the effect.
6. If commands are ignored, export an Android Bluetooth HCI snoop log from a session with the official HeyMelody app and compare the exact packets. Do not assume the Pro's token/commands work unchanged on every Nord Buds 3 firmware.

## Protocol reference
- https://github.com/AasheeshLikePanner/cracked-oneplus-buds
- https://aasheesh.vercel.app/blog/oneplus-buds

The reverse-engineering reference is MIT licensed; this app is an independent implementation. Review upstream licensing before redistributing protocol-derived code.
