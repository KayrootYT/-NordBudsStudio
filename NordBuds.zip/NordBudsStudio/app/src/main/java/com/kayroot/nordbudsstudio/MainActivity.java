package com.kayroot.nordbudsstudio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.*;

/** Native OPOv1 BLE client. Protocol values are based on publicly documented reverse engineering;
 * device-specific commands must still be verified on the user's exact firmware. */
public class MainActivity extends Activity {
    private static final int REQUEST_BLE = 42;
    private static final UUID OPO_SERVICE = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5");
    private static final UUID OPO_WRITE = UUID.fromString("0100079a-d102-11e1-9b23-00025b00a5a5");
    private static final UUID OPO_NOTIFY = UUID.fromString("0200079a-d102-11e1-9b23-00025b00a5a5");
    private static final UUID FE2C_SERVICE = UUID.fromString("fe2c123a-8366-4814-8eb0-01de32100bea");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final byte[] HELLO = hex("AA 07 00 00 00 01 23 00 00 12");
    private static final byte[] REGISTER = hex("AA 0C 00 00 00 85 41 05 00 00 B5 50 A0 69");

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic writeChar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private TextView statusText, batteryText;
    private Button scanButton;
    private boolean scanning, authenticated;
    private String connectedName = "Nord Buds";
    private int pendingMode = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        batteryText = findViewById(R.id.batteryText);
        scanButton = findViewById(R.id.scanButton);
        BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        scanButton.setOnClickListener(v -> beginScan());
        findViewById(R.id.ancButton).setOnClickListener(v -> setAnc(0x01, "ANC"));
        findViewById(R.id.offButton).setOnClickListener(v -> setAnc(0x04, "Off"));
        findViewById(R.id.transparencyButton).setOnClickListener(v -> setAnc(0x02, "Transparency"));
        findViewById(R.id.eqButton).setOnClickListener(v -> query(0x05, "EQ"));
        findViewById(R.id.dualButton).setOnClickListener(v -> unavailable("Dual connection", "Multipoint enable/disable command is not verified for this model. Pair the earbuds with the second device through Bluetooth settings."));
        findViewById(R.id.findButton).setOnClickListener(v -> unavailable("Find earbuds", "The OPO command for triggering the earbud speaker has not been verified. This button will not pretend that a sound was played."));
        findViewById(R.id.controlsButton).setOnClickListener(v -> unavailable("Touch controls", "Gesture remapping requires additional verified OPO commands. No settings have been changed."));
        findViewById(R.id.firmwareButton).setOnClickListener(v -> unavailable("Firmware update", "Firmware flashing is intentionally disabled until the exact signed firmware package, transfer protocol and recovery process are verified. Incorrect flashing can brick the earbuds."));
        findViewById(R.id.aboutButton).setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("About Nord Buds Studio").setMessage("Independent companion app. OPOv1 ANC commands and protocol queries are implemented from public reverse-engineering references. Exact Nord Buds 3 firmware compatibility must be tested on your earbuds.").setPositiveButton("OK", null).show());
        findViewById(R.id.deviceTab).setOnClickListener(v -> statusText.setText("Device dashboard • connect your earbuds to begin"));
        findViewById(R.id.controlsTab).setOnClickListener(v -> unavailable("Touch controls", "Gesture remapping is not yet verified for this model."));
        findViewById(R.id.aboutTab).setOnClickListener(v -> findViewById(R.id.aboutButton).performClick());
        Switch gameSwitch = findViewById(R.id.gameSwitch);
        gameSwitch.setOnCheckedChangeListener((b, checked) -> {
            gameSwitch.setChecked(false);
            unavailable("Game mode", "No verified OPO command is available to toggle the earbuds' Game Mode. The switch has been reset to avoid a false success state.");
        });
    }

    private void unavailable(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }
    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void beginScan() {
        if (adapter == null) { statusText.setText("This phone does not support Bluetooth LE."); return; }
        if (!hasPermissions()) {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BLE);
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_BLE);
            return;
        }
        if (!adapter.isEnabled()) { statusText.setText("Turn on Bluetooth, then scan again."); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { statusText.setText("BLE scanner unavailable."); return; }
        found.clear(); scanning = true; scanButton.setText("Scanning…"); statusText.setText("Scanning BLE devices for 12 seconds…");
        try { scanner.startScan(scanCallback); handler.postDelayed(this::stopScan, 12000); }
        catch (SecurityException e) { statusText.setText("Bluetooth permission denied."); scanning=false; }
    }
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult result) {
            BluetoothDevice d = result.getDevice(); if (d == null) return;
            String name = result.getScanRecord()!=null && result.getScanRecord().getDeviceName()!=null ? result.getScanRecord().getDeviceName() : safeName(d);
            String key = d.getAddress(); found.put(key, d);
            if (name.toLowerCase(Locale.ROOT).contains("oneplus") || name.toLowerCase(Locale.ROOT).contains("nord") || name.toLowerCase(Locale.ROOT).contains("buds")) {
                runOnUiThread(() -> statusText.setText("Found: " + name + " • scan finishing"));
            }
        }
        @Override public void onScanFailed(int code) { runOnUiThread(() -> { scanning=false; scanButton.setText("Scan"); statusText.setText("BLE scan failed: " + code); }); }
    };
    private String safeName(BluetoothDevice d) { try { return d.getName()==null ? "Unknown BLE device" : d.getName(); } catch (SecurityException e) { return "Bluetooth device"; } }
    private void stopScan() {
        if (!scanning) return;
        try { if (scanner != null && hasPermissions()) scanner.stopScan(scanCallback); } catch (SecurityException ignored) { }
        scanning=false; scanButton.setText("Choose device");
        if (found.isEmpty()) { statusText.setText("No BLE devices found. Ensure earbuds are out of the case and paired in Android Bluetooth settings."); return; }
        List<BluetoothDevice> devices = new ArrayList<>(found.values()); String[] labels = new String[devices.size()];
        for (int i=0;i<devices.size();i++) labels[i]=safeName(devices.get(i))+"  •  "+devices.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Select your earbuds").setItems(labels, (dialog, which) -> connect(devices.get(which))).setNegativeButton("Cancel", null).show();
    }
    private void connect(BluetoothDevice device) {
        try {
            if (gatt != null) { gatt.disconnect(); gatt.close(); }
            authenticated=false; writeChar=null; connectedName=safeName(device); statusText.setText("Connecting to "+connectedName+"…");
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) { statusText.setText("Bluetooth permission denied while connecting."); }
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) { runOnUiThread(() -> statusText.setText("Connected • discovering OPO protocol services…")); g.discoverServices(); }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) { authenticated=false; writeChar=null; runOnUiThread(() -> statusText.setText("Disconnected from earbuds. Tap Scan to reconnect.")); }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) { runOnUiThread(() -> statusText.setText("Service discovery failed: "+status)); return; }
            BluetoothGattService service = g.getService(OPO_SERVICE);
            if (service != null) {
                writeChar = service.getCharacteristic(OPO_WRITE);
                BluetoothGattCharacteristic notify = service.getCharacteristic(OPO_NOTIFY);
                if (notify != null) enableNotify(g, notify);
            }
            for (BluetoothGattService s : g.getServices()) for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                if ((c.getProperties() & (BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) enableNotify(g,c);
            }
            if (writeChar == null) { runOnUiThread(() -> statusText.setText("OPO command service 0000079A not found. This firmware may use a different protocol.")); return; }
            runOnUiThread(() -> statusText.setText("OPO service found • initializing command session…"));
            handler.postDelayed(() -> sendRaw(HELLO), 900);
            handler.postDelayed(() -> sendRaw(REGISTER), 2900);
            handler.postDelayed(() -> { authenticated=true; runOnUiThread(() -> statusText.setText("Connected to "+connectedName+" • protocol session initialized")); query(0x06,"Battery"); }, 4500);
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) { byte[] value=c.getValue(); if (value!=null) parseResponse(value); }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) { if(value!=null) parseResponse(value); }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) { byte[] value=c.getValue(); if(value!=null) parseResponse(value); }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) { }
    };
    private void enableNotify(BluetoothGatt g, BluetoothGattCharacteristic c) {
        try {
            g.setCharacteristicNotification(c,true); BluetoothGattDescriptor desc=c.getDescriptor(CCCD);
            if(desc!=null) { if(Build.VERSION.SDK_INT>=33) g.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); else { desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(desc); } }
        } catch (SecurityException ignored) { }
    }
    private void setAnc(int mode, String label) {
        if (gatt==null || writeChar==null || !authenticated) { statusText.setText("Connect to your earbuds first. ANC command not sent."); return; }
        pendingMode=mode; statusText.setText("Sending "+label+" command…");
        // Public OPOv1 sequence: handshake, registration, query, then mode set.
        sendRaw(HELLO);
        handler.postDelayed(() -> sendRaw(REGISTER), 1600);
        handler.postDelayed(() -> sendRaw(hex("AA 09 00 00 04 82 44 02 00 00 F2")), 3200);
        handler.postDelayed(() -> sendRaw(new byte[]{(byte)0xAA,0x0A,0,0,4,4,0x42,3,0,1,1,(byte)pendingMode}), 4700);
        handler.postDelayed(() -> { if (pendingMode==mode) statusText.setText("Command sent: "+label+" • confirm the mode on your earbuds; response parsing is shown below when available."); }, 5200);
    }
    private void query(int category, String name) {
        if (gatt==null || writeChar==null || !authenticated) { statusText.setText("Connect to earbuds first. "+name+" query not sent."); return; }
        sendRaw(HELLO);
        handler.postDelayed(() -> sendRaw(REGISTER), 1500);
        handler.postDelayed(() -> {
            byte[] packet;
            if(category==0x06) packet=hex("AA 07 00 00 06 01 25 00 00");
            else if(category==0x05) packet=hex("AA 07 00 00 05 01 2B 00 00");
            else packet=hex("AA 07 00 00 03 01 28 00 00");
            sendRaw(packet); runOnUiThread(() -> statusText.setText(name+" query sent • waiting for actual earbud response…"));
        }, 3000);
    }
    private void sendRaw(byte[] bytes) {
        BluetoothGatt g=gatt; BluetoothGattCharacteristic c=writeChar;
        if(g==null || c==null) return;
        try {
            if(Build.VERSION.SDK_INT>=33) g.writeCharacteristic(c, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            else { c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE); c.setValue(bytes); g.writeCharacteristic(c); }
        } catch (SecurityException ignored) { runOnUiThread(() -> statusText.setText("Bluetooth permission lost; command not sent.")); }
    }
    private void parseResponse(byte[] b) {
        if(b.length>=6 && (b[4]&255)==0x06 && (b[5]&255)==0x81) {
            String result="Battery response received";
            if(b.length>=16) result="Left bud: "+(b[12]&255)+"%   Right bud: "+(b[14]&255)+"%   Case: "+(b[15]&255)+"%";
            final String r=result; runOnUiThread(() -> { batteryText.setText(r); statusText.setText("Live response received from "+connectedName); });
        } else if(b.length>=7 && (b[4]&255)==0x05 && (b[5]&255)==0x02) {
            final int eq=b[6]&255; runOnUiThread(() -> statusText.setText("Earbud EQ response received • raw mode value: "+eq+" (mapping needs device-specific confirmation)"));
        } else if(b.length>=6 && (b[4]&255)==0x03 && (b[5]&255)==0x81) {
            runOnUiThread(() -> statusText.setText("Device-info response received from earbuds."));
        } else {
            StringBuilder hex=new StringBuilder(); for(byte x:b) hex.append(String.format(Locale.US,"%02X ",x));
            runOnUiThread(() -> statusText.setText("Earbud response: "+hex.toString().trim()));
        }
    }
    private static byte[] hex(String s) { String[] p=s.trim().split("\\s+"); byte[] out=new byte[p.length]; for(int i=0;i<p.length;i++) out[i]=(byte)Integer.parseInt(p[i],16); return out; }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) { super.onRequestPermissionsResult(requestCode,permissions,results); if(requestCode==REQUEST_BLE){ boolean ok=results.length>0; for(int r:results) ok &= r==PackageManager.PERMISSION_GRANTED; if(ok) beginScan(); else statusText.setText("Bluetooth permission is required."); } }
    @Override protected void onDestroy() { if(scanning) { try { if(scanner!=null && hasPermissions()) scanner.stopScan(scanCallback); } catch(Exception ignored){} } if(gatt!=null){ try{gatt.disconnect();gatt.close();}catch(Exception ignored){} } super.onDestroy(); }
}
