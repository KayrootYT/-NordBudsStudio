# Budsy — GitHub Actions build starter

This repository bundle builds the Android project stored in `Budsy.zip` and publishes `Budsy-debug-apk` as a GitHub Actions artifact.

## Setup
1. Create a new GitHub repository named `Budsy-Android` (or another available name).
2. Upload the contents of this folder to the repository root. Keep `.github/workflows/android.yml` at exactly that path and `Budsy.zip` at the root.
3. Open **Actions** and enable workflows if GitHub prompts you.
4. Push/commit the files to `main`, or open **Actions → Build and verify Budsy Android APK → Run workflow**.
5. Open the completed workflow run and download the `Budsy-debug-apk` artifact.

The workflow compiles the project; it does not prove that proprietary Bluetooth controls work on the physical earbuds. Device testing is still required.
