# Budsy (native Android)
Kotlin + Jetpack Compose app that talks to OnePlus Nord Buds 3 over Bluetooth RFCOMM using the protocol decoded from a HeyMelody capture.

1. Push everything to a GitHub repo (`main`). Keep `.github/workflows/build-apk.yml`.
2. Actions tab -> Build APK -> Run workflow. Download artifact `Budsy-apk` (contains app-debug.apk).
3. Pair buds in phone Bluetooth settings, force-stop HeyMelody, open the app, tap Connect.

Protocol and the guessed values are in `app/src/main/java/com/nordbuds/studio/Buds.kt`.
