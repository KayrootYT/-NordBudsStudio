# Nord Buds Studio (native Android)
Kotlin + Jetpack Compose app that talks to OnePlus Nord Buds 3 over Bluetooth RFCOMM using the protocol decoded from a HeyMelody capture.

Pages: Overview (battery, ANC, Game Mode, AI Clear Calls), Sound (presets, BassWave, 6-band Master EQ), Controls (ANC, touch gestures), Settings (connections, preferences, specs).
Badges: LIVE = sent to the buds, PREVIEW = saved in the app only.

1. Push everything to a GitHub repo (`main`). Keep `.github/workflows/build-apk.yml`.
2. Actions tab -> Build APK -> Run workflow. Download artifact `Budsy-apk`.
3. Pair buds in phone Bluetooth settings, force-stop HeyMelody, open the app, tap Connect.

Protocol and the guessed values are in `app/src/main/java/com/nordbuds/studio/Buds.kt`.
