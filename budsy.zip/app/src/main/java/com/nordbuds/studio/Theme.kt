package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val accent2: Color, val soft: Color,
    val green: Color, val amber: Color, val washA: Color, val washB: Color
)

val LightPal = Pal(
    false, Color(0xFFFBF7F5), Color.White, Color(0xFFF7F1EF), Color(0xFF1B1616), Color(0xFF6F6563),
    Color(0xFFF0E6E3), Color(0xFFE3D9D6), Color(0xFFE5432B), Color(0xFFF46F3E), Color(0xFFFCE9E4),
    Color(0xFF1FA86A), Color(0xFFE0A100), Color(0xFFFFD9CF), Color(0xFFCDEDEE)
)
val DarkPal = Pal(
    true, Color(0xFF121010), Color(0xFF1E1A1B), Color(0xFF2A2526), Color(0xFFF6EFED), Color(0xFFABA19E),
    Color(0xFF332D2E), Color(0xFF433B3C), Color(0xFFFF5B40), Color(0xFFFF8B4D), Color(0xFF3B221D),
    Color(0xFF3CCB8B), Color(0xFFF0B429), Color(0xFF3A1D18), Color(0xFF123035)
)

val LocalPal = staticCompositionLocalOf { LightPal }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) darkColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
