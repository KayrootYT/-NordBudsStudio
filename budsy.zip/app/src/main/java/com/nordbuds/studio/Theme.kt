package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color
)

val LightPal = Pal(
    false, Color(0xFFF2F3F7), Color.White, Color(0xFFF0F1F5), Color(0xFF111214), Color(0xFF86888F),
    Color(0xFFE8E9EE), Color(0xFFC9CBD2), Color(0xFF0A84FF), Color(0xFFE5F1FF), Color(0xFF1FA86A), Color(0xFFE0A100)
)
val DarkPal = Pal(
    true, Color(0xFF0E0F11), Color(0xFF1C1D20), Color(0xFF2A2B2F), Color(0xFFF2F3F5), Color(0xFF9A9CA3),
    Color(0xFF2C2D31), Color(0xFF4A4C52), Color(0xFF3395FF), Color(0xFF1A2E47), Color(0xFF3CCB8B), Color(0xFFF0B429)
)

val LocalPal = staticCompositionLocalOf { LightPal }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) darkColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
