package com.nordbuds.studio

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*

/** A boolean preference that survives app restarts. */
class Flag(private val sp: SharedPreferences, private val key: String, def: Boolean) {
    var on by mutableStateOf(sp.getBoolean(key, def))
        private set
    fun set(v: Boolean) { on = v; sp.edit().putBoolean(key, v).apply() }
}

/** UI-only settings (not sent to the buds yet). */
class Local(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nbs", Context.MODE_PRIVATE)
    val dark = Flag(sp, "dark", false)
    val gameMode = Flag(sp, "game", false)
    val aiClear = Flag(sp, "aiclear", true)
    val fastPair = Flag(sp, "fastpair", true)
    val dual = Flag(sp, "dual", true)
    val notify = Flag(sp, "notify", true)

    var bass by mutableIntStateOf(sp.getInt("bass", 8))
        private set
    val eq = mutableStateListOf<Int>().apply {
        val s = (sp.getString("eq", "0,0,0,0,0,0") ?: "").split(",")
        repeat(6) { add(s.getOrNull(it)?.toIntOrNull() ?: 0) }
    }

    fun changeBass(v: Int) { bass = v; sp.edit().putInt("bass", v).apply() }
    fun setEq(i: Int, v: Int) { if (eq[i] != v) eq[i] = v }
    fun saveEq() { sp.edit().putString("eq", eq.joinToString(",")).apply() }
    fun flat() { for (i in 0..5) eq[i] = 0; saveEq() }
}

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val l: Local, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit
)
