package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import androidx.compose.runtime.*
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.Executors

/**
 * Protocol decoded from a real HeyMelody <-> Nord Buds 3 Bluetooth capture (RFCOMM channel 12).
 * Frame: AA | len16 LE (=7+payload) | 00 | cmd | type | seq | payloadLen16 LE | payload
 * type 0x01 = query, 0x04 = set, replies come back with bit 0x80 set.
 */
@SuppressLint("MissingPermission")
class Buds {
    var status by mutableStateOf("Not connected")
    var connected by mutableStateOf(false)
    val battery = mutableStateListOf(-1, -1, -1)      // left, right, case
    var ancMode by mutableIntStateOf(-1)                  // 1 / 2 / 4
    var presetMode by mutableIntStateOf(-1)               // 3 / 4 / 5
    val sw = mutableStateMapOf<String, Boolean>()     // "1d", "06", "f60a", "00"
    val gest = mutableStateMapOf<Int, Int>()          // side*16+gesture -> action id

    private val io = Executors.newSingleThreadExecutor()
    private var sock: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var seq = 0x20

    @Synchronized
    private fun raw(cmd: Int, typ: Int, pl: IntArray) {
        val o = out ?: return
        val n = 7 + pl.size
        val f = ByteArray(9 + pl.size)
        f[0] = 0xAA.toByte(); f[1] = n.toByte(); f[2] = (n shr 8).toByte(); f[3] = 0
        f[4] = cmd.toByte(); f[5] = typ.toByte(); f[6] = (seq++ and 255).toByte()
        f[7] = pl.size.toByte(); f[8] = (pl.size shr 8).toByte()
        pl.forEachIndexed { i, v -> f[9 + i] = v.toByte() }
        try { o.write(f); o.flush() } catch (e: Exception) { drop("Connection lost") }
    }

    fun send(cmd: Int, typ: Int, vararg pl: Int) { io.execute { raw(cmd, typ, pl) } }

    fun connect(d: BluetoothDevice) {
        status = "Connecting…"
        Thread {
            try { d.fetchUuidsWithSdp(); Thread.sleep(1500) } catch (e: Exception) {}
            val sig = "-0000-1000-8000-00805f9b34fb"
            val all = (d.uuids ?: emptyArray()).map { it.uuid }
            val order = all.filter { !it.toString().endsWith(sig) } + all.filter { it.toString().endsWith(sig) }
            for (u in order) {
                try {
                    val s = d.createRfcommSocketToServiceRecord(u)
                    s.connect()
                    sock = s; out = s.outputStream
                    val inp = java.io.PushbackInputStream(s.inputStream)
                    raw(0, 1, intArrayOf())
                    if (!awaitData(inp)) { s.close(); out = null; continue }
                    connected = true; status = "Connected to ${d.name}"
                    Thread { reader(inp) }.start()
                    raw(6, 1, intArrayOf())
                    raw(8, 1, intArrayOf(2, 3, 1))
                    raw(0x0d, 1, intArrayOf(6, 5, 0x0b, 0x11, 6, 0x1b, 0x1d))
                    raw(0x24, 1, intArrayOf())
                    Thread { while (connected) { Thread.sleep(15000); io.execute { raw(6, 1, intArrayOf()) } } }.start()
                    return@Thread
                } catch (e: Exception) { /* try next UUID */ }
            }
            status = "Control channel not found. Close HeyMelody and try again."
        }.start()
    }

    // Accept the channel only if the first byte is the 0xAA frame marker (skips HFP/A2DP channels)
    private fun awaitData(i: java.io.PushbackInputStream): Boolean {
        repeat(30) {
            if (i.available() > 0) { val b = i.read(); if (b >= 0) i.unread(b); return b == 0xAA }
            Thread.sleep(100)
        }
        return false
    }

    private fun reader(i: InputStream) {
        val tmp = ByteArray(512)
        var acc = ByteArray(0)
        try {
            while (true) {
                val n = i.read(tmp); if (n < 0) break
                acc += tmp.copyOf(n)
                while (true) {
                    val s = acc.indexOfFirst { it == 0xAA.toByte() }
                    if (s < 0) { acc = ByteArray(0); break }
                    if (s > 0) acc = acc.copyOfRange(s, acc.size)
                    if (acc.size < 3) break
                    val len = (acc[1].toInt() and 255) or ((acc[2].toInt() and 255) shl 8)
                    if (acc.size < len + 2) break
                    val f = acc.copyOfRange(0, len + 2)
                    acc = acc.copyOfRange(len + 2, acc.size)
                    handle(f)
                }
            }
        } catch (e: Exception) { }
        drop("Disconnected")
    }

    private fun handle(f: ByteArray) {
        if (f.size < 9) return
        val cmd = f[4].toInt() and 255
        val typ = f[5].toInt() and 255
        if ((typ and 0x80) == 0) return
        val p = IntArray(f.size - 9) { f[9 + it].toInt() and 255 }
        if (p.size < 2) return
        when (cmd) {
            0x06 -> for (k in 0 until p[1]) { val j = 2 + k * 2
                if (j + 1 < p.size && p[j] in 1..3) battery[p[j] - 1] = p[j + 1] }
            0x08 -> for (k in 0 until p[1]) { val j = 2 + k * 4
                if (j + 3 < p.size && p[j + 1] == 1) gest[p[j] * 16 + p[j + 2]] = p[j + 3] }
            0x0d -> for (k in 0 until p[1]) { val j = 2 + k * 2
                if (j + 1 < p.size) when (p[j]) {
                    0x1d -> sw["1d"] = p[j + 1] == 1
                    0x06 -> sw["06"] = p[j + 1] == 1
                } }
            0x24 -> if (p.size >= 4) sw["f60a"] = p[3] != 0
        }
    }

    private fun drop(msg: String) {
        connected = false; status = msg; out = null
        try { sock?.close() } catch (e: Exception) { }
    }

    fun disconnect() = drop("Not connected")

    // ---- commands (values marked "assumed" come from the order the actions were done in the capture)
    fun setAnc(v: Int) { ancMode = v; send(4, 4, 1, 1, v) }                 // 1 ANC, 2 Off, 4 Transparency (assumed)
    fun setPreset(v: Int) { presetMode = v; send(6, 4, v) }                 // 3 Balanced, 4 Serenade, 5 Bass (assumed)
    fun setGesture(side: Int, g: Int, a: Int) { gest[side * 16 + g] = a; send(1, 4, 1, side, 1, g, a) }
    fun setSwitch(key: String, on: Boolean) {
        sw[key] = on
        val v = if (on) 1 else 0
        when (key) {
            "1d" -> send(3, 4, 0x1d, v)
            "06" -> send(3, 4, 0x06, v)
            "f60a" -> send(0x1b, 4, 0xf6, 0x0a, if (on) 0xf6 else 0)
            "00" -> send(0, 4, v)
        }
    }
}
