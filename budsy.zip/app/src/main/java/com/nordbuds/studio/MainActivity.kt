package com.nordbuds.studio

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BG = Color(0xFFF0F1F5)
val BLUE = Color(0xFF0A84FF)

val ACTS = listOf(0x00 to "None", 0x08 to "Off", 0x0c to "Volume down", 0x0b to "Action 0x0B",
    0x01 to "Action 0x01", 0x03 to "Action 0x03", 0x05 to "Action 0x05", 0x06 to "Action 0x06", 0x11 to "Action 0x11")
fun actName(a: Int?) = if (a == null) "—" else ACTS.firstOrNull { it.first == a }?.second ?: "Action 0x%02X".format(a)

class MainActivity : ComponentActivity() {
    private val buds = Buds()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(buds) }
    }
}

@Composable
fun Card2(content: @Composable ColumnScope.() -> Unit) = Card(
    colors = CardDefaults.cardColors(containerColor = Color.White),
    shape = RoundedCornerShape(22.dp),
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
) { Column(Modifier.padding(18.dp), content = content) }

@Composable
fun SwitchRow(title: String, sub: String, on: Boolean, f: (Boolean) -> Unit) = Row(
    Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically
) {
    Column(Modifier.weight(1f)) { Text(title, fontSize = 17.sp); Text(sub, fontSize = 13.sp, color = Color.Gray) }
    Switch(checked = on, onCheckedChange = f)
}

@Composable
fun App(b: Buds) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var perm by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 ||
            ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    MaterialTheme(colorScheme = lightColorScheme(primary = BLUE)) {
        Scaffold(containerColor = BG, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("📱" to "Device", "👆" to "Earbud controls", "ℹ️" to "About").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.first) }, label = { Text(t.second, fontSize = 11.sp) })
                }
            }
        }) { pad ->
            Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp)) {
                when (tab) {
                    0 -> DeviceTab(b, perm) { ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }
                    1 -> ControlsTab(b)
                    else -> AboutTab()
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun DeviceTab(b: Buds, perm: Boolean, requestPerm: () -> Unit) {
    val ctx = LocalContext.current
    Text("OnePlus Nord Buds 3", fontSize = 30.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 12.dp))
    if (!b.connected) {
        Card2 {
            Text(b.status, fontSize = 15.sp)
            Text("Pehle buds ko phone ki Bluetooth settings mein pair karo aur HeyMelody band karo.", fontSize = 13.sp, color = Color.Gray)
            if (!perm) Button(onClick = requestPerm, modifier = Modifier.padding(top = 10.dp)) { Text("Allow Bluetooth permission") }
            else {
                val list = ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList()
                if (list.isEmpty()) Text("Koi paired device nahi mila.", modifier = Modifier.padding(top = 10.dp))
                list.forEach { d ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(d.name ?: d.address, Modifier.weight(1f))
                        Button(onClick = { b.connect(d) }) { Text("Connect") }
                    }
                }
            }
        }
        return
    }
    Text(listOf("L" to 0, "R" to 1, "Case" to 2).joinToString("   ") { (n, i) ->
        "$n " + (if (b.battery[i] >= 0) "${b.battery[i]}%" else "–") }, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(Triple("Noise cancellation", 1, "🔇"), Triple("Off", 2, "🚫"), Triple("Transparency", 4, "👂")).forEach { m ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { b.setAnc(m.second) }) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(if (b.ancMode == m.second) BLUE else Color(0xFFE2E3E8)),
                    contentAlignment = Alignment.Center) { Text(m.third, fontSize = 26.sp) }
                Text(m.first, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Card2 {
        Text("Sound Master EQ", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        listOf(3 to "Balanced", 4 to "Serenade", 5 to "Bass").forEach { p ->
            Row(Modifier.fillMaxWidth().clickable { b.setPreset(p.first) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = b.presetMode == p.first, onClick = { b.setPreset(p.first) }); Text(p.second)
            }
        }
    }
    Card2 {
        Text("Switches (beta)", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text("Ye buds ke real switches hain. Kaunsa kya hai, test karke naam badalenge.", fontSize = 12.sp, color = Color.Gray)
        listOf("1d" to "Switch 0x1D", "06" to "Switch 0x06", "f60a" to "Switch 0xF60A", "00" to "Switch cmd 00").forEach { s ->
            SwitchRow(s.second, "", b.sw[s.first] == true) { b.setSwitch(s.first, it) }
        }
    }
    Button(onClick = { b.disconnect() }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFD93025)),
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text("Disconnect") }
}

@Composable
fun ControlsTab(b: Buds) {
    var side by remember { mutableIntStateOf(1) }
    Text("Earbud controls", fontSize = 28.sp, modifier = Modifier.padding(vertical = 12.dp))
    if (!b.connected) { Text("Pehle Device tab se connect karo."); return }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = side == 1, onClick = { side = 1 }, label = { Text("Left") })
        FilterChip(selected = side == 2, onClick = { side = 2 }, label = { Text("Right") })
    }
    Card2 {
        listOf("Single tap" to 1, "Double tap" to 2, "Triple tap" to 3, "Touch and hold" to 4, "Long touch and hold" to 6).forEach { g ->
            var open by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(g.first, Modifier.weight(1f), fontSize = 16.sp)
                Box {
                    TextButton(onClick = { open = true }) { Text(actName(b.gest[side * 16 + g.second])) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        ACTS.forEach { a ->
                            DropdownMenuItem(text = { Text(a.second) }, onClick = { b.setGesture(side, g.second, a.first); open = false })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AboutTab() {
    Text("About", fontSize = 28.sp, modifier = Modifier.padding(vertical = 12.dp))
    Card2 {
        Text("Budsy 1.0", fontWeight = FontWeight.Medium)
        Text("Buds se seedha RFCOMM par baat karta hai, jo HeyMelody ke Bluetooth capture se decode kiya gaya hai. Ye unofficial app hai.",
            fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        Text("Pakka: battery, gesture table, switches ke commands. Andaza (order se): noise mode 1/2/4, EQ presets 3/4/5. Gesture ke baaki action naam abhi numbers mein hain.",
            fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
    }
}
