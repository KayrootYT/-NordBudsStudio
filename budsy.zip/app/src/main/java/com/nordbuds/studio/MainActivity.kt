package com.nordbuds.studio

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val buds = Buds()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Root(buds) }
    }
}

@Composable
fun Root(b: Buds) {
    val ctx = LocalContext.current
    val l = remember { Local(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var perm by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val toast: (String) -> Unit = { m ->
        if (l.notify.on) scope.launch { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(m, duration = SnackbarDuration.Short) }
    }
    val x = Ctx(b, l, perm, { ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }, toast, { tab = it })

    NordTheme(l.dark.on) {
        val view = LocalView.current
        val darkUi = l.dark.on
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !darkUi
                c.isAppearanceLightNavigationBars = !darkUi
            }
        }
        val washA = P.washA; val washB = P.washB
        Box(
            Modifier.fillMaxSize().background(P.bg).drawBehind {
                drawRect(Brush.radialGradient(listOf(washA, Color.Transparent), Offset(0f, 0f), size.width * .95f))
                drawRect(Brush.radialGradient(listOf(washB, Color.Transparent), Offset(size.width, 0f), size.width * .85f))
            }
        ) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopBar(x, tab)
                AnimatedContent(
                    targetState = tab, modifier = Modifier.weight(1f),
                    transitionSpec = { (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 28 }) togetherWith fadeOut(tween(120)) },
                    label = "page"
                ) { t ->
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                            .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 130.dp)
                    ) {
                        when (t) {
                            0 -> OverviewScreen(x)
                            1 -> SoundScreen(x)
                            2 -> ControlsScreen(x)
                            else -> SettingsScreen(x)
                        }
                    }
                }
            }
            BottomNav(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
            SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 104.dp))
        }
    }
}

@Composable
fun TopBar(x: Ctx, tab: Int) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).shadow(8.dp, CircleShape, ambientColor = P.accent.copy(alpha = .5f), spotColor = P.accent.copy(alpha = .5f))
                .clip(CircleShape).background(Brush.linearGradient(listOf(P.accent, P.accent2))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Headphones, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
        Spacer(Modifier.width(12.dp))
        Text(
            buildAnnotatedString { append("Nord Buds "); withStyle(SpanStyle(color = P.accent)) { append("Studio") } },
            color = P.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1
        )
        Box(Modifier.size(11.dp).clip(CircleShape).background(if (x.b.connected) P.green else P.amber))
        Spacer(Modifier.width(6.dp))
        BarIcon(if (x.l.dark.on) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, false) { x.l.dark.set(!x.l.dark.on) }
        BarIcon(Icons.Rounded.Settings, tab == 3) { x.go(3) }
    }
}

@Composable
private fun BarIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (active) P.accent else P.text, modifier = Modifier.size(24.dp)) }
}

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(Icons.Rounded.GridView to "Overview", Icons.Rounded.Tune to "Sound", Icons.Rounded.TouchApp to "Controls", Icons.Rounded.Settings to "Settings")
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)
            .shadow(if (P.dark) 0.dp else 18.dp, shape, ambientColor = Color(0x33B0402A), spotColor = Color(0x33B0402A))
            .background(P.card, shape).border(1.dp, P.line, shape).padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, item ->
            val sel = tab == i
            val bg by animateColorAsState(if (sel) P.soft else Color.Transparent, label = "nb")
            val tint by animateColorAsState(if (sel) P.accent else P.sub, label = "nt")
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(bg)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onTab(i) }
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(item.first, null, tint = tint, modifier = Modifier.size(26.dp))
                Txt(item.second, 12, if (sel) FontWeight.SemiBold else FontWeight.Medium, tint, maxLines = 1)
            }
        }
    }
}
