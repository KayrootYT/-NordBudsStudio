package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ---------------------------------------------------------------- shared bits

val ACTS = listOf(
    0x00 to "None", 0x08 to "Off", 0x0c to "Volume down", 0x0b to "Action 0x0B", 0x01 to "Action 0x01",
    0x03 to "Action 0x03", 0x05 to "Action 0x05", 0x06 to "Action 0x06", 0x11 to "Action 0x11"
)
fun actName(a: Int?) = if (a == null) "—" else ACTS.firstOrNull { it.first == a }?.second ?: "Action 0x%02X".format(a)

val PRESETS = listOf(Triple(3, "Balanced", "Natural, even tuning"), Triple(4, "Serenade", "Warm, vocal-forward"), Triple(5, "Bass", "Punchy low end"))
fun presetName(id: Int) = PRESETS.firstOrNull { it.first == id }?.second ?: "Balanced"

@Composable
fun PageHeader(eyebrow: String, title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
        Txt(eyebrow, 13, FontWeight.Bold, P.accent, spacing = 2f)
        Spacer(Modifier.height(6.dp))
        Txt(title, 34, FontWeight.Bold, P.text, lineHeight = 40)
        Spacer(Modifier.height(8.dp))
        Txt(sub, 16, lineHeight = 24)
    }
}

@Composable
fun Stack(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(16.dp), content = content)

@SuppressLint("MissingPermission")
@Composable
fun DeviceRows(x: Ctx) {
    val ctx = LocalContext.current
    if (!x.perm) { GradientButton("Allow Bluetooth permission", Icons.Rounded.Bluetooth) { x.askPerm() }; return }
    val list = remember(x.b.connected, x.perm) {
        try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList<BluetoothDevice>() }
        catch (e: Exception) { emptyList<BluetoothDevice>() }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (list.isEmpty()) Txt("No paired devices found. Pair your buds in Bluetooth settings first.", 14, lineHeight = 21)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.tile).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Headphones, 42.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1); Txt("Paired", 13) }
                SmallButton("Connect") { x.b.connect(d); x.toast("Connecting…") }
            }
        }
        Row(
            Modifier.clip(CircleShape).clickable {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt("Open Bluetooth settings", 14, FontWeight.SemiBold, P.accent)
        }
    }
}

@Composable
fun NoiseCard(x: Ctx) {
    val b = x.b
    val mode = if (b.ancMode == -1) 1 else b.ancMode
    val items = listOf(Icons.Rounded.Waves to "ANC", Icons.Rounded.Hearing to "Aware", Icons.Rounded.Block to "Off")
    val ids = listOf(1, 4, 2)
    AppCard {
        CardHeader(Icons.Rounded.Waves, "Noise control", "ANC up to 32 dB") { Tag(if (b.connected) "LIVE" else "PREVIEW", b.connected) }
        Spacer(Modifier.height(16.dp))
        Segmented(items, ids.indexOf(mode).coerceAtLeast(0)) { i ->
            b.setAnc(ids[i])
            if (!b.connected) x.toast("Preview only. Connect your buds to apply.")
        }
        Spacer(Modifier.height(14.dp))
        val (head, rest) = when (mode) {
            1 -> "Noise Cancellation." to " Up to 32 dB of noise reduction (manufacturer claim)."
            4 -> "Aware." to " Lets outside sound in so you can hear your surroundings."
            else -> "Off." to " Plain listening with no noise processing."
        }
        Text(
            buildAnnotatedString { withStyle(SpanStyle(color = P.text, fontWeight = FontWeight.SemiBold)) { append(head) }; append(rest) },
            color = P.sub, fontSize = 15.sp, lineHeight = 22.sp
        )
    }
}

// ---------------------------------------------------------------- overview

@Composable
fun OverviewScreen(x: Ctx) {
    val b = x.b; val l = x.l; val live = b.connected
    val bat = if (live) b.battery.toList() else listOf(82, 76, 64)
    val mode = if (b.ancMode == -1) 1 else b.ancMode
    Stack {
        AppCard(pad = 0.dp) {
            Column(Modifier.background(Brush.verticalGradient(listOf(P.washA.copy(alpha = .5f), Color.Transparent))).padding(20.dp)) {
                Box(Modifier.fillMaxWidth()) {
                    BudsArt(Modifier.align(Alignment.Center))
                    Box(Modifier.align(Alignment.BottomEnd)) {
                        Pill(when (mode) { 1 -> "Noise Cancellation"; 4 -> "Aware"; else -> "Noise off" })
                    }
                }
                Spacer(Modifier.height(14.dp))
                Tag(if (live) "CONNECTED" else "DEMO PREVIEW", live)
                Spacer(Modifier.height(12.dp))
                Text(
                    buildAnnotatedString { append("OnePlus "); withStyle(SpanStyle(color = P.accent)) { append("Nord Buds 3") } },
                    color = P.text, fontSize = 32.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Txt(
                    if (live) "Connected to ${b.deviceName}. Battery, noise control and touch settings are read from your buds."
                    else "Demo preview — connect your buds to read live values. Battery levels below are illustrative sample values.", 15, lineHeight = 22
                )
                Spacer(Modifier.height(16.dp))
                Waveform(live)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BatteryTile(Icons.Rounded.Hearing, bat[0], "Left", Modifier.weight(1f))
                    BatteryTile(Icons.Rounded.Hearing, bat[1], "Right", Modifier.weight(1f))
                    BatteryTile(Icons.Rounded.Inventory2, bat[2], "Case", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Txt(if (live) "Live values from your buds" else "Illustrative demo values · not read from a device", 13, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }

        if (!live) {
            AppCard {
                CardHeader(Icons.Rounded.Bluetooth, "Connect your buds", b.status)
                Spacer(Modifier.height(6.dp))
                Txt("Pair the buds in phone Bluetooth settings, force-stop HeyMelody, then tap Connect.", 14, lineHeight = 21)
                Spacer(Modifier.height(14.dp))
                DeviceRows(x)
            }
        } else {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconTile(Icons.Rounded.Bluetooth, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Txt(b.deviceName, 17, FontWeight.SemiBold, P.text, maxLines = 1); Txt("Connected", 14, color = P.green) }
                    SmallButton("Disconnect", false) { b.disconnect(); x.toast("Disconnected") }
                }
            }
        }

        NoiseCard(x)
        ToggleCard(
            Icons.Rounded.SportsEsports, "Game Mode", "Latency as low as 94 ms (claim)",
            "Lowers audio latency for gaming. State is saved in this app only (preview).", l.gameMode.on
        ) { l.gameMode.set(it) }
        ToggleCard(
            Icons.Rounded.Mic, "AI Clear Calls", "2 mics per earbud",
            "Reduces background noise during calls so your voice stays clear.", l.aiClear.on
        ) { l.aiClear.set(it) }

        AppCard {
            CardHeader(Icons.Rounded.BatteryChargingFull, "Battery & charging", "Manufacturer claims")
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Total · ANC off", "43 h", "with case", Modifier.weight(1f))
                StatTile("Total · ANC on", "28 h", "with case", Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Earbuds alone", "12 h", "ANC off", Modifier.weight(1f))
                StatTile("Fast charge", "11 h", "from 10 min", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("USB-C case"); Pill("TÜV Rheinland certified") }
            Spacer(Modifier.height(14.dp))
            InfoNote("Figures are manufacturer claims under specified test conditions. Real playback varies with volume, ANC, codec and usage.")
        }

        AppCard(onClick = { x.go(1) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Tune)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Txt("Sound", 19, FontWeight.SemiBold, P.text)
                    Txt("${presetName(if (b.presetMode == -1) 3 else b.presetMode)} · BassWave level ${l.bass}", 14)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = P.sub)
            }
        }
        AppCard(onClick = { x.go(2) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.TouchApp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Txt("Touch controls", 19, FontWeight.SemiBold, P.text)
                    Txt(if (live && b.gest[0x11] != null) "Single tap: ${actName(b.gest[0x11])}" else "Connect to read your mapping", 14)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = P.sub)
            }
        }

        AppCard {
            CardHeader(Icons.Rounded.Memory, "Device integration", "What this app can and can't do")
            Spacer(Modifier.height(14.dp))
            val gotBat = live && b.battery.any { it >= 0 }
            StatusRow(1, "Interactive UI and saved local settings")
            StatusRow(if (live) 1 else 2, "Bluetooth link to the earbuds")
            StatusRow(if (gotBat) 1 else 2, "Live left / right / case battery")
            StatusRow(if (live) 1 else 2, "ANC mode, touch gestures, EQ presets")
            StatusRow(0, "BassWave and Master EQ on the buds")
            StatusRow(0, "Firmware updates")
            Spacer(Modifier.height(12.dp))
            Txt("Items marked partial work once the buds are connected. BassWave and Master EQ are stored in this app until their commands are decoded.", 13, lineHeight = 19)
        }
    }
}

@Composable
fun StatusRow(state: Int, text: String) {
    val c = when (state) { 1 -> P.green; 2 -> P.amber; else -> P.sub }
    Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(c.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
            Icon(when (state) { 1 -> Icons.Rounded.Check; 2 -> Icons.Rounded.MoreHoriz; else -> Icons.Rounded.Close }, null, tint = c, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(12.dp))
        Txt(text, 15, color = P.text, lineHeight = 21)
    }
}

// ---------------------------------------------------------------- sound

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b; val l = x.l
    val cur = if (b.presetMode == -1) 3 else b.presetMode
    Stack {
        PageHeader("AUDIO & SOUND", "Sound studio", "Shape your sound with presets, BassWave 2.0 and Master EQ.")
        AppCard {
            CardHeader(Icons.Rounded.GraphicEq, "EQ presets") { Tag(if (b.connected) "LIVE" else "PREVIEW", b.connected) }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PRESETS.forEach { (id, name, desc) ->
                    val sel = cur == id
                    val shape = RoundedCornerShape(24.dp)
                    Column(
                        Modifier.weight(1f).height(112.dp)
                            .then(if (sel) Modifier.shadow(12.dp, shape, ambientColor = P.accent.copy(alpha = .4f), spotColor = P.accent.copy(alpha = .4f)) else Modifier)
                            .clip(shape).background(if (sel) P.soft else P.tile)
                            .border(if (sel) 2.dp else 1.dp, if (sel) P.accent else P.line, shape)
                            .clickable {
                                b.setPreset(id)
                                if (!b.connected) x.toast("Preview only. Connect your buds to apply.")
                            }.padding(14.dp)
                    ) {
                        Txt(name, 18, FontWeight.SemiBold, if (sel) P.accent else P.text, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        Txt(desc, 13, lineHeight = 18)
                    }
                }
            }
        }

        AppCard {
            CardHeader(Icons.Rounded.Waves, "BassWave 2.0", "Bass adjustment · 20 levels") {
                Txt("${l.bass}", 30, FontWeight.Bold, P.accent)
            }
            Spacer(Modifier.height(8.dp))
            Slider(
                value = l.bass.toFloat(), onValueChange = { l.changeBass(it.roundToInt()) }, valueRange = 0f..20f, steps = 19,
                colors = SliderDefaults.colors(
                    thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.soft,
                    activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                )
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Txt("0 · Subtle", 14); Txt("20 · Deep", 14) }
            Spacer(Modifier.height(10.dp))
            Txt("Saved in this app. Sending BassWave to the buds needs a protocol command that isn't decoded yet.", 13, lineHeight = 19)
        }

        AppCard {
            CardHeader(Icons.Rounded.Album, "Master EQ", "Drag the curve to customise") {
                Row(
                    Modifier.clip(CircleShape).clickable { l.flat() }.padding(8.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Restore, null, tint = P.sub, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)); Txt("Flat", 15, FontWeight.Medium, P.text)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                l.eq.forEach { v ->
                    Txt(if (v > 0) "+$v" else "$v", 14, FontWeight.SemiBold, if (v == 0) P.sub else P.accent, Modifier.weight(1f), TextAlign.Center)
                }
            }
            EqGraph(l.eq, { i, v -> l.setEq(i, v) }, { l.saveEq() })
            Row(Modifier.fillMaxWidth()) {
                listOf("62", "250", "1k", "4k", "8k", "16k").forEach { Txt(it, 13, modifier = Modifier.weight(1f), align = TextAlign.Center) }
            }
            Spacer(Modifier.height(12.dp))
            Txt("Range ±12 dB. Saved in this app (preview).", 13)
        }

        ToggleCard(
            Icons.Rounded.ViewInAr, "3D Audio", "On supported OnePlus phones",
            "Spatial sound is available only when paired with a supported OnePlus phone.", false, enabled = false
        ) { }

        AppCard {
            Txt("Hardware", 19, FontWeight.SemiBold, P.text)
            Txt("Published specifications", 14)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Drivers", "12.4 mm", "Titanium dynamic", Modifier.weight(1f))
                StatTile("Frequency", "20 Hz–20 kHz", "Published response", Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(P.tile).padding(16.dp)) {
                Txt("Codecs", 13)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("AAC", true); Pill("SBC", true) }
            }
        }
    }
}

// ---------------------------------------------------------------- controls

private data class Gest(val name: String, val id: Int, val dots: Int)
private val GESTS = listOf(Gest("Single tap", 1, 1), Gest("Double tap", 2, 2), Gest("Triple tap", 3, 3), Gest("Press & hold", 4, 0), Gest("Long press & hold", 6, -1))

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b; val l = x.l
    var sideSel by remember { mutableIntStateOf(0) }
    val pending = remember { mutableStateMapOf<Int, Int>() }
    val sides = when (sideSel) { 0 -> listOf(1, 2); 1 -> listOf(1); else -> listOf(2) }
    Stack {
        PageHeader("NOISE & TOUCH", "Controls", "Choose a listening mode and map touch gestures for your buds.")
        NoiseCard(x)

        AppCard {
            CardHeader(Icons.Rounded.Mic, "Call clarity", "AI Clear Calls") { NordSwitch(l.aiClear.on) { l.aiClear.set(it) } }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Microphones", "2 per bud", "4 in total", Modifier.weight(1f))
                StatTile("In calls", "Noise reduction", "Background suppression", Modifier.weight(1f))
            }
        }

        AppCard {
            CardHeader(Icons.Rounded.TouchApp, "Touch gestures", "Pick an earbud, then choose actions") { Tag(if (b.connected) "LIVE" else "PREVIEW", b.connected) }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().clip(CircleShape).background(P.tile).padding(4.dp)) {
                listOf("Both", "Left", "Right").forEachIndexed { i, n ->
                    val sel = sideSel == i
                    Box(
                        Modifier.weight(1f).clip(CircleShape)
                            .then(if (sel) Modifier.background(Brush.linearGradient(listOf(P.accent, P.accent2))) else Modifier)
                            .clickable { sideSel = i }.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) { Txt(n, 15, FontWeight.SemiBold, if (sel) Color.White else P.sub) }
                }
            }
            Spacer(Modifier.height(12.dp))
            GESTS.forEach { g ->
                val key = sides[0] * 16 + g.id
                val cur = pending[key] ?: b.gest[key]
                GestureRow(g, cur, pending[key] != null) { a -> sides.forEach { pending[it * 16 + g.id] = a } }
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.height(4.dp))
            GradientButton(
                if (pending.isEmpty()) "Apply mapping" else "Apply mapping (${pending.size} change${if (pending.size > 1) "s" else ""})",
                Icons.Rounded.Save, enabled = pending.isNotEmpty() && b.connected
            ) {
                when {
                    !b.connected -> x.toast("Connect your buds first")
                    pending.isEmpty() -> x.toast("Nothing to apply")
                    else -> { pending.toMap().forEach { (k, a) -> b.setGesture(k / 16, k % 16, a) }; pending.clear(); x.toast("Mapping sent to buds") }
                }
            }
            Spacer(Modifier.height(12.dp))
            InfoNote("Some actions show a code (like Action 0x0B) because their names haven't been confirmed yet. Test one to see what it does.")
        }
    }
}

@Composable
private fun GestureRow(g: Gest, cur: Int?, changed: Boolean, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(P.tile).border(1.dp, if (changed) P.accent else Color.Transparent, shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(56.dp, 40.dp).clip(RoundedCornerShape(16.dp)).background(P.soft), contentAlignment = Alignment.Center) {
            when {
                g.dots > 0 -> Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { repeat(g.dots) { Box(Modifier.size(7.dp).clip(CircleShape).background(P.accent)) } }
                g.dots == 0 -> Box(Modifier.size(22.dp, 7.dp).clip(CircleShape).background(P.accent))
                else -> Box(Modifier.size(34.dp, 7.dp).clip(CircleShape).background(P.accent))
            }
        }
        Spacer(Modifier.width(12.dp))
        Txt(g.name, 16, FontWeight.Medium, P.text, Modifier.weight(1f), lineHeight = 20)
        Box {
            Row(
                Modifier.widthIn(max = 160.dp).clip(CircleShape).background(P.card).border(1.dp, P.line, CircleShape)
                    .clickable { open = true }.padding(start = 14.dp, end = 8.dp, top = 9.dp, bottom = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Txt(actName(cur), 14, FontWeight.Medium, P.text, Modifier.weight(1f, fill = false), maxLines = 1)
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = P.sub, modifier = Modifier.size(20.dp))
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                ACTS.forEach { a -> DropdownMenuItem(text = { Text(a.second) }, onClick = { onPick(a.first); open = false }) }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

private val SPECS = listOf(
    Triple("Audio", "Drivers", "12.4 mm titanium dynamic"), Triple("Audio", "BassWave", "BassWave 2.0 bass adjustment"),
    Triple("Audio", "Master EQ", "Custom sound tuning"), Triple("Audio", "EQ presets", "Balanced, Serenade, Bass"),
    Triple("Audio", "3D Audio", "On supported OnePlus phones"), Triple("Audio", "Codecs", "AAC, SBC"),
    Triple("Audio", "Frequency response", "20 Hz–20 kHz"), Triple("Noise", "ANC", "Up to 32 dB (claim)"),
    Triple("Calls", "AI Clear Calls", "2 mics per earbud"), Triple("Connect", "Bluetooth", "5.4 · range ≈10 m"),
    Triple("Connect", "Latency", "As low as 94 ms"), Triple("Connect", "Dual connection", "2 devices at once"),
    Triple("Battery", "Playback", "Up to 43 h with case (ANC off)"), Triple("Battery", "Fast charge", "11 h from 10 min"),
    Triple("Durability", "IP rating", "IP55 earbuds"), Triple("Case", "Charging", "USB-C"),
    Triple("Control", "Touch", "Single, double, triple, hold")
)

@Composable
fun SettingsScreen(x: Ctx) {
    val b = x.b; val l = x.l
    var q by remember { mutableStateOf("") }
    Stack {
        PageHeader("CONNECTIVITY & DEVICE", "Settings", "Connections, preferences and everything about your buds.")

        AppCard {
            CardHeader(Icons.Rounded.Bluetooth, "Connections", "Bluetooth 5.4 · up to 2 devices") { Tag(if (b.connected) "LIVE" else "PREVIEW", b.connected) }
            Spacer(Modifier.height(14.dp))
            if (b.connected) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.tile).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconTile(Icons.Rounded.PhoneAndroid, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Txt("Device slot 1", 16, FontWeight.Medium, P.text); Txt("Connected · ${b.deviceName}", 13, maxLines = 1) }
                    SmallButton("Disconnect", false) { b.disconnect(); x.toast("Disconnected") }
                }
            } else {
                Txt(b.status, 14, FontWeight.Medium, P.text); Spacer(Modifier.height(10.dp))
                DeviceRows(x)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.tile).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Laptop, 42.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Txt("Device slot 2", 16, FontWeight.Medium, P.text); Txt("Dual Connection · Empty (preview)", 13) }
                SmallButton("Pair", false) { x.toast("Pair the second device from its own Bluetooth menu") }
            }
            Spacer(Modifier.height(6.dp))
            ToggleRow("Dual Connection", "Stay connected to 2 devices at once", l.dual.on) { l.dual.set(it) }
            ToggleRow("Google Fast Pair", "Quick pairing on supported Android phones", l.fastPair.on, divider = false) { l.fastPair.set(it) }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Version", "BT 5.4", "Bluetooth", Modifier.weight(1f))
                StatTile("Range", "≈10 m", "Varies", Modifier.weight(1f))
                StatTile("Latency", "94 ms", "As low as", Modifier.weight(1f))
            }
        }

        ToggleCard(
            Icons.Rounded.SportsEsports, "Game Mode", "Low-latency audio",
            "Latency claim as low as 94 ms. State is saved in this app only (preview).", l.gameMode.on
        ) { l.gameMode.set(it) }

        AppCard {
            Txt("Preferences", 19, FontWeight.SemiBold, P.text)
            Txt("Stored on this phone", 14)
            Spacer(Modifier.height(6.dp))
            ToggleRow("Status notifications", "Show feedback messages in this app", l.notify.on) { l.notify.set(it) }
            ToggleRow("AI Clear Calls", "Background noise reduction during calls", l.aiClear.on) { l.aiClear.set(it) }
            ToggleRow("Dark mode", "Easier on the eyes at night", l.dark.on) { l.dark.set(it) }
            ToggleRow("3D Audio", "On supported OnePlus phones", false, enabled = false, divider = false) { }
        }

        AppCard {
            CardHeader(Icons.Rounded.Tune, "Advanced switches", "Real switches on the buds (beta)") { Tag(if (b.connected) "LIVE" else "OFFLINE", b.connected) }
            Spacer(Modifier.height(6.dp))
            Txt("Names aren't confirmed yet. Flip one and note what changes.", 13, lineHeight = 19)
            Spacer(Modifier.height(6.dp))
            val sw = listOf("1d" to "Switch 0x1D", "06" to "Switch 0x06", "f60a" to "Switch 0xF60A", "00" to "Switch cmd 00")
            sw.forEachIndexed { i, s ->
                ToggleRow(s.second, if (b.connected) "Sent straight to the buds" else "Connect to use", b.sw[s.first] == true, b.connected, i < sw.size - 1) { b.setSwitch(s.first, it) }
            }
        }

        AppCard {
            CardHeader(Icons.Rounded.WaterDrop, "Protection & design")
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Earbuds", "IP55", "Water & dust", Modifier.weight(1f))
                StatTile("Fit", "Light", "In-ear, lightweight", Modifier.weight(1f))
                StatTile("Case", "USB-C", "Compact", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            InfoNote("IP55 covers sweat and light rain on the earbuds only — not submersible. Don't swim or shower with them; the case is not rated.")
        }

        AppCard {
            CardHeader(Icons.Rounded.FormatListBulleted, "Features & specifications", "OnePlus Nord Buds 3 · manufacturer published")
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().clip(CircleShape).background(P.tile).border(1.dp, P.line, CircleShape).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Search, null, tint = P.sub, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    q, { q = it }, Modifier.weight(1f), singleLine = true,
                    textStyle = TextStyle(color = P.text, fontSize = 16.sp), cursorBrush = SolidColor(P.accent),
                    decorationBox = { inner -> if (q.isEmpty()) Txt("Search e.g. latency, IP55, codec…", 16); inner() }
                )
                if (q.isNotEmpty()) Icon(Icons.Rounded.Close, null, tint = P.sub, modifier = Modifier.size(20.dp).clickable { q = "" })
            }
            Spacer(Modifier.height(8.dp))
            val hits = SPECS.filter { (t, n, v) -> q.isBlank() || listOf(t, n, v).any { it.contains(q.trim(), ignoreCase = true) } }
            if (hits.isEmpty()) Txt("No matches. Try a different word.", 14, modifier = Modifier.padding(vertical = 16.dp))
            hits.forEachIndexed { i, (t, n, v) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Txt(t.uppercase(), 11, FontWeight.Bold, P.accent, spacing = 1f); Txt(n, 16, FontWeight.Medium, P.text) }
                    Spacer(Modifier.width(12.dp))
                    Txt(v, 14, modifier = Modifier.weight(1.1f), align = TextAlign.End, lineHeight = 19)
                }
                if (i < hits.size - 1) HorizontalDivider(color = P.line)
            }
        }

        AppCard {
            Txt("About this app", 17, FontWeight.SemiBold, P.text)
            Spacer(Modifier.height(6.dp))
            Txt(
                "Nord Buds Studio 1.0 is unofficial. It talks to the buds over Bluetooth using a protocol decoded from a HeyMelody capture. " +
                    "Confirmed: battery, gesture table, switch commands. Assumed from the capture order: noise mode IDs 1/2/4 and EQ presets 3/4/5.", 13, lineHeight = 19
            )
        }
    }
}
