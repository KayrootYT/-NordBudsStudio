package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

// ================================================================= DEVICE

@Composable
fun DeviceScreen(x: Ctx) {
    val b = x.b
    Stack {
        Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BudArt(false, 150.dp)
                BudArt(true, 150.dp)
            }
            Spacer(Modifier.height(8.dp))
            Txt(if (b.connected) b.deviceName else "OnePlus Nord Buds 3", 24, FontWeight.SemiBold, P.text, align = TextAlign.Center)
            Spacer(Modifier.height(2.dp))
            Txt(
                if (b.connected) "Connected" else b.status, 15,
                color = if (b.connected) P.green else P.sub, align = TextAlign.Center
            )
        }

        if (!b.connected) {
            Panel { Column(Modifier.padding(20.dp)) { ConnectBlock(x) } }
            return@Stack
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BatteryTile(b.battery[0], b.charging[0], "L", Modifier.weight(1f))
            BatteryTile(b.battery[1], b.charging[1], "R", Modifier.weight(1f))
            BatteryTile(b.battery[2], b.charging[2], "Case", Modifier.weight(1f))
        }

        SectionLabel("Noise control")
        Panel {
            Column(Modifier.padding(14.dp)) {
                val items = listOf(Icons.Rounded.Waves to "Noise cancellation", Icons.Rounded.Block to "Off", Icons.Rounded.Hearing to "Transparency")
                val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                Segmented(items, ids.indexOf(b.ancMode)) { i -> b.setAnc(ids[i]) }
            }
        }

        SectionLabel("Sound effect")
        Panel {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Buds.PRESETS.forEachIndexed { i, p ->
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clickable { b.setEq(p.first) }.padding(vertical = 16.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) { Txt(p.second, 18, FontWeight.Normal, P.text); Txt(p.third, 14) }
                            RadioDot(b.eqPreset == p.first)
                        }
                        if (i < Buds.PRESETS.size - 1) HorizontalDivider(color = P.line)
                    }
                }
            }
        }

        SectionLabel("Bass")
        Panel {
            SwitchRow("BassWave", "Adjust the low end", b.bassOn == true, divider = b.bassLevel != null) { b.setBassOn(it) }
            val lv = b.bassLevel
            if (lv != null) {
                var drag by remember { mutableStateOf<Float?>(null) }
                Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 14.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Txt("Level", 16, FontWeight.Normal, P.text, Modifier.weight(1f))
                        val shown = (drag ?: lv.toFloat()).roundToInt()
                        Txt(if (shown > 0) "+$shown" else "$shown", 16, FontWeight.SemiBold, P.accent)
                    }
                    Slider(
                        value = drag ?: lv.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null },
                        valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(),
                        steps = (b.bassMax - b.bassMin - 1).coerceAtLeast(0),
                        enabled = b.bassOn == true,
                        colors = SliderDefaults.colors(
                            thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.soft,
                            activeTickColor = androidx.compose.ui.graphics.Color.Transparent,
                            inactiveTickColor = androidx.compose.ui.graphics.Color.Transparent
                        )
                    )
                }
            }
        }

        SectionLabel("Gaming")
        Panel {
            SwitchRow("Game mode", "Lower audio latency", b.gameMode == true, divider = false) { b.setGame(it) }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            SmallButton("Refresh", false) { b.refreshAll() }
            Spacer(Modifier.width(10.dp))
            SmallButton("Disconnect", false) { b.disconnect() }
        }
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt("Bluetooth permission is needed to find your paired earbuds.", 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton("Allow Bluetooth") { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting) { bondedDevices(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Txt("Pair the earbuds in Bluetooth settings first, close HeyMelody, then tap Connect.", 14, lineHeight = 20)
        if (list.isEmpty()) Txt("No paired devices found.", 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Headphones, null, tint = P.accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt("Paired", 13)
                }
                SmallButton(if (b.connecting) "…" else "Connect") { if (!b.connecting) b.connect(d) }
            }
        }
        Row(
            Modifier.clip(CircleShape).clickable {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt("Open Bluetooth settings", 14, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val label: String)

private val NONE = Opt(Buds.F_NONE, "None")
private val PLAY = Opt(Buds.F_PLAY, "Play/Pause")
private val PREV = Opt(Buds.F_PREV, "Previous")
private val NEXT = Opt(Buds.F_NEXT, "Next track")
private val VOICE = Opt(Buds.F_VOICE, "Voice Assistant")
private val GAME = Opt(Buds.F_GAME, "Game mode")

private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, "Volume up"), Opt(Buds.F_VOL_DN, "Volume down"))

private fun optsFor(gid: Int) = when (gid) {
    Buds.G_SINGLE -> SINGLE_OPTS
    Buds.G_DOUBLE -> DOUBLE_OPTS
    Buds.G_TRIPLE -> TRIPLE_OPTS
    else -> LONG_OPTS
}

private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return it.label }
    return when (fn) {
        0x07 -> "Volume"
        0x0A -> "Switch track"
        Buds.F_ANC -> "Noise control"
        else -> "Action 0x%02X".format(fn)
    }
}

private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add("Noise cancellation")
        if ((mask and Buds.M_OFF) != 0) add("Off")
        if ((mask and Buds.M_TRANSP) != 0) add("Transparency")
    }
    return n.joinToString(", ")
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) "left" else "right"
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast("Connect your earbuds first") }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null

    Stack {
        if (!live) {
            Panel {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt("Earbuds not connected", 16, FontWeight.Medium, P.text)
                        Txt("Connect on the Device tab to change controls.", 14)
                    }
                    SmallButton("Device") { x.go(0) }
                }
            }
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            BudArt(side == 2, 190.dp, touchSpot = true)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Chip("Left", side == 1) { side = 1 }
                Chip("Right", side == 2) { side = 2 }
            }
        }

        SectionLabel("When not on a call")
        Panel {
            ValueRow("Single-tap $sideName earbud", fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE))) { open(Buds.G_SINGLE) }
            ValueRow("Double-tap $sideName earbud", fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE))) { open(Buds.G_DOUBLE) }
            ValueRow("Triple-tap $sideName earbud", fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE))) { open(Buds.G_TRIPLE) }
            ValueRow("Touch and hold", if (live) holdLabel(b.holdMask) else "—") { open(Buds.G_HOLD) }
            ValueRow("Long touch and hold", fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), divider = false) { open(Buds.G_LONG) }
        }

        SectionLabel("When on a call")
        Panel {
            ValueRow("Double-tap $sideName earbud", "Answer/End call", chevron = false)
            ValueRow("Long touch and hold", "Decline call", chevron = false, divider = false)
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.tile)
                .clickable { tutorial = true }.padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Txt("Learn earbud controls", 15)
            Spacer(Modifier.height(14.dp))
            Txt("View tutorial", 18, FontWeight.Normal, P.text)
        }
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> "Single-tap"; Buds.G_DOUBLE -> "Double-tap"; else -> "Triple-tap" }) + " $sideName earbud"
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(o.label, now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton("Cancel", false) { dlg = 0 }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }) {
            SheetTitle("Long touch and hold")
            Txt(
                "Raise or lower the volume: Press and hold the earbud until you hear 3 beeps. Lift your finger to stop adjusting the volume.",
                16, lineHeight = 23
            )
            Spacer(Modifier.height(14.dp))
            Txt(
                "Switch between Noise control modes: Press and hold the earbud and lift your finger when you hear a beep.",
                16, lineHeight = 23
            )
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEachIndexed { i, o ->
                RadioRow(o.label, now == o.fn, divider = i < LONG_OPTS.size - 1) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton("Cancel", false) { dlg = 0 }
        }
    }

    if (g == Buds.G_HOLD) {
        var sel by remember { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) sel = v }
        SheetDialog({ dlg = 0 }) {
            SheetTitle("Touch and hold")
            Txt(
                if (n == 1) "1 option selected. Touching and holding will not switch modes."
                else "$n options selected. Touching and holding will switch between these modes.",
                16, lineHeight = 22
            )
            Spacer(Modifier.height(6.dp))
            CheckRow("Noise cancellation", "Significantly reduce external noise.", (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow("Off", "No noise cancellation effect", (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow("Transparency", "External noise can be heard.", (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton("Cancel", false) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton("Confirm", true) { b.setHoldMask(sel); dlg = 0 } }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle("Earbud controls")
            Txt("Single, double and triple tap: tap the touch area on the stem of the earbud quickly.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("Touch and hold: hold until you hear a beep, then let go to switch noise control mode.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("Long touch and hold: keep holding until you hear 3 beeps, then adjust the volume.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("During a call: double-tap to answer or end it, long hold to decline.", 16, lineHeight = 23)
            Spacer(Modifier.height(18.dp))
            WideButton("Got it", true) { tutorial = false }
        }
    }
}

// ================================================================= ABOUT

@Composable
fun AboutScreen(x: Ctx) {
    val b = x.b
    val clip = LocalClipboardManager.current
    Stack {
        SectionLabel("Earbuds")
        Panel {
            ValueRow("Name", if (b.connected) b.deviceName else "—", chevron = false)
            ValueRow("Bluetooth address", if (b.connected) b.deviceAddr else "—", chevron = false)
            ValueRow("Status", if (b.connected) "Connected" else b.status, chevron = false, divider = false)
        }
        if (b.connected) {
            WideButton("Disconnect", false) { b.disconnect() }
        } else {
            Panel { Column(Modifier.padding(20.dp)) { ConnectBlock(x) } }
        }

        SectionLabel("Diagnostics")
        Panel {
            Column(Modifier.padding(20.dp)) {
                Txt("Gesture table reported by the buds", 16, FontWeight.Medium, P.text)
                Spacer(Modifier.height(6.dp))
                val keys = b.gest.keys.sorted()
                if (keys.isEmpty()) Txt("Nothing read yet.", 14)
                keys.forEach { k ->
                    Txt(
                        "${if (k / 16 == 1) "Left" else if (k / 16 == 2) "Right" else "Side ${k / 16}"} · gesture ${k % 16} → 0x%02X".format(b.gest[k] ?: 0),
                        13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt("Protocol log", 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                    SmallButton("Copy", false) { clip.setText(AnnotatedString(b.logText())); x.toast("Log copied") }
                }
                Spacer(Modifier.height(6.dp))
                val ver = b.logVersion
                val lines = remember(ver) { b.logText().lines().takeLast(14) }
                Txt(
                    if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) "Empty." else lines.joinToString("\n"),
                    11, FontWeight.Normal, P.sub, lineHeight = 15
                )
            }
        }

        Txt(
            "Nord Buds Studio is an unofficial controller for OnePlus Nord Buds 3. It talks to the earbuds over Bluetooth using the same control channel as HeyMelody, " +
                "so close HeyMelody before connecting.",
            13, lineHeight = 19, modifier = Modifier.padding(horizontal = 12.dp)
        )
    }
}
