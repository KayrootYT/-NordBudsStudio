package com.nordbuds.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color, size.sp, fontWeight = weight, textAlign = align,
    lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
    letterSpacing = spacing.sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

@Composable
fun AppCard(
    modifier: Modifier = Modifier, pad: Dp = 20.dp, onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier.fillMaxWidth()
            .shadow(if (P.dark) 0.dp else 10.dp, shape, ambientColor = Color(0x22B0402A), spotColor = Color(0x22B0402A))
            .background(P.card, shape).border(1.dp, P.line, shape).clip(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(pad),
        content = content
    )
}

@Composable
fun IconTile(icon: ImageVector, size: Dp = 52.dp, tint: Color = P.accent) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.32f)).background(P.soft), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.46f))
    }
}

@Composable
fun CardHeader(icon: ImageVector, title: String, sub: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconTile(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Txt(title, 19, FontWeight.SemiBold, P.text)
            if (sub != null) Txt(sub, 14, lineHeight = 19)
        }
        if (trailing != null) { Spacer(Modifier.width(8.dp)); trailing() }
    }
}

@Composable
fun Tag(text: String, live: Boolean = false) {
    val c = if (live) P.green else P.accent
    Row(
        Modifier.clip(CircleShape).background(c.copy(alpha = .08f)).border(1.dp, c.copy(alpha = .45f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (live) Icons.Rounded.Bolt else Icons.Rounded.Science, null, tint = c, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(4.dp))
        Txt(text, 11, FontWeight.Bold, c, spacing = .8f)
    }
}

@Composable
fun Pill(text: String, filled: Boolean = false) {
    val shape = CircleShape
    Box(
        Modifier.clip(shape)
            .background(if (filled) P.accent else P.tile, shape)
            .border(1.dp, if (filled) P.accent else P.line, shape)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Txt(text, 14, FontWeight.SemiBold, if (filled) Color.White else P.text) }
}

@Composable
fun NordSwitch(on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 26.dp else 2.dp, spring(stiffness = 600f), label = "sw")
    val bg by animateColorAsState(if (on) P.accent else P.track, label = "swc")
    Box(
        Modifier.alpha(if (enabled) 1f else .5f).size(54.dp, 30.dp).clip(CircleShape).background(bg)
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { onChange(!on) },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.offset(x = x).size(26.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

@Composable
fun ToggleRow(title: String, sub: String, on: Boolean, enabled: Boolean = true, divider: Boolean = true, onChange: (Boolean) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Txt(title, 17, FontWeight.Medium, P.text); Txt(sub, 14, lineHeight = 19) }
            Spacer(Modifier.width(12.dp))
            NordSwitch(on, enabled, onChange)
        }
        if (divider) HorizontalDivider(color = P.line)
    }
}

@Composable
fun ToggleCard(icon: ImageVector, title: String, sub: String, desc: String, on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    AppCard {
        CardHeader(icon, title, sub) { NordSwitch(on, enabled, onChange) }
        Spacer(Modifier.height(12.dp))
        Txt(desc, 15, lineHeight = 22)
    }
}

@Composable
fun Segmented(items: List<Pair<ImageVector, String>>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    BoxWithConstraints(Modifier.fillMaxWidth().clip(shape).background(P.tile).padding(6.dp)) {
        val w = maxWidth / items.size
        val off by animateDpAsState(w * sel, spring(dampingRatio = .75f, stiffness = 420f), label = "seg")
        val inner = RoundedCornerShape(21.dp)
        Box(
            Modifier.offset(x = off).width(w).height(74.dp)
                .shadow(10.dp, inner, ambientColor = P.accent.copy(alpha = .5f), spotColor = P.accent.copy(alpha = .5f))
                .clip(inner).background(Brush.linearGradient(listOf(P.accent, P.accent2)))
        )
        Row {
            items.forEachIndexed { i, it ->
                val tint by animateColorAsState(if (sel == i) Color.White else P.sub, label = "segc")
                Column(
                    Modifier.weight(1f).height(74.dp).clip(inner)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Icon(it.first, null, tint = tint, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(4.dp))
                    Txt(it.second, 14, FontWeight.Medium, tint)
                }
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(P.tile).padding(16.dp)) {
        Txt(label, 13)
        Spacer(Modifier.height(6.dp))
        Txt(value, 22, FontWeight.Bold, P.text, lineHeight = 27)
        Spacer(Modifier.height(4.dp))
        Txt(sub, 12, lineHeight = 16)
    }
}

@Composable
fun InfoNote(text: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(P.tile).padding(16.dp)) {
        Icon(Icons.Rounded.Info, null, tint = P.sub, modifier = Modifier.size(20.dp).padding(top = 2.dp))
        Spacer(Modifier.width(10.dp))
        Txt(text, 14, lineHeight = 21)
    }
}

@Composable
fun GradientButton(text: String, icon: ImageVector? = null, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val brush = if (enabled) Brush.linearGradient(listOf(P.accent, P.accent2)) else Brush.linearGradient(listOf(P.track, P.track))
    Row(
        modifier.fillMaxWidth()
            .shadow(if (enabled) 12.dp else 0.dp, shape, ambientColor = P.accent.copy(alpha = .5f), spotColor = P.accent.copy(alpha = .5f))
            .clip(shape).background(brush).clickable(onClick = onClick).padding(vertical = 18.dp),
        Arrangement.Center, Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)) }
        Txt(text, 17, FontWeight.SemiBold, Color.White)
    }
}

@Composable
fun SmallButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    val shape = CircleShape
    Box(
        Modifier.clip(shape)
            .then(if (filled) Modifier.background(Brush.linearGradient(listOf(P.accent, P.accent2))) else Modifier.background(P.card).border(1.dp, P.line, shape))
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp)
    ) { Txt(text, 14, FontWeight.SemiBold, if (filled) Color.White else P.text) }
}

@Composable
fun BatteryTile(icon: ImageVector, pct: Int, label: String, modifier: Modifier = Modifier) {
    val sweep by animateFloatAsState(if (pct < 0) 0f else pct / 100f, tween(900), label = "ring")
    val track = P.line; val col = P.green
    Column(modifier.clip(RoundedCornerShape(26.dp)).background(P.tile).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val st = 7.dp.toPx()
                val tl = Offset(st / 2, st / 2); val sz = Size(size.width - st, size.height - st)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(st))
                drawArc(col, -90f, 360f * sweep, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            }
            Icon(icon, null, tint = P.sub, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.height(8.dp))
        Txt(if (pct < 0) "–" else "$pct%", 18, FontWeight.Bold, P.text)
        Txt(label, 14)
    }
}

@Composable
fun Waveform(active: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val ph by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "ph")
    val c1 = P.accent; val c2 = P.accent2
    Canvas(modifier.fillMaxWidth().height(34.dp)) {
        val n = 44; val gap = size.width / n; val bw = gap * .46f
        val a = if (active) 1f else .35f
        for (i in 0 until n) {
            val h = (.22f + .78f * abs(sin(i * .55f + ph) * sin(i * .21f - ph))) * size.height * a
            drawRoundRect(
                lerp(c1, c2, i / n.toFloat()), Offset(i * gap + (gap - bw) / 2, (size.height - h) / 2),
                Size(bw, h), CornerRadius(bw / 2)
            )
        }
    }
}

@Composable
fun BudsArt(modifier: Modifier = Modifier) {
    val dark = P.dark; val green = P.green; val red = P.accent
    Canvas(modifier.fillMaxWidth().height(200.dp)) {
        val w = size.width; val h = size.height; val cx = w / 2
        val hi = if (dark) Color(0xFF4A4344) else Color.White
        val lo = if (dark) Color(0xFF2B2627) else Color(0xFFD9D1CF)
        drawOval(Color.Black.copy(alpha = if (dark) .35f else .10f), Offset(cx - 120.dp.toPx(), h - 24.dp.toPx()), Size(240.dp.toPx(), 18.dp.toPx()))
        val cw = 200.dp.toPx(); val ch = 88.dp.toPx(); val ct = h - ch - 12.dp.toPx()
        drawRoundRect(Brush.verticalGradient(listOf(hi, lo), ct, ct + ch), Offset(cx - cw / 2, ct), Size(cw, ch), CornerRadius(34.dp.toPx()))
        drawLine(lo, Offset(cx - cw / 2 + 16.dp.toPx(), ct + 30.dp.toPx()), Offset(cx + cw / 2 - 16.dp.toPx(), ct + 30.dp.toPx()), 1.5.dp.toPx())
        drawRoundRect(green, Offset(cx - 9.dp.toPx(), ct + 56.dp.toPx()), Size(18.dp.toPx(), 3.dp.toPx()), CornerRadius(2.dp.toPx()))
        for (s in listOf(-1f, 1f)) {
            val bx = cx + s * 58.dp.toPx(); val hy = 62.dp.toPx(); val r = 34.dp.toPx()
            drawRoundRect(
                Brush.verticalGradient(listOf(hi, lo), hy, ct + 6.dp.toPx()),
                Offset(bx - 10.dp.toPx(), hy), Size(20.dp.toPx(), ct + 6.dp.toPx() - hy), CornerRadius(10.dp.toPx())
            )
            drawCircle(Brush.radialGradient(listOf(hi, lo), Offset(bx - r * .3f, hy - r * .3f), r * 1.7f), r, Offset(bx, hy))
            drawCircle(red, 3.5.dp.toPx(), Offset(bx, hy + r + 12.dp.toPx()))
        }
    }
}

/** Six-band EQ: drag anywhere on the graph, the curve follows the thumbs. */
@Composable
fun EqGraph(vals: SnapshotStateList<Int>, onChange: (Int, Int) -> Unit, onDone: () -> Unit) {
    val accent = P.accent; val accent2 = P.accent2; val line = P.line; val card = P.card; val track = P.soft
    val av = vals.map { animateFloatAsState(it.toFloat(), tween(140), label = "eq").value }
    val cb by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Canvas(
        Modifier.fillMaxWidth().height(190.dp)
            .pointerInput(Unit) {
                val pad = 18.dp.toPx()
                fun band(x: Float) = (x / (size.width / 6f)).toInt().coerceIn(0, 5)
                fun v(y: Float) = (((size.height - pad - y) / (size.height - 2 * pad)) * 24f - 12f).roundToInt().coerceIn(-12, 12)
                detectTapGestures { o -> cb(band(o.x), v(o.y)); done() }
            }
            .pointerInput(Unit) {
                val pad = 18.dp.toPx()
                var sel = 0
                fun band(x: Float) = (x / (size.width / 6f)).toInt().coerceIn(0, 5)
                fun v(y: Float) = (((size.height - pad - y) / (size.height - 2 * pad)) * 24f - 12f).roundToInt().coerceIn(-12, 12)
                detectDragGestures(
                    onDragStart = { o -> sel = band(o.x); cb(sel, v(o.y)) },
                    onDragEnd = { done() }, onDragCancel = { done() }
                ) { ch, _ -> ch.consume(); cb(sel, v(ch.position.y)) }
            }
    ) {
        val w = size.width; val h = size.height; val pad = 18.dp.toPx()
        fun yOf(db: Float) = pad + (1f - (db + 12f) / 24f) * (h - 2 * pad)
        fun xOf(i: Int) = w * (i + .5f) / 6f
        for (g in listOf(12f, 6f, 0f, -6f, -12f)) {
            drawLine(line, Offset(0f, yOf(g)), Offset(w, yOf(g)), if (g == 0f) 2.dp.toPx() else 1.dp.toPx())
        }
        for (i in 0..5) drawRoundRect(track, Offset(xOf(i) - 2.dp.toPx(), pad), Size(4.dp.toPx(), h - 2 * pad), CornerRadius(2.dp.toPx()))
        val pts = buildList {
            add(Offset(0f, yOf(av[0])))
            for (i in 0..5) add(Offset(xOf(i), yOf(av[i])))
            add(Offset(w, yOf(av[5])))
        }
        fun curve(p: Path) {
            p.moveTo(pts[0].x, pts[0].y)
            for (i in 0 until pts.size - 1) {
                val mx = (pts[i].x + pts[i + 1].x) / 2f
                p.cubicTo(mx, pts[i].y, mx, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y)
            }
        }
        val stroke = Path().also { curve(it) }
        val fill = Path().also { curve(it); it.lineTo(w, h); it.lineTo(0f, h); it.close() }
        drawPath(fill, Brush.verticalGradient(listOf(accent.copy(alpha = .28f), accent.copy(alpha = 0f)), 0f, h))
        drawPath(stroke, Brush.horizontalGradient(listOf(accent, accent2)), style = Stroke(3.5.dp.toPx(), cap = StrokeCap.Round))
        for (i in 0..5) {
            val c = Offset(xOf(i), yOf(av[i]))
            drawCircle(accent.copy(alpha = .18f), 15.dp.toPx(), c)
            drawCircle(card, 9.dp.toPx(), c)
            drawCircle(accent, 9.dp.toPx(), c, style = Stroke(3.dp.toPx()))
        }
    }
}
