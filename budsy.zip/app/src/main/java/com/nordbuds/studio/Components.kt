package com.nordbuds.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color, size.sp, fontWeight = weight, textAlign = align,
    lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
    letterSpacing = spacing.sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

@Composable
fun Stack(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxWidth(), Arrangement.spacedBy(14.dp), content = content)

/** White rounded block, like the grouped lists in HeyMelody. */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(modifier.fillMaxWidth().clip(shape).background(P.card), content = content)
}

@Composable
fun SectionLabel(text: String) {
    Txt(text, 15, FontWeight.Normal, P.sub, Modifier.padding(start = 12.dp, top = 6.dp))
}

@Composable
fun Divider() = HorizontalDivider(color = P.line, modifier = Modifier.padding(horizontal = 20.dp))

/** "Title ........ Value >" row. */
@Composable
fun ValueRow(title: String, value: String, chevron: Boolean = true, divider: Boolean = true, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            Modifier.fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 20.dp, vertical = 19.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(title, 18, FontWeight.Normal, P.text, Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            Txt(value, 15, FontWeight.Normal, P.sub, Modifier.widthIn(max = 170.dp), align = TextAlign.End)
            if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = P.sub, modifier = Modifier.size(22.dp))
        }
        if (divider) Divider()
    }
}

@Composable
fun NordSwitch(on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 26.dp else 2.dp, spring(stiffness = 600f), label = "sw")
    val bg by animateColorAsState(if (on) P.accent else P.track, label = "swc")
    Box(
        Modifier.alpha(if (enabled) 1f else .5f).size(54.dp, 30.dp).clip(CircleShape).background(bg)
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { onChange(!on) },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.offset(x = x).size(26.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, on: Boolean, enabled: Boolean = true, divider: Boolean = true, onChange: (Boolean) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(title, 18, FontWeight.Normal, P.text)
                if (sub != null) Txt(sub, 14, lineHeight = 19)
            }
            Spacer(Modifier.width(12.dp))
            NordSwitch(on, enabled, onChange)
        }
        if (divider) Divider()
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(if (selected) P.accent else P.tile)
            .clickable(onClick = onClick).padding(horizontal = 30.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 18, FontWeight.Normal, if (selected) Color.White else P.text) }
}

@Composable
fun SmallButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .then(if (filled) Modifier.background(P.accent) else Modifier.background(P.tile))
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp)
    ) { Txt(text, 14, FontWeight.SemiBold, if (filled) Color.White else P.text) }
}

@Composable
fun WideButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(54.dp).clip(CircleShape)
            .background(if (filled) P.accent else P.tile).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt(text, 18, FontWeight.Medium, if (filled) Color.White else P.text) }
}

/** Three-way selector with icons (noise control). */
@Composable
fun Segmented(items: List<Pair<ImageVector, String>>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    BoxWithConstraints(Modifier.fillMaxWidth().clip(shape).background(P.tile).padding(5.dp)) {
        val w = maxWidth / items.size
        val off by animateDpAsState(w * sel.coerceAtLeast(0), spring(dampingRatio = .8f, stiffness = 500f), label = "seg")
        val inner = RoundedCornerShape(18.dp)
        if (sel >= 0) Box(Modifier.offset(x = off).width(w).height(72.dp).clip(inner).background(P.accent))
        Row {
            items.forEachIndexed { i, it ->
                val tint by animateColorAsState(if (sel == i) Color.White else P.sub, label = "segc")
                Column(
                    Modifier.weight(1f).height(72.dp).clip(inner)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Icon(it.first, null, tint = tint, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(4.dp))
                    Txt(it.second, 13, FontWeight.Medium, tint, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun BatteryTile(pct: Int, charging: Boolean, label: String, modifier: Modifier = Modifier) {
    val sweep by animateFloatAsState(if (pct < 0) 0f else pct / 100f, tween(700), label = "ring")
    val track = P.line; val col = P.green
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(P.tile).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val st = 6.dp.toPx()
                val tl = Offset(st / 2, st / 2); val sz = Size(size.width - st, size.height - st)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(st))
                drawArc(col, -90f, 360f * sweep, false, tl, sz, style = Stroke(st, cap = StrokeCap.Round))
            }
            if (charging) Icon(Icons.Rounded.Bolt, null, tint = col, modifier = Modifier.size(24.dp))
            else Txt(if (pct < 0) "–" else "$pct", 18, FontWeight.Bold, P.text)
        }
        Spacer(Modifier.height(6.dp))
        Txt(if (pct < 0) "$label  –" else "$label  $pct%", 14, color = P.sub)
    }
}

// ---------------------------------------------------------------- bottom sheet dialogs

@Composable
fun SheetDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp)
                    .clip(RoundedCornerShape(36.dp)).background(P.card)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                    .padding(horizontal = 20.dp, vertical = 22.dp),
                content = content
            )
        }
    }
}

@Composable
fun SheetTitle(text: String) {
    Txt(text, 24, FontWeight.Medium, P.text, Modifier.fillMaxWidth().padding(bottom = 10.dp), align = TextAlign.Center)
}

@Composable
fun RadioDot(selected: Boolean) {
    Box(Modifier.size(26.dp).border(if (selected) 6.dp else 2.dp, if (selected) P.accent else P.track, CircleShape))
}

@Composable
fun RadioRow(label: String, selected: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(label, 20, FontWeight.Normal, P.text, Modifier.weight(1f))
            RadioDot(selected)
        }
        if (divider) HorizontalDivider(color = P.line)
    }
}

@Composable
fun CheckBox(checked: Boolean) {
    Box(
        Modifier.size(26.dp).clip(RoundedCornerShape(7.dp))
            .background(if (checked) P.accent else Color.Transparent)
            .border(2.dp, if (checked) P.accent else P.track, RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center
    ) { if (checked) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
}

@Composable
fun CheckRow(title: String, sub: String, checked: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Txt(title, 20, FontWeight.Normal, P.text)
                Txt(sub, 15, lineHeight = 20)
            }
            Spacer(Modifier.width(10.dp))
            CheckBox(checked)
        }
        if (divider) HorizontalDivider(color = P.line)
    }
}

// ---------------------------------------------------------------- drawing

/** A stem-style earbud. The blue disc is the touch area. */
@Composable
fun BudArt(right: Boolean, height: Dp, modifier: Modifier = Modifier, touchSpot: Boolean = false) {
    val accent = P.accent
    Canvas(modifier.size(height * 0.86f, height)) {
        val s = if (right) -1f else 1f
        val w = size.width; val h = size.height; val cx = w / 2
        val headR = w * 0.31f
        val headC = Offset(cx, h * 0.30f)
        val stemW = w * 0.17f
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF3B3D43), Color(0xFF141518)), h * 0.40f, h),
            Offset(cx + s * w * 0.05f - stemW / 2, h * 0.40f), Size(stemW, h * 0.58f), CornerRadius(stemW / 2)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF5A5D64), Color(0xFF1A1B1E)), Offset(cx - s * headR * 0.35f, headC.y - headR * 0.4f), headR * 1.9f),
            headR, headC
        )
        drawCircle(Color(0xFF0E0E10), headR * 0.46f, Offset(cx - s * headR * 0.95f, headC.y + headR * 0.15f))
        if (touchSpot) drawCircle(accent.copy(alpha = .9f), headR * 0.52f, Offset(cx + s * headR * 0.08f, headC.y))
    }
}
