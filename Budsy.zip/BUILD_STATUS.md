# Budsy engineering validation status

Date: 2026-10-24

## Changes in this revision
- Restored active-state liquid-glass glow borders and status pulses.
- Added animated hero rings and a subtle floating/tilting product illustration.
- Reduced feature-tile icon scale and tightened label hierarchy for more consistent tile layouts.
- Removed the automatic ANC-Off write during connection; the app preserves the earbud-reported mode until the user changes it.
- Added a separate, guarded encoder and unit tests for the observed GATT custom-EQ `0x0418` field layout. It is not connected to a live GATT writer because service/characteristic IDs and framing/checksum remain unverified.
- Added secure-to-insecure RFCOMM fallback only for standard SPP.
- Corrected UTF-8 decoding for custom EQ profile names and peer names.

## Validation performed
- Kotlin compiler check passed for the platform-independent `Protocol.kt` source.
- Protocol smoke checks passed for frame layout, split-frame parsing, RFCOMM EQ round-trip, UTF-8 profile parsing, GATT EQ field layout/range validation, and ANC mask decoding.
- Archive integrity check passed after packaging.

## Not verified in this environment
- Full Android Gradle build / `testDebugUnitTest` / `assembleDebug`: Gradle and Android SDK are not installed in this execution environment.
- UI rendering on a physical device or emulator.
- Actual Nord Buds 3 / Nord Buds 3 Pro hardware behavior for ANC, Find My Buds, battery/case readings, firmware, or custom EQ.
- GATT `0x0418` hardware writes: do not enable until the proprietary service UUID, write characteristic UUID, transport framing, and response semantics are confirmed from a target-device capture.


## UI theme revision (2026-10-24)
- Added five selectable appearance presets in Settings: Liquid Titanium, Nothing Dot Matrix, OnePlus Aurora, Sony Studio, and Spatial 3D.
- Each preset has its own palette/accent and theme-specific vector hero treatment, header icon motion, and animated theme selector.
- Compact top bar remains fixed in the Scaffold top-bar slot.
- Replaced the static hero image with a Compose vector-rendered earbud/case illustration. Dragging moves the art in the finger direction and springs back; the product does not rotate.
- Validation limitation: a full Android Gradle build could not be run because Gradle/Android SDK are not installed in this environment. UI and touch behavior still require emulator/physical-device verification.

## UI polish pass (2026-10-24)
- Refined the pinned header with a compact theme-icon tile, subtle theme-specific motion, smaller connection status chip, and a divider for clearer separation from the scrollable page.
- Added theme-specific icon motion styles and touch bounce feedback to the five theme selector cards.
- Kept the device artwork directional-drag interaction (translation only; no product rotation).
- Kept all three battery slots stable; case battery now shows an unavailable placeholder instead of disappearing and shifting the row when the reading is unknown or the device is disconnected.
- Validation: archive structure and source changes reviewed; full Android build remains unverified because this environment has no Gradle executable or Android SDK.
