# Budsy engineering validation status

Date: 2026-10-24

## Changes in this revision
- Restored active-state liquid-glass glow borders and status pulses.
- Added animated hero rings and a subtle floating/tilting product illustration.
- Reduced feature-tile icon scale and tightened label hierarchy for more consistent tile layouts.
- Removed the automatic ANC-Off write during connection; the app preserves the earbud-reported mode until the user changes it.
- Added a separate, guarded encoder and unit tests for the observed GATT custom-EQ `0x0418` field layout. It is not connected to a live GATT writer because service/characteristic IDs and framing/checksum remain unverified.
- Added secure-to-insecure RFCOMM fallback only for standard SPP.
- Corrected UTF-8 decoding for custom EQ profile names and peer names.

## Validation performed
- Kotlin compiler check passed for the platform-independent `Protocol.kt` source.
- Protocol smoke checks passed for frame layout, split-frame parsing, RFCOMM EQ round-trip, UTF-8 profile parsing, GATT EQ field layout/range validation, and ANC mask decoding.
- Archive integrity check passed after packaging.

## Not verified in this environment
- Full Android Gradle build / `testDebugUnitTest` / `assembleDebug`: Gradle and Android SDK are not installed in this execution environment.
- UI rendering on a physical device or emulator.
- Actual Nord Buds 3 / Nord Buds 3 Pro hardware behavior for ANC, Find My Buds, battery/case readings, firmware, or custom EQ.
- GATT `0x0418` hardware writes: do not enable until the proprietary service UUID, write characteristic UUID, transport framing, and response semantics are confirmed from a target-device capture.
