# Cell BLE — Bluetooth lifecycle and GATT diagnostics

You own only:
- `app/src/main/java/com/budsy/quantum/BleManager.java`
- BLE-specific unit-test files under `app/src/test/**` (create folder if needed)

Do not edit `MainActivity.java`, layouts/drawables/styles, Gradle/workflow files, or feature capability registry.

## Task
Implement or refactor a small lifecycle-safe BLE manager for Android 8+ that supports permission-aware BLE scanning, scan timeout/cancellation, de-duplication by device identity, RSSI/device name display data, connecting to a selected device, GATT service/characteristic discovery, state/error callbacks, disconnect and close cleanup. Handle runtime permission differences for Android 12+ and older supported Android versions; never crash when Bluetooth is off, adapter/scanner is absent, permissions are denied, or callbacks arrive after cancellation.

Expose a concise documented listener/API for MainActivity integration. Do not add guessed writes to proprietary characteristics and do not claim BLE scan results are definitely earbuds until identified. Never log sensitive data unnecessarily. Use main-thread-safe callbacks or document callback threading.

## Verification
- Add focused tests for state transitions/deduplication where feasible.
- Run available tests/static checks and record exact commands/results.
- If Android SDK/Gradle is unavailable, state that explicitly; do not infer success.

## Required report
Write `.mece/cells/BLE/REPORT.md` with changed paths, public API signatures, checks/results, blockers, and session ID if available.
