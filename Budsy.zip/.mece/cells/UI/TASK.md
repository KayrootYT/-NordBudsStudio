# Cell UI — Quantum Studio interface

You own only these files:
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/drawable/**`
- `app/src/main/res/values/styles.xml`

Do not edit Java/Kotlin source, Gradle files, workflow files, or another cell's files.

## Task
Inspect the existing manifest and layout requirements, then build a polished premium UI for OnePlus Nord Buds 3 non-Pro: deep emerald/near-black surfaces, lime accents, high-quality spacing/typography, device hero, left/right/case battery cards, Sound Studio, EQ/BassWave panel, ANC/noise control panel, touch gestures, Find My Buds, Bluetooth discovery and diagnostics. Make it fit normal Android phone screens with scrollable content and clear navigation.

UI must not imply fake hardware state. Use neutral `Not connected`, `Unavailable on this firmware`, `Needs device verification`, or `Preview only` states as appropriate. Buttons must have stable IDs and a short `UI_INTEGRATION.md` documenting IDs and intended actions for the parent integrator. Do not use image placeholders as fake live readings. Respect contrast, touch target sizes, accessibility labels, and Android XML compatibility.

## Verification
- Validate XML well-formedness if tooling is available.
- Check every referenced drawable/style exists and IDs are unique.
- Do not claim APK build success unless a real build was run.

## Required report
Write `.mece/cells/UI/REPORT.md` with changed paths, checks and actual results, UI IDs/API notes, remaining blockers, and session ID if available.
