# Cell QA — reproducible build and device verification

You own only:
- `.github/workflows/**`
- `docs/qa/**`

Do not edit app source, layout/drawable/style resources, Gradle project configuration, or another cell's files.

## Task
Review the existing Android GitHub Actions workflow and make it reproducible for this Java + XML Android project. Prefer a supported JDK/Android SDK setup, deterministic Gradle invocation, useful failure logs, unit tests before assemble, and APK artifact upload only when the build succeeds. Do not add secrets or use private credentials. Do not claim build success without an actual successful workflow/build run.

Create `docs/qa/PHONE_TEST_MATRIX.md` covering Android permissions, Bluetooth off/on, scan cancel/timeout, duplicate advertisements, selecting non-earbud devices, connect/disconnect/reconnect, GATT discovery, process/background lifecycle, denied permissions, and exact-device checks for Find My Buds, ANC, EQ/BassWave, gestures, battery/case, multipoint and firmware update. Require evidence and clearly mark hardware-dependent tests.

## Verification
Run available YAML/static checks and record exact commands/results. If this environment lacks Android SDK/Gradle, state the blocker and give the exact next verification step.

## Required report
Write `.mece/cells/QA/REPORT.md` with changed paths, checks/results, workflow assumptions, blockers, and session ID if available.
