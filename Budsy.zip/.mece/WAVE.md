# Budsy MECE Wave — Fresh Build

## Goal
Build Budsy Quantum Studio for OnePlus Nord Buds 3 (non-Pro), firmware 110.110.100, using the clean Java + XML Android project in this repository. Deliver a premium dark-emerald/lime interface, reliable Bluetooth discovery/GATT diagnostics, and only verified device controls. Never fake a hardware feature as working.

## Parent conductor rules
- OpenCode is the execution worker; the parent conductor owns integration, review, and final acceptance.
- Run each cell from the project root in a separate OpenCode session.
- Cells have non-overlapping file ownership. If a task requires another cell's files, report the interface needed rather than editing those files.
- Each cell must create `.mece/cells/<CELL-ID>/REPORT.md` with changed paths, checks run, results, blockers, and session ID if available.
- A cell is not complete without a report and evidence. Do not claim build success unless a real build succeeded.
- No guessed proprietary GATT writes. Unknown protocol commands must remain disabled and clearly labelled unsupported.

## Cell ownership
| Cell | Exclusive file ownership | Goal |
|---|---|---|
| UI | `app/src/main/res/layout/activity_main.xml`, `app/src/main/res/drawable/**`, `app/src/main/res/values/styles.xml` | Premium responsive UI, accessible states, Find My Buds/gesture/ANC/EQ panels with honest availability states |
| BLE | `app/src/main/java/com/budsy/quantum/BleManager.java` and BLE-specific unit-test files only | Robust scan/connect/disconnect/GATT inventory lifecycle; expose a small documented API, do not edit MainActivity or layout |
| FEATURES | `app/src/main/java/com/budsy/quantum/FeatureStatus.java`, `FEATURE_PROTOCOL_NOTES.md` | Capability registry, protocol evidence requirements, safe feature availability state; no writes to unknown characteristics |
| QA | `.github/workflows/**`, `docs/qa/**` | Build/test workflow, static checks, phone verification matrix; do not edit app source |

## Integration sequence
1. Execute UI, BLE, FEATURES, and QA cells independently.
2. Parent reviews each REPORT and reconciles API/interface needs.
3. Parent integrates `MainActivity.java` with the UI and `BleManager`/`FeatureStatus` APIs. Only parent edits MainActivity during integration.
4. Run Gradle build and tests in a suitable Android SDK environment. Fix failures and repeat until verified or a clearly documented environment blocker remains.
5. Validate on the actual Nord Buds 3 hardware. Proprietary controls require captured, repeatable evidence from the exact model/firmware.

## Definition of done
- All four reports exist and list real evidence.
- UI screens are reachable and states are accessible.
- BLE scanning, connection cleanup, service discovery, and errors are tested.
- No mock data is represented as live device data.
- Gradle build/test results are recorded honestly.
- Find My Buds, ANC, EQ/BassWave and gesture remapping are marked supported only after exact-device protocol verification.
