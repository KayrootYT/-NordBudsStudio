# Budsy repair audit — 2026-10-21

## Changes made in this pass
- Replaced the Home connect action that incorrectly called `Buds.scanFlags()` with a paired-device picker.
- Added runtime permission requests for Bluetooth access (Android 12+) and location permission on older Android versions.
- The picker lists paired OnePlus/Nord Buds and uses the existing `Buds.connect(BluetoothDevice)` entry point.
- Corrected touch gesture side IDs to left=1/right=2 and gesture IDs to 1–4.
- Updated the manual EQ editor to six frequency bands matching the existing device-side EQ profile shape and calls the existing `Buds.writeCustomEq` API.
- Kept unknown battery values as an em dash rather than inventing percentages.

## Important unresolved issue
- The current `buds/Link.kt` implementation uses Classic Bluetooth RFCOMM sockets. The user's reverse-engineering notes describe a BLE/GATT transport. These are not interchangeable. The archive does not contain verified BLE service/characteristic UUIDs and a confirmed GATT packet transport implementation, so real OnePlus Nord Buds 3 connection cannot honestly be declared fixed by this pass.
- Android build could not run in this environment because Gradle wrapper distribution download failed (`UnknownHostException: services.gradle.org`). ZIP integrity can be checked, but Kotlin compilation and device tests remain unverified.
