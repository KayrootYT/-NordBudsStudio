# Nord Buds Studio (native Android)
Kotlin + Jetpack Compose controller for OnePlus Nord Buds 3. Talks to the buds over Bluetooth RFCOMM using the HeyMelody protocol.

Tabs (same layout as HeyMelody): **Device**, **Earbud controls**, **About**.

- Device: battery (L / R / case), noise control, sound effect (EQ preset), BassWave switch + level, game mode.
- Earbud controls: single / double / triple tap, touch and hold (noise modes to cycle), long touch and hold (volume), per earbud. Every change is written to the buds and read back to confirm.
- About: device info, raw gesture table and protocol log (use Copy and send it if something does not match HeyMelody).

Also: **Find my earbuds** (Left / Right / Both), in ear / in case status, firmware version, devices connected to the buds, saved custom EQ (read only), and a **feature flag scanner** in Settings -> Diagnostics for locating switches such as ear detection and dual connection.

Every control talks to the buds. There is no demo or preview data. Nothing is shown unless the buds are connected.

## Build
1. Push everything to a GitHub repo (`main`). Keep `.github/workflows/build-apk.yml`.
2. Actions tab -> Build APK -> Run workflow. Download artifact `Budsy-apk`.
3. Pair the buds in phone Bluetooth settings, force-stop HeyMelody, open the app. It reconnects to the last buds by itself.

Protocol notes and command ids are at the top of `Buds.kt`.
