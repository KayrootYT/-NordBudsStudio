# Nord Buds Studio (native Android)
Kotlin + Jetpack Compose controller for OnePlus Nord Buds 3. Talks to the buds over Bluetooth RFCOMM using the HeyMelody protocol.

Tabs (same layout as HeyMelody): **Device**, **Earbud controls**, **About**.

- Device: battery (L / R / case), noise control, sound effect (EQ preset), BassWave switch + level, game mode.
- Earbud controls: single / double / triple tap, touch and hold (noise modes to cycle), long touch and hold (volume), per earbud. Every change is written to the buds and read back to confirm.
- About: device info, raw gesture table and protocol log (use Copy and send it if something does not match HeyMelody).

Also: **Find my earbuds** (Left / Right / Both), in ear / in case status, firmware version, devices connected to the buds, saved custom EQ (read only), and a **feature flag scanner** in Settings -> Diagnostics for locating switches such as ear detection and dual connection.

Every control talks to the buds. There is no demo or preview data. Nothing is shown unless the buds are connected.

## Build
1. Push everything to a GitHub repo (`main`). Keep `.github/workflows/build-apk.yml`.
2. Actions tab -> Build APK -> Run workflow. Download artifact `Budsy-apk`.
3. Pair the buds in phone Bluetooth settings, force-stop HeyMelody, open the app. It reconnects to the last buds by itself.

Protocol notes and command ids are at the top of `Buds.kt`.

## UI update (2026-10-18)
- Noise Control is requested to switch to Off when a new earbud control connection is established.
- Expanded the colour palette to Aurora, Ocean, Cosmic, Sunset, and Emerald.
- Enhanced theme swatches with animated scale/ring transitions and gradient colour chips.
- Increased the number of drifting aurora particles and slightly shortened the background animation cycle.

Note: device-level Noise Control switching depends on the earbud firmware accepting the proprietary command. Verify on the target Nord Buds 3 firmware; a source change alone is not proof of hardware behaviour.


## October 2026 reliability fixes (source updated; hardware/build verification pending)

- Touch & Hold writes now stay in a Saving state until the device-reported mask matches the requested mask; rejected, mismatched, and timed-out writes are surfaced instead of being presented as successful.
- ANC selection now has Saving/Saved/Failed feedback and requests a read-back before claiming confirmation. The connection flow still requests Noise Control Off after initial queries.
- Find My Buds now exposes Play again and Pause / Stop controls. The zero-target stop packet is explicitly marked experimental until verified on Nord Buds 3 firmware 110.110.100.
- RFCOMM reader threads use connection-generation tokens to prevent an old reader from dropping a newly reconnected session. The Overview separately warns when control is connected but A2DP/HFP audio is not routed to the earbuds.
- Hold selection no longer resets on every asynchronous device mask update while the user is editing; the initial confirmed mask is loaded until the user changes a selection.
- Tab changes now use animated fade/slide transitions. The GitHub Actions build runs unit tests before producing the debug APK and checks that the APK exists.
- Hardware command verification and Android APK compilation remain outstanding; do not treat the experimental Find-device stop payload as confirmed.

### Paired control + audio connection behavior

On startup, Budsy continues to auto-connect its reverse-engineered control channel to the saved paired earbuds. It also monitors Android's public A2DP/HFP profile state. If the control channel connects but the system audio profile does not, Budsy now shows a one-time `Finish connecting Nord Buds 3` prompt with a `Connect audio` action that opens Android Bluetooth settings. Enable `Media audio` there if needed; the app will reflect the system-reported profile state when it returns.

Android's public SDK does not expose a supported API for third-party apps to force-connect or force-disconnect system-managed A2DP/HFP profiles. Therefore this flow intentionally does not fake an automatic audio connection. A truly silent one-tap connection like an OEM companion app may require privileged/OEM APIs or a supported earbud mechanism.

## Nord Buds Studio reference UI port

The Android Compose project includes a native adaptation of the Nord Buds Studio visual reference: dark space/cyberpunk glass cards, connection slots clearly marked as mock UI, Game Mode and preference preview switches, published protection/design specs, and a searchable feature/specification list in Settings. The Sound and Controls tabs retain the app's native controls and explicitly label preview-only features. This is a visual/UI port into the Android project, not a copy of the React web source, and preview-only switches do not claim to change proprietary earbud firmware.

## Custom Spatial EQ profiles

The Sound Studio now includes a compact 10-band vertical EQ card with Music, Movie, Game and Podcast curves. Drag each knob vertically to edit a band. Editing a preset switches to a Custom curve so the built-in preset is not overwritten. Named custom profiles are persisted locally in SharedPreferences and can be reloaded from the saved-profile chips. `Apply to earbuds` sends the named frequency/gain curve through the existing custom-EQ protocol command when a Budsy control connection is active. Hardware acceptance depends on the Nord Buds 3 firmware and must be verified on-device; the app does not claim that Dolby Atmos itself is activated by this EQ card.


## Premium iOS visual pass (2026-10-20)

- Replaced the static-looking hero treatment with locally drawn animated Compose vector artwork. No remote or stock product photo is required.
- Added tab-specific animated hero art: floating earbuds and case on Overview, audio-field rings/waveform in Sound, touch-target rings in Controls, and a rotating system ring in Settings.
- Made the premium iOS-inspired visual style the default for new installs, with a warm orange accent and neutral system surfaces. Existing saved appearance choices are preserved.
- Simplified the top bar into Budsy Studio branding and an honest connection-status pill; removed decorative header icons that looked actionable but did nothing.
- Kept the existing Bluetooth control stack and EQ persistence implementation. The 10-band EQ remains a compact vertical touch-drag control with named local profiles.

Validation note: source-level changes were made in this archive. An Android Gradle build and device/hardware test could not be run in this environment, so compilation and real animation performance still need CI/device verification. The animated hero is vector/Canvas-based 2.5D artwork, not a physically rendered 3D model.
