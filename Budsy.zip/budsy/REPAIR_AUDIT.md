# Merge audit

- Kept the uploaded source's modular premium UI screens and components (`PremiumHomeScreen.kt`, `PremiumNoiseControlScreen.kt`, `Components.kt`, `Screens.kt`, `State.kt`, `Theme.kt`).
- Kept the shared app logic, resources, manifest, Gradle configuration, widget/service code, and existing protocol tests.
- Replaced the Classic RFCOMM `Link.kt` with the GATT candidate transport from the newer archive.
- Added serialized GATT characteristic writes: only one write is in flight, and the next queued write begins from `onCharacteristicWrite`.
- Used the parser version that supports resetting buffered bytes on reconnect.
- Updated transport documentation so it no longer claims the current build uses RFCOMM.

## Verification limits

- ZIP integrity and Android manifest XML are checked.
- Gradle build could not run in this environment: Gradle 8.9 is not cached and the wrapper cannot reach `services.gradle.org` due unavailable network/DNS.
- No APK was produced. No physical Vivo T4x / OnePlus Nord Buds 3 connection test was performed.
- GATT UUIDs and wire frame format remain candidates from APK inspection and must be confirmed from actual GATT traffic. UI availability does not imply all hardware features work.
