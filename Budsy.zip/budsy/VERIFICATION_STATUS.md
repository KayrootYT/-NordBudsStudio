# Budsy verification status

Target device: OnePlus Nord Buds 3 (non-Pro), firmware reported by user as 110.110.100.

## Changes in this revision
- `SheetDialog` uses a non-filling scroll-content weight so short HeyMelody-style dialogs wrap their content instead of expanding to almost the full screen; long content remains scrollable and the footer stays visible.
- Overview opens with the in-app device list visible and starts classic Bluetooth discovery. The device list remains available even while the Budsy control channel is connected, so users can scan/select devices without leaving Overview. Nearby devices are listed alongside paired devices; unpaired devices offer Android pairing, and paired devices can open Budsy's control channel from the app.
- Added the Android 12+ `BLUETOOTH_SCAN` permission and request it together with `BLUETOOTH_CONNECT`.
- The disconnect button now closes Budsy's proprietary control channel without automatically sending the user to Bluetooth Settings.

## Important platform / firmware limitations
- Android's public SDK does not provide ordinary apps a supported API to force-disconnect or force-connect the system-managed A2DP/HFP audio profiles. Therefore the in-app disconnect closes Budsy's control link but cannot guarantee that Android's media/call audio link is disconnected. Do not label it as a full Bluetooth disconnect.
- Custom EQ is sent through the reverse-engineered Nord Buds protocol and verified by read-back. The currently reported firmware has not returned a matching custom-EQ confirmation, so actual earbud-side custom EQ remains unverified; a UI-only success would be misleading. This revision does not fabricate protocol support.
- Classic Bluetooth discovery can show nearby discoverable devices. Devices may need to be in pairing mode; pairing is handled by Android's system pairing flow.

## Checks completed in this environment
- Android manifest XML parsed successfully.
- Source-level edits reviewed.
- Overview device scanning list is now shown while the Budsy control channel is connected as well as disconnected.

## Not verified
- Full Android Gradle build: not run because this project copy has no Gradle wrapper and no Android SDK configured in this environment.
- Unit tests, installation, UI rendering, Bluetooth scan/pair/connect/disconnect, custom EQ read-back, and audio routing on a physical Nord Buds 3 have not been tested here.

## Premium theme and animation settings update
- Expanded theme palette choices to Aurora, Ocean, Cosmic, Fusion, Emerald, Titanium, Prism, Sunset, and Ice.
- Added persisted animation intensity preference: Smooth, Cinematic, and Extreme.
- Wired animation intensity into the app theme and animated icon tile breathing/glow amplitude and timing.
- Added the animation intensity selector beneath the palette selector in Settings.
- Compact sheet dialog layout retains a medium maximum height (72% of available screen height) and scrolls long content.

## Current verification for this update
- Reviewed Kotlin source structure and confirmed balanced braces in modified files.
- Gradle build could not be run in this environment because no Gradle wrapper/system Gradle or Android SDK is available. Physical-device runtime behavior remains unverified.


## Premium redesign delivery update (2026-10-20)
- Added `PremiumHomeScreen.kt` as the new native Compose dashboard and routed the first tab to it.
- Added `PremiumNoiseControlScreen.kt` as a dedicated animated noise-mode screen using the existing ANC protocol methods.
- Expanded bottom navigation to five destinations: Device, Sound, Noise, Controls, Settings.
- Build remains unverified: this environment has no usable Gradle/Android SDK setup. No APK is included or claimed.


## Premium redesign checks (2026-10-20)
- Android manifest parsed successfully with Python's XML parser.
- Source-level navigation checks passed for Home, Sound, Noise Control, Touch Controls, and Settings.
- Noise Control mode selection is wired to the existing `Buds.setAnc(mode)` method; this confirms source wiring only, not successful hardware behavior.
- Build and emulator/device verification were not run because this environment has no available Gradle executable or wrapper and no configured Android SDK. No APK was produced.

- UI refinement pass: Controls header now says "Touch & Gestures" and Settings header says "Device & Preferences". These are source edits only; compile verification is still blocked by missing build tooling.


## Final source polish pass
- Added animated selected-state transitions for Sound Studio EQ presets and Noise Control mode cards.
- Kotlin parser check across project `.kt` sources returned no syntax/parse diagnostics. The check is not a successful app compile because Android/Compose dependencies are unavailable to standalone `kotlinc`.
- Android Manifest XML parses; navigation checks confirm Home, Sound, Noise Control, Touch Controls, and Settings are wired.
- Gradle build/APK/device testing remains unverified due missing Android SDK/Gradle and unavailable network access in this environment.


## Compact UI pass (2026-10-21)
- Source updates made for compact Touch Controls and Sound Master EQ screens.
- Gradle test/build attempt failed before configuration because the wrapper could not download Gradle 8.9 (`UnknownHostException: services.gradle.org`); compilation, unit tests, APK generation, and device behavior remain unverified.
