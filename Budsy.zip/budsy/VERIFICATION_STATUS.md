# Budsy verification status

Target device: OnePlus Nord Buds 3 (non-Pro), firmware reported by user as 110.110.100.

## Checks completed in this environment
- `Protocol.kt` compiled independently with Kotlin/JVM compiler.
- Seven protocol smoke checks passed: frame layout, split-frame parsing, battery parsing, custom-EQ payload round-trip, gesture-table parsing, and ANC-mask decoding.
- All Android XML resource files parsed successfully.
- Lightweight delimiter checks passed for the main Kotlin source files.
- Source includes unit tests in `app/src/test/java/com/nordbuds/studio/ProtocolTest.kt`.

## Not verified here
- Full Android Gradle build: not run because this project copy has no Gradle wrapper and no Android SDK configured in the environment.
- JUnit/Gradle test task: not run.
- Installation, UI rendering, BLE writes, EQ/gesture read-back, and audio routing on a physical Nord Buds 3: not tested here.

## Feature truthfulness
- Custom EQ profiles saved in Budsy are local app profiles. Applying the custom curve requires compatible firmware/protocol support; the app checks read-back and reports when confirmation is missing.
- Features marked `preview`/`mock` in Settings are UI-only and are not represented as working earbud controls.
- The Spatial Sound EQ UI is not a claim that Android Dolby Atmos is installed or that a system Atmos engine is controlled.
