# Budsy verification status

Target device: OnePlus Nord Buds 3 (non-Pro), firmware reported by user as 110.110.100.

## Changes in this revision
- `SheetDialog` uses a non-filling scroll-content weight so short HeyMelody-style dialogs wrap their content instead of expanding to almost the full screen; long content remains scrollable and the footer stays visible.
- Overview opens with the in-app device list visible and starts classic Bluetooth discovery. Nearby devices are listed alongside paired devices; unpaired devices offer Android pairing, and paired devices can open Budsy's control channel from the app.
- Added the Android 12+ `BLUETOOTH_SCAN` permission and request it together with `BLUETOOTH_CONNECT`.
- The disconnect button now closes Budsy's proprietary control channel without automatically sending the user to Bluetooth Settings.

## Important platform / firmware limitations
- Android's public SDK does not provide ordinary apps a supported API to force-disconnect or force-connect the system-managed A2DP/HFP audio profiles. Therefore the in-app disconnect closes Budsy's control link but cannot guarantee that Android's media/call audio link is disconnected. Do not label it as a full Bluetooth disconnect.
- Custom EQ is sent through the reverse-engineered Nord Buds protocol and verified by read-back. The currently reported firmware has not returned a matching custom-EQ confirmation, so actual earbud-side custom EQ remains unverified; a UI-only success would be misleading. This revision does not fabricate protocol support.
- Classic Bluetooth discovery can show nearby discoverable devices. Devices may need to be in pairing mode; pairing is handled by Android's system pairing flow.

## Checks completed in this environment
- Android manifest XML parsed successfully.
- Source-level edits reviewed.

## Not verified
- Full Android Gradle build: not run because this project copy has no Gradle wrapper and no Android SDK configured in this environment.
- Unit tests, installation, UI rendering, Bluetooth scan/pair/connect/disconnect, custom EQ read-back, and audio routing on a physical Nord Buds 3 have not been tested here.
