package com.nordbuds.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class NoiseMode(val mode: Int, val title: String, val desc: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun PremiumNoiseControlScreen(x: Ctx) {
    val b = x.b
    val connected = b.connected
    val active = b.ancMode
    val transition = rememberInfiniteTransition(label = "noisePulse")
    val pulse by transition.animateFloat(initialValue = 0.86f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val activeColor = when (active) {
        Buds.ANC_ON -> P.accent
        Buds.ANC_TRANSP -> P.green
        else -> P.sub
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 104.dp)) {
        Spacer(Modifier.height(4.dp))
        Text("Noise control", color = P.text, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("Shape the world around you.", color = P.sub, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.card).border(1.dp, P.line, RoundedCornerShape(16.dp)).padding(vertical = 7.dp, horizontal = 10.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val c = Offset(size.width/2, size.height/2)
                        val base = size.minDimension * .29f
                        drawCircle(activeColor.copy(alpha=.055f), radius=base*1.65f*pulse, center=c)
                        drawCircle(activeColor.copy(alpha=.075f), radius=base*1.36f*pulse, center=c)
                        drawCircle(activeColor.copy(alpha=.14f), radius=base*1.08f, center=c, style=androidx.compose.ui.graphics.drawscope.Stroke(width=1.5.dp.toPx()))
                        drawArc(Brush.sweepGradient(listOf(activeColor.copy(alpha=.05f), activeColor, activeColor.copy(alpha=.25f))), startAngle=-90f, sweepAngle=270f, useCenter=false, topLeft=Offset(c.x-base*1.08f,c.y-base*1.08f), size=androidx.compose.ui.geometry.Size(base*2.16f,base*2.16f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3.dp.toPx(), cap=StrokeCap.Round))
                    }
                    Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(P.soft, P.card))).border(1.dp, activeColor.copy(alpha=.45f), CircleShape), contentAlignment=Alignment.Center) {
                        androidx.compose.material3.Icon(when(active) { Buds.ANC_ON -> Icons.Rounded.GraphicEq; Buds.ANC_TRANSP -> Icons.Rounded.Hearing; else -> Icons.Rounded.Block }, null, tint=activeColor, modifier=Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(when(active) { Buds.ANC_ON -> "Noise cancelling"; Buds.ANC_TRANSP -> "Transparency"; Buds.ANC_OFF -> "Noise control off"; else -> "Choose a mode" }, color=P.text, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text(if (connected) "Changes are sent to your earbuds" else "Connect your earbuds to control noise", color=P.sub, style=MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("LISTENING MODE", color=P.sub, style=MaterialTheme.typography.labelSmall, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        val modes = listOf(
            NoiseMode(Buds.ANC_ON, "Noise cancelling", "Reduce surrounding sounds", Icons.Rounded.GraphicEq),
            NoiseMode(Buds.ANC_TRANSP, "Transparency", "Let the outside world in", Icons.Rounded.Hearing),
            NoiseMode(Buds.ANC_OFF, "Normal", "Hear audio without processing", Icons.Rounded.Block)
        )
        modes.forEach { item ->
            val mode = item.mode
            val title = item.title
            val desc = item.desc
            val icon = item.icon
            val selected = active == mode
            val color = when(mode) { Buds.ANC_ON -> P.accent; Buds.ANC_TRANSP -> P.green; else -> P.sub }
            val tileColor by animateColorAsState(if (selected) color.copy(alpha = .12f) else P.card, tween(220), label = "noiseTile-$mode")
            val iconScale by transition.animateFloat(
                initialValue = 1f, targetValue = 1.08f,
                animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "noiseIcon-$mode"
            )
            Row(Modifier.fillMaxWidth().padding(bottom=6.dp).clip(RoundedCornerShape(12.dp)).background(tileColor).border(1.dp, if(selected) color.copy(alpha=.65f) else P.line, RoundedCornerShape(12.dp)).clickable { if (connected) b.setAnc(mode) else x.toast("Connect your earbuds first") }.padding(horizontal=9.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(color.copy(alpha=.13f)), contentAlignment=Alignment.Center) { Icon(icon, null, tint=color, modifier=Modifier.size(18.dp).graphicsLayer { scaleX = if (selected) iconScale else 1f; scaleY = if (selected) iconScale else 1f }) }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color=P.text, style=MaterialTheme.typography.titleSmall, fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.height(3.dp))
                    Text(desc, color=P.sub, style=MaterialTheme.typography.bodySmall)
                }
                if (selected) Icon(Icons.Rounded.CheckCircle, contentDescription="Selected", tint=color, modifier=Modifier.size(22.dp))
            }
        }
        if (b.ancSaveState != Buds.SaveState.IDLE && b.ancSaveMessage.isNotBlank()) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(P.card).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(if (b.ancSaveState == Buds.SaveState.FAILED) Icons.Rounded.Info else Icons.Rounded.CheckCircle, null, tint=if(b.ancSaveState == Buds.SaveState.FAILED) P.amber else P.green, modifier=Modifier.size(18.dp))
                Spacer(Modifier.width(9.dp)); Text(b.ancSaveMessage, color=P.sub, style=MaterialTheme.typography.bodySmall)
            }
        }
    }
}
