package com.nordbuds.studio.protocol

import java.io.ByteArrayOutputStream

/**
 * Reverse-engineered OPPO/OnePlus earbud control protocol.
 *
 * Frame: AA | length16 LE (= 7 + payload length) | reserved | command-low |
 * command-group | sequence | payload-length16 LE | payload bytes.
 * Group 0x01 is query, 0x02 is unsolicited push, and 0x04 is set. Replies
 * set bit 7 of the group byte (for example 0x0106 -> group 0x81).
 *
 * Commands observed in this implementation: 0x0105 firmware, 0x0106 battery,
 * 0x0108 gesture table, 0x0109 wear state, 0x010C noise/hold modes,
 * 0x010D feature flags, 0x010F EQ preset, 0x0112 peers, 0x0122 custom EQ,
 * 0x0124 BassWave; writes 0x0401 gesture, 0x0403 flag, 0x0404 ANC/hold,
 * 0x0406 preset, 0x041B BassWave, 0x0422 custom EQ.
 *
 * Gesture entry: [side, 0x01, gestureId, functionId], side 1=left, 2=right.
 * This protocol is reverse engineered and has not been verified on every firmware.
 */
object Protocol {
    const val GRP_QUERY = 0x01
    const val GRP_PUSH = 0x02
    const val GRP_SET = 0x04
    const val ANC_OFF = 0
    const val ANC_ON = 1
    const val ANC_TRANSP = 2
    val FEATURE_REQUEST = intArrayOf(7, 0x06, 0x05, 0x0b, 0x11, 0x1b, 0x1d, 0x20)

    data class Frame(val lo: Int, val hi: Int, val seq: Int, val payload: IntArray) {
        val cmd: Int get() = ((hi and 0x7f) shl 8) or lo
        val status: Int get() = payload.firstOrNull() ?: -1
        val isPush: Boolean get() = (hi and 0x7f) == GRP_PUSH
    }
    data class Battery(val slot: Int, val percent: Int, val charging: Boolean)
    data class Wear(val slot: Int, val flags: Int)
    data class Peer(val mac: String, val name: String)
    data class CustomEqProfile(val name: String, val active: Boolean, val bands: List<Pair<Int, Int>>, val minDb: Int = -6, val maxDb: Int = 6, val eqId: Int = 0)

    fun hex(v: Int) = (v and 0xff).toString(16).padStart(2, '0')

    /**
     * RFCOMM packet: AA | length16 LE (= 7 + payload size) | 00 | key u16 LE (cmd low, group) | seq u8 |
     * payload size u16 LE | payload.
     */
    fun buildFrame(cmd: Int, group: Int, seq: Int, payload: IntArray): ByteArray {
        val n = payload.size
        val out = ByteArray(9 + n)
        out[0] = 0xAA.toByte()
        out[1] = ((7 + n) and 0xff).toByte(); out[2] = (((7 + n) ushr 8) and 0xff).toByte()
        out[3] = 0
        out[4] = (cmd and 0xff).toByte(); out[5] = (group and 0xff).toByte()
        out[6] = (seq and 0xff).toByte()
        out[7] = (n and 0xff).toByte(); out[8] = ((n ushr 8) and 0xff).toByte()
        payload.forEachIndexed { i, v -> out[9 + i] = v.toByte() }
        return out
    }

    /** Re-assembles frames from the RFCOMM byte stream: resyncs on 0xAA and drops corrupt frames. */
    class Parser {
        private var buffer = ByteArray(0)
        fun feed(bytes: ByteArray, length: Int = bytes.size): List<Frame> {
            if (length > 0) buffer += bytes.copyOfRange(0, length)
            val out = ArrayList<Frame>()
            while (true) {
                val start = buffer.indexOfFirst { it == 0xAA.toByte() }
                if (start < 0) { buffer = ByteArray(0); break }
                if (start > 0) buffer = buffer.copyOfRange(start, buffer.size)
                if (buffer.size < 9) break
                val len = (buffer[1].toInt() and 0xff) or ((buffer[2].toInt() and 0xff) shl 8)
                val payloadLen = (buffer[7].toInt() and 0xff) or ((buffer[8].toInt() and 0xff) shl 8)
                if (len < 7 || len > 4103 || payloadLen != len - 7) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val total = len + 2
                if (buffer.size < total) break
                val payload = IntArray(payloadLen) { buffer[9 + it].toInt() and 0xff }
                out += Frame(buffer[4].toInt() and 0xff, buffer[5].toInt() and 0xff, buffer[6].toInt() and 0xff, payload)
                buffer = buffer.copyOfRange(total, buffer.size)
            }
            return out
        }
    }

    fun parseBattery(p: IntArray): List<Battery> {
        if (p.size < 2) return emptyList()
        val count = p[1].coerceAtMost(20); val out = ArrayList<Battery>()
        repeat(count) { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size && p[j] in 1..3) {
                val raw = p[j + 1]; val pct = raw and 0x7f
                out += Battery(p[j] - 1, if (pct <= 100) pct else -1, raw and 0x80 != 0)
            }
        }
        return out
    }
    fun parseWear(p: IntArray): List<Wear> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(20)).mapNotNull { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size && p[j] in 1..3) Wear(p[j] - 1, p[j + 1]) else null
        }
    }
    fun parseFirmware(p: IntArray): String? = p.drop(2).mapNotNull { it.takeIf { c -> c in 32..126 }?.toChar() }.joinToString("").trim().ifEmpty { null }
    fun parseGestureTable(p: IntArray): Map<Int, Int> {
        if (p.size < 2) return emptyMap()
        val count = p[1].coerceAtMost(64); val out = linkedMapOf<Int, Int>()
        repeat(count) { i ->
            val j = 2 + i * 4
            if (j + 3 < p.size) {
                val side = p[j]; val enabled = p[j + 1]; val gid = p[j + 2]; val fn = p[j + 3]
                if (enabled != 0 && side in 1..2) out[side * 16 + gid] = fn
            }
        }
        return out
    }
    fun parseFlags(p: IntArray): List<Pair<Int, Int>> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(128)).mapNotNull { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size) p[j] to p[j + 1] else null
        }
    }
    fun parsePeers(p: IntArray): List<Peer> {
        if (p.size < 2) return emptyList()
        val out = ArrayList<Peer>(); var i = 2
        repeat(p[1].coerceAtMost(8)) {
            if (i + 9 > p.size) return@repeat
            val mac = (0..5).joinToString(":") { hex(p[i + it]).uppercase() }
            val nameLen = p[i + 9]; if (i + 10 + nameLen > p.size) return@repeat
            val name = p.slice(i + 10 until i + 10 + nameLen).map { it.toChar() }.joinToString("")
            out += Peer(mac, name); i += 10 + nameLen
        }
        return out
    }
    fun decodeAnc(mask: Int): Int = when {
        (mask and 0x0300) != 0 -> ANC_TRANSP
        (mask and 0x08F2) != 0 -> ANC_ON
        (mask and 0x0008) != 0 -> ANC_OFF
        else -> -1
    }
    /** Response payload includes status at p[0], then entry count at p[1]. */
    fun parseCustomEq(p: IntArray): List<CustomEqProfile> {
        if (p.size < 2) return emptyList()
        val out = ArrayList<CustomEqProfile>(); var i = 2
        repeat(p[1].coerceAtMost(32)) {
            if (i + 5 > p.size) return out
            val selected = p[i] != 0
            val mn = p[i + 1].toByte().toInt(); val mx = p[i + 2].toByte().toInt()
            val id = p[i + 3]; val nameLen = p[i + 4]; i += 5
            if (nameLen < 0 || i + nameLen >= p.size) return out
            val name = p.slice(i until i + nameLen).map { it.toChar() }.joinToString(""); i += nameLen
            if (i >= p.size) return out
            val count = p[i++].coerceAtMost(32)
            if (i + count * 3 > p.size) return out
            val bands = ArrayList<Pair<Int, Int>>()
            repeat(count) { bands += ((p[i] or (p[i + 1] shl 8)) to p[i + 2].toByte().toInt()); i += 3 }
            out += CustomEqProfile(name, selected, bands, mn, mx, id)
        }
        return out
    }

    /** HeyMelody 0x0418 payload: action,min,max,id,nameLen,name,N,[freqLE16,gainS8]*N. */
    fun buildCustomEqPayload(action: Int, eqId: Int, name: String, bands: List<Pair<Int, Int>>, min: Int = -6, max: Int = 6): IntArray {
        require(bands.isNotEmpty()) { "EQ bands cannot be empty" }
        val nameBytes = name.toByteArray(Charsets.UTF_8).map { it.toInt() and 0xff }
        require(nameBytes.size <= 255 && bands.size <= 255) { "EQ payload too large" }
        val out = ArrayList<Int>()
        out += action and 0xff; out += min.toByte().toInt() and 0xff; out += max.toByte().toInt() and 0xff
        out += eqId and 0xff; out += nameBytes.size; out.addAll(nameBytes); out += bands.size
        bands.forEach { (hz, gain) -> out += hz and 0xff; out += (hz ushr 8) and 0xff; out += gain.toByte().toInt() and 0xff }
        return out.toIntArray()
    }


    const val CMD_FIND_EARBUDS = 0x0400
    /** Find / ring payload: [count, side ids...] with side 1 = left, 2 = right. Unverified on Nord Buds 3 firmware. */
    fun findPayload(side: Int): IntArray = when (side) { 1 -> intArrayOf(1, 1); 2 -> intArrayOf(1, 2); else -> intArrayOf(2, 1, 2) }
    /** Zero targets stops the tone (inferred from the list encoding, unverified). */
    fun findStopPayload(): IntArray = intArrayOf(0)

}
