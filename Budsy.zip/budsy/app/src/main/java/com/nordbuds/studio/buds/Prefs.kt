package com.nordbuds.studio.buds

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("budsy", Context.MODE_PRIVATE)
    var autoPaused: Boolean get() = p.getBoolean("auto_paused", false); set(v) { p.edit().putBoolean("auto_paused", v).apply() }
    var customName: String? get() = p.getString("custom_name", null); set(v) { p.edit().putString("custom_name", v).apply() }
    var lastAddr: String? get() = p.getString("last_addr", null); set(v) { p.edit().putString("last_addr", v).apply() }
    var themeMode: Int get() = p.getInt("theme_mode", 0); set(v) { p.edit().putInt("theme_mode", v).apply() }
    var accent: Int get() = p.getInt("accent", 0).coerceIn(0, 4); set(v) { p.edit().putInt("accent", v.coerceIn(0, 4)).apply() }
    /** 0 = Space, 1 = Cyberpunk. */
    var visualStyle: Int get() = p.getInt("visual_style", 0).coerceIn(0, 1); set(v) { p.edit().putInt("visual_style", v.coerceIn(0, 1)).apply() }
    var amoled: Boolean get() = p.getBoolean("amoled", false); set(v) { p.edit().putBoolean("amoled", v).apply() }
    var welcomed: Boolean get() = p.getBoolean("welcomed", false); set(v) { p.edit().putBoolean("welcomed", v).apply() }
    var diag: Boolean get() = p.getBoolean("diag", false); set(v) { p.edit().putBoolean("diag", v).apply() }
    var batteryNotif: Boolean get() = p.getBoolean("battery_notif", false); set(v) { p.edit().putBoolean("battery_notif", v).apply() }
}
