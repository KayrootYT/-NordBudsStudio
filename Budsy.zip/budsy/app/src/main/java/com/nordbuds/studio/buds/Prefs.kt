package com.nordbuds.studio.buds

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("budsy", Context.MODE_PRIVATE)
    var autoPaused: Boolean get() = p.getBoolean("auto_paused", false); set(v) { p.edit().putBoolean("auto_paused", v).apply() }
    var customName: String? get() = p.getString("custom_name", null); set(v) { p.edit().putString("custom_name", v).apply() }
    var lastAddr: String? get() = p.getString("last_addr", null); set(v) { p.edit().putString("last_addr", v).apply() }
    var themeMode: Int get() = p.getInt("theme_mode", 0); set(v) { p.edit().putInt("theme_mode", v).apply() }
    var accent: Int get() = p.getInt("accent", 3).coerceIn(0, 4); set(v) { p.edit().putInt("accent", v.coerceIn(0, 4)).apply() }
    /** 0 = Classic, 1 = Premium iOS. */
    var visualStyle: Int get() = p.getInt("visual_style", 1).coerceIn(0, 1); set(v) { p.edit().putInt("visual_style", v.coerceIn(0, 1)).apply() }
    var amoled: Boolean get() = p.getBoolean("amoled", false); set(v) { p.edit().putBoolean("amoled", v).apply() }
    var welcomed: Boolean get() = p.getBoolean("welcomed", false); set(v) { p.edit().putBoolean("welcomed", v).apply() }
    var diag: Boolean get() = p.getBoolean("diag", false); set(v) { p.edit().putBoolean("diag", v).apply() }
    var batteryNotif: Boolean get() = p.getBoolean("battery_notif", false); set(v) { p.edit().putBoolean("battery_notif", v).apply() }

    /** Persist user EQ curves locally; these are app profiles, separate from earbud protocol state. */
    fun loadEqProfiles(): List<SavedEqProfile> {
        val raw = p.getString("eq_profiles_v1", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
                val vals = obj.optJSONArray("values") ?: return@mapNotNull null
                if (vals.length() != 10) return@mapNotNull null
                SavedEqProfile(obj.optString("name", "Custom EQ"), (0 until 10).map { vals.optInt(it).coerceIn(-12, 12) })
            }
        } catch (_: Exception) { emptyList() }
    }
    fun saveEqProfiles(profiles: List<SavedEqProfile>) {
        val arr = JSONArray()
        profiles.take(24).forEach { profile ->
            val obj = JSONObject(); obj.put("name", profile.name.take(32))
            val vals = JSONArray(); profile.values.take(10).forEach { vals.put(it.coerceIn(-12, 12)) }
            obj.put("values", vals); arr.put(obj)
        }
        p.edit().putString("eq_profiles_v1", arr.toString()).apply()
    }
}

data class SavedEqProfile(val name: String, val values: List<Int>)
