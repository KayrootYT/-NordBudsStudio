package com.nordbuds.studio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared palette retained for the EQ editor while the rest of the app uses the new dashboard UI. */
internal object P {
    val accent: Color @Composable get() = MaterialTheme.colorScheme.primary
    val text: Color @Composable get() = MaterialTheme.colorScheme.onSurface
    val sub: Color @Composable get() = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.66f)
    val card: Color @Composable get() = MaterialTheme.colorScheme.surface
    val tile: Color @Composable get() = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    val soft: Color @Composable get() = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val amber: Color = Color(0xFFFFB454)
}

@Composable
internal fun Txt(
    text: String,
    size: Int = 14,
    weight: FontWeight = FontWeight.Normal,
    color: Color = MaterialTheme.colorScheme.onSurface,
    maxLines: Int = Int.MAX_VALUE,
    lineHeight: Int? = null
) {
    Text(
        text = text,
        fontSize = size.sp,
        fontWeight = weight,
        color = color,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        lineHeight = (lineHeight ?: (size + 4)).sp
    )
}

@Composable
internal fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(2.dp), content = content)
    }
}
