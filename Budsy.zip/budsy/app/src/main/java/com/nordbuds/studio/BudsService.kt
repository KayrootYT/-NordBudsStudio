package com.nordbuds.studio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps the app process alive while the earbuds' control channel is connecting or connected, so the
 * connection, widget, tile and notification keep working with the UI closed (like HeyMelody).
 * It stops itself about a minute after the earbuds are gone.
 */
class BudsService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Buds.attach(applicationContext)
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(NOTIF_ID, build())
        } catch (_: Throwable) { stopSelf(); return START_NOT_STICKY }
        job?.cancel()
        job = scope.launch {
            var idle = 0
            while (isActive) {
                refresh()
                idle = if (Buds.connected || Buds.connecting) 0 else idle + 1
                if (idle >= 12) { stopSelf(); break }
                delay(5000)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        job?.cancel(); scope.cancel()
        try { BatteryNotifier.update(applicationContext) } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun refresh() {
        try { getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, build()) } catch (_: Throwable) { }
    }

    private fun build(): Notification {
        val l = Buds.battery[0]; val r = Buds.battery[1]; val c = Buds.battery[2]
        val text = when {
            Buds.connected && l >= 0 && r >= 0 -> if (c >= 0) getString(R.string.notif_connected, l, r, c) else getString(R.string.notif_connected_no_case, l, r)
            Buds.connected -> getString(R.string.connected)
            Buds.connecting -> getString(R.string.status_connecting)
            else -> getString(R.string.notif_disconnected)
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_buds)
            .setContentTitle(Buds.displayName.ifEmpty { getString(R.string.app_name) })
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "link"
        private const val NOTIF_ID = 2
        @Volatile var running = false; private set
        fun start(ctx: Context) {
            if (running) return
            ContextCompat.startForegroundService(ctx, Intent(ctx, BudsService::class.java))
        }
    }
}
