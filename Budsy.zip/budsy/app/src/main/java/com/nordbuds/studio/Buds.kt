package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nordbuds.studio.buds.Link
import com.nordbuds.studio.buds.Prefs
import com.nordbuds.studio.protocol.Protocol
import com.nordbuds.studio.widget.BudsWidgetProvider
import java.util.ArrayDeque
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** App-wide observable earbud state and protocol API. */
@SuppressLint("MissingPermission")
object Buds {
    const val ANC_OFF = Protocol.ANC_OFF
    const val ANC_ON = Protocol.ANC_ON
    const val ANC_TRANSP = Protocol.ANC_TRANSP
    const val G_SINGLE = 1; const val G_DOUBLE = 2; const val G_TRIPLE = 3; const val G_HOLD = 4; const val G_LONG = 6
    const val F_NONE = 0x00; const val F_PLAY = 0x01; const val F_VOICE = 0x03; const val F_PREV = 0x05; const val F_NEXT = 0x06; const val F_ANC = 0x08; const val F_VOL_UP = 0x0B; const val F_VOL_DN = 0x0C; const val F_GAME = 0x11
    const val M_OFF = 1; const val M_ANC = 2; const val M_TRANSP = 4
    val PRESETS = listOf(Triple(3, R.string.preset_balanced, R.string.preset_balanced_sub), Triple(4, R.string.preset_vocals, R.string.preset_vocals_sub), Triple(5, R.string.preset_bass, R.string.preset_bass_sub))
    data class Msg(val id: Int, val res: Int, val args: List<Any> = emptyList())
    enum class SaveState { IDLE, SAVING, SAVED, FAILED }

    private lateinit var appCtx: Context
    lateinit var prefs: Prefs; private set
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var link: Link
    var status by mutableStateOf(""); private set
    var connected by mutableStateOf(false); private set
    var connecting by mutableStateOf(false); private set
    var searching by mutableStateOf(false)
    var autoPaused by mutableStateOf(false); private set
    var btEnabled by mutableStateOf(true)
    var deviceName by mutableStateOf(""); private set
    var deviceAddr by mutableStateOf(""); private set
    var customName by mutableStateOf<String?>(null); private set
    val displayName: String get() = customName ?: deviceName
    val battery = mutableStateListOf(-1, -1, -1)
    val charging = mutableStateListOf(false, false, false)
    var ancMode by mutableIntStateOf(-1); private set
    var ancSaveState by mutableStateOf(SaveState.IDLE); private set
    var ancSaveMessage by mutableStateOf(""); private set
    private var ancVerifyJob: Job? = null
    var holdMask by mutableIntStateOf(-1); private set
    var holdSaveState by mutableStateOf(SaveState.IDLE); private set
    var holdSaveMessage by mutableStateOf(""); private set
    var findAlertRequested by mutableStateOf(false); private set
    var findAlertSide by mutableIntStateOf(3); private set
    var findAlertMessage by mutableStateOf(""); private set
    private var pendingHoldMask: Int? = null
    private var holdVerifyTries = 0
    private var holdVerifyJob: Job? = null
    var eqPreset by mutableIntStateOf(-1); private set
    var eqSaveState by mutableStateOf(SaveState.IDLE); private set
    var eqSaveMessage by mutableStateOf(""); private set
    private var pendingEqPreset: Int? = null
    private var eqVerifyJob: Job? = null
    var gameMode by mutableStateOf<Boolean?>(null); private set
    var bassOn by mutableStateOf<Boolean?>(null); private set
    var bassLevel by mutableStateOf<Int?>(null); private set
    var bassMin by mutableIntStateOf(-10); private set
    var bassMax by mutableIntStateOf(10); private set
    var wearDetect by mutableStateOf<Boolean?>(null); private set
    val gest = mutableStateMapOf<Int, Int>()
    var msg by mutableStateOf<Msg?>(null); private set
    var logVersion by mutableIntStateOf(0); private set
    var firmware by mutableStateOf<String?>(null); private set
    val wear = mutableStateListOf(-1, -1, -1)
    val flags = mutableStateMapOf<Int, Int>()
    var customEq by mutableStateOf<String?>(null); private set
    val customEqProfiles = mutableStateListOf<Protocol.CustomEqProfile>()
    val peers = mutableStateListOf<String>()
    private var heartbeatJob: Job? = null
    private var msgSeq = 0
    private var pendingAnc = -1
    private var ancSwapped = false
    private val ancCode = intArrayOf(1, 2, 4)
    private val pendingGest = HashMap<Int, Int>()
    private var verifyGest = false
    private var verifyTries = 0
    private var bassRawMin = 0xF6
    private var bassRawMax = 0x0A
    private val logBuf = ArrayDeque<String>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun attach(ctx: Context) {
        if (::appCtx.isInitialized) return
        appCtx = ctx.applicationContext; prefs = Prefs(appCtx)
        status = str(R.string.status_not_connected)
        autoPaused = prefs.autoPaused; customName = prefs.customName
        link = Link(scope, ::onFrame, ::onDropped)
        BatteryNotifier.ensureChannel(appCtx)
    }
    fun isAttached(): Boolean = ::appCtx.isInitialized
    fun str(res: Int, vararg args: Any): String = appCtx.getString(res, *args)
    fun say(res: Int, vararg args: Any) { msg = Msg(++msgSeq, res, args.toList()) }
    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun logText(): String = synchronized(logBuf) { logBuf.joinToString("\n") }
    private fun note(dir: String, lo: Int, hi: Int, p: IntArray) {
        synchronized(logBuf) { logBuf.addLast("$dir ${Protocol.hex(hi)}${Protocol.hex(lo)} " + p.joinToString(" ") { Protocol.hex(it) }); while (logBuf.size > 150) logBuf.removeFirst() }
        logVersion++
    }
    private fun notifyChanged() { listeners.forEach { it() }; if (::appCtx.isInitialized) { BudsWidgetProvider.notifyUpdate(appCtx); BatteryNotifier.update(appCtx) } }
    private fun send(cmd: Int, grp: Int, vararg pl: Int) { note("TX", cmd, grp, pl); link.write(cmd, grp, pl) }
    private fun query(ms: Int, cmd: Int, vararg pl: Int) { scope.launch { delay(ms.toLong()); if (connected) send(cmd, Protocol.GRP_QUERY, *pl) } }

    fun connect(d: BluetoothDevice, auto: Boolean = false) {
        if (auto && autoPaused) return
        if (!auto && autoPaused) { autoPaused = false; prefs.autoPaused = false }
        if (connecting || connected) return
        connecting = true; status = str(R.string.status_connecting); ancSaveState = SaveState.IDLE; ancSaveMessage = ""; findAlertMessage = ""
        scope.launch {
            val dev = try { link.connect(d) } catch (_: Exception) { null }
            connecting = false
            if (dev == null) { if (!connected) status = str(R.string.status_no_channel); notifyChanged(); return@launch }
            deviceName = dev.name ?: dev.address; deviceAddr = dev.address; prefs.lastAddr = deviceAddr
            connected = true; status = str(R.string.status_connected_to, displayName)
            initialRead()
            // User preference: start each new connection with Noise Control OFF.
            // Wait until the initial status queries have been sent before issuing the setting.
            scope.launch {
                delay(1400)
                if (connected) setAnc(ANC_OFF)
            }
            heartbeatJob?.cancel()
            heartbeatJob = scope.launch { while (isActive && connected) { delay(10000); if (connected) { send(6, Protocol.GRP_QUERY); send(0x0c, Protocol.GRP_QUERY, 1, 1); send(0x0c, Protocol.GRP_QUERY, 2, 1) } } }
            notifyChanged()
        }
    }
    fun resumeAutoConnect() { autoPaused = false; prefs.autoPaused = false }
    fun disconnect() { autoPaused = true; prefs.autoPaused = true; link.close(true); cleanup(str(R.string.status_auto_off)) }
    private fun onDropped(reason: String) { if (connecting) connecting = false; if (connected) cleanup(reason) }
    private fun cleanup(statusMsg: String) {
        connected = false; heartbeatJob?.cancel(); heartbeatJob = null; verifyGest = false; pendingGest.clear(); pendingAnc = -1; pendingHoldMask = null; holdVerifyJob?.cancel(); pendingEqPreset = null; eqVerifyJob?.cancel(); eqSaveState = SaveState.IDLE; holdSaveState = SaveState.IDLE; ancVerifyJob?.cancel(); ancSaveState = SaveState.IDLE; findAlertRequested = false; findAlertMessage = ""
        for (i in 0..2) { battery[i] = -1; charging[i] = false; wear[i] = -1 }
        peers.clear(); status = statusMsg; notifyChanged()
    }
    private fun initialRead() {
        scope.launch {
            val q = listOf(6 to intArrayOf(), 0x0c to intArrayOf(1, 1), 0x0c to intArrayOf(2, 1), 8 to intArrayOf(2, 3, 1), 0x0d to Protocol.FEATURE_REQUEST, 0x0f to intArrayOf(), 0x24 to intArrayOf(), 5 to intArrayOf(), 9 to intArrayOf(), 0x22 to intArrayOf(), 0x12 to intArrayOf())
            for ((c, p) in q) { if (!connected) break; send(c, Protocol.GRP_QUERY, *p); delay(90) }
        }
    }
    fun refreshAll() { if (connected) initialRead() }
    fun scanFlags() {
        if (!need()) return
        scope.launch { var id = 1; while (id <= 0x20 && connected) { val n = minOf(15, 0x20 - id + 1); send(0x0d, Protocol.GRP_QUERY, *IntArray(n + 1) { if (it == 0) n else id + it - 1 }); id += n; delay(150) } }
    }
    fun findEarbuds(side: Int) {
        if (!need()) return
        val ids = when (side) { 1 -> intArrayOf(1, 1); 2 -> intArrayOf(1, 2); else -> intArrayOf(2, 1, 2) }
        findAlertSide = side.coerceIn(1, 3)
        findAlertRequested = true
        findAlertMessage = "Alert command sent · device response not confirmed"
        send(0, Protocol.GRP_SET, *ids)
        notifyChanged()
    }

    /** OPOv1 implementations commonly encode the find-device target list as a count + side IDs.
     * A zero count is the safest stop candidate, but must still be confirmed on the target firmware. */
    fun stopFindEarbuds() {
        if (!need()) return
        // The protocol currently has no documented stop acknowledgement for this firmware.
        // Send the count=0 candidate, but do not claim the tone stopped until tested on-device.
        send(0, Protocol.GRP_SET, 0)
        findAlertRequested = false
        findAlertMessage = "Stop requested · confirm the tone stopped on the earbuds"
        notifyChanged()
    }

    private fun onFrame(f: Protocol.Frame) {
        note("RX", f.lo, f.hi, f.payload); val p = f.payload
        if (f.isPush) { if (f.lo == 0x04 && p.isNotEmpty()) when (p[0]) { 1 -> onBattery(p); 2 -> onWear(p); 3 -> if (p.size >= 4) onAncValue(p[3] or (if (p.size > 4) p[4] shl 8 else 0)) }; notifyChanged(); return }
        if (p.isEmpty()) return
        val st = p[0]
        when (f.cmd) {
            0x0106 -> if (st == 0) onBattery(p)
            0x0105 -> if (st == 0) Protocol.parseFirmware(p)?.let { firmware = it }
            0x0109 -> if (st == 0) onWear(p)
            0x0122 -> if (st == 0) { val profs = Protocol.parseCustomEq(p); customEqProfiles.clear(); customEqProfiles.addAll(profs); customEq = formatCustomEq(profs) }
            0x0112 -> if (st == 0) { peers.clear(); peers.addAll(Protocol.parsePeers(p).map { it.name.ifEmpty { it.mac } }) }
            0x0108 -> if (st == 0 && p.size >= 2) onGestureTable(p)
            0x010C -> if (st == 0 && p.size >= 4) {
                val mask = p[3] or (if (p.size > 4) p[4] shl 8 else 0)
                if (p[1] == 1) onAncValue(mask)
                else if (p[1] == 2) {
                    val actual = mask and 7
                    holdMask = actual
                    val expected = pendingHoldMask
                    if (expected != null) {
                        if (actual == expected) {
                            pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.SAVED
                            holdSaveMessage = "Earbud confirmed the Hold setting"
                        } else if (holdVerifyTries < 2) {
                            holdVerifyTries++
                            query(500, 0x0c, 2, 1)
                        } else {
                            pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.FAILED
                            holdSaveMessage = "Earbud value did not match the selected setting"
                        }
                    }
                }
            }
            0x010D -> if (st == 0) for ((id, v) in Protocol.parseFlags(p)) { flags[id] = v; when (id) { 0x06 -> gameMode = v == 1; 0x1d -> bassOn = v == 1; 0x0b -> wearDetect = v == 1 } }
            0x010F -> if (st == 0 && p.size >= 2) {
                val actual = p[1]
                eqPreset = actual
                val expected = pendingEqPreset
                if (expected != null) {
                    if (actual == expected) {
                        pendingEqPreset = null; eqVerifyJob?.cancel()
                        eqSaveState = SaveState.SAVED; eqSaveMessage = "Earbuds confirmed the EQ preset"
                    } else if (eqSaveState == SaveState.SAVING) {
                        // The device still reports its previous preset; allow one delayed read-back.
                        eqVerifyJob?.cancel()
                        eqVerifyJob = scope.launch {
                            delay(700)
                            if (connected && pendingEqPreset != null) send(0x0f, Protocol.GRP_QUERY)
                            delay(1200)
                            if (connected && pendingEqPreset != null) {
                                pendingEqPreset = null; eqSaveState = SaveState.FAILED
                                eqSaveMessage = "Earbuds did not confirm this preset. Check the protocol log."
                                query(100, 0x0f); notifyChanged()
                            }
                        }
                    }
                }
            }
            0x0124 -> if (st == 0 && p.size >= 4) { bassRawMin = p[1]; bassRawMax = p[2]; val mn = p[1].toByte().toInt(); val mx = p[2].toByte().toInt(); if (mn < mx) { bassMin = mn; bassMax = mx }; bassLevel = p[3].toByte().toInt().coerceIn(bassMin, bassMax) }
            0x0401 -> { if (st != 0) { say(R.string.err_refused_gesture, Protocol.hex(st)); pendingGest.clear(); verifyGest = false; query(200, 8, 2, 3, 1) } else { verifyGest = true; verifyTries = 0; query(500, 8, 2, 3, 1) } }
            0x0403 -> { if (st != 0) say(R.string.err_refused_setting, Protocol.hex(st)); query(200, 0x0d, *Protocol.FEATURE_REQUEST) }
            0x0404 -> {
                if (st != 0) {
                    pendingAnc = -1
                    ancVerifyJob?.cancel()
                    ancSaveState = SaveState.FAILED
                    ancSaveMessage = "Earbuds rejected Noise Control (${Protocol.hex(st)})"
                    if (pendingHoldMask != null) {
                        pendingHoldMask = null; holdVerifyJob?.cancel(); holdSaveState = SaveState.FAILED
                        holdSaveMessage = "Earbud rejected the Hold setting (${Protocol.hex(st)})"
                    }
                    say(if (st == 0x0e) R.string.err_anc_ears else R.string.err_anc_failed, Protocol.hex(st))
                }
                query(200, 0x0c, 1, 1); query(350, 0x0c, 2, 1)
            }
            0x0406 -> {
                if (st != 0) {
                    pendingEqPreset = null; eqVerifyJob?.cancel(); eqSaveState = SaveState.FAILED
                    eqSaveMessage = "Earbuds rejected the EQ preset (${Protocol.hex(st)})"
                    say(R.string.err_refused_preset, Protocol.hex(st))
                } else {
                    eqSaveState = SaveState.SAVING; eqSaveMessage = "Checking EQ preset on earbuds…"
                }
                query(250, 0x0f)
            }
            0x041B -> { if (st != 0) say(R.string.err_refused_bass, Protocol.hex(st)); query(200, 0x24) }
            0x0422 -> { if (st != 0) say(R.string.err_refused_setting, Protocol.hex(st)); query(200, 0x22) }
        }
        notifyChanged()
    }
    private fun formatCustomEq(profs: List<Protocol.CustomEqProfile>): String? = if (profs.isEmpty()) str(R.string.custom_eq_none) else profs.joinToString("\n") { pr -> pr.name + (if (pr.active) " (active)" else "") + ": " + pr.bands.mapIndexed { i, (hz, g) -> (if (hz >= 1000) "${hz / 1000}k" else "$hz") + " " + (if (g > 0) "+$g" else "$g") + if (i < pr.bands.size - 1) " · " else "" }.joinToString("") }
    private fun onBattery(p: IntArray) { Protocol.parseBattery(p).forEach { b -> if (b.slot in 0..2) { battery[b.slot] = b.percent; charging[b.slot] = b.charging } }; notifyChanged() }
    private fun onWear(p: IntArray) { Protocol.parseWear(p).forEach { if (it.slot in 0..2) wear[it.slot] = it.flags } }
    private fun onAncValue(mask: Int) {
        val m = Protocol.decodeAnc(mask).let { if (it >= 0) it else ancCode.indexOf(mask) }; if (m < 0) return; val want = pendingAnc
        if (want >= 0) {
            if (m == want) { pendingAnc = -1; ancVerifyJob?.cancel(); ancSaveState = SaveState.SAVED; ancSaveMessage = "Earbuds confirmed Noise Control" }
            else { ancSaveState = SaveState.SAVING; ancSaveMessage = "Waiting for Noise Control confirmation…" }
        }
        if (want >= 0 && m != want && !ancSwapped && (m == ANC_OFF || m == ANC_ON) && (want == ANC_OFF || want == ANC_ON)) { ancSwapped = true; val t = ancCode[ANC_OFF]; ancCode[ANC_OFF] = ancCode[ANC_ON]; ancCode[ANC_ON] = t; pendingAnc = want; send(4, Protocol.GRP_SET, 1, 1, ancCode[want]); return }; ancMode = m
    }
    private fun onGestureTable(p: IntArray) {
        val pend = HashMap(pendingGest); val table = Protocol.parseGestureTable(p)
        table.forEach { (k, v) -> if (!pend.containsKey(k)) gest[k] = v }
        if (!verifyGest) return
        val bad = pend.any { table[it.key] != it.value }
        if (bad && verifyTries < 2) { verifyTries++; query(700, 8, 2, 3, 1); return }
        verifyGest = false; pendingGest.clear(); table.forEach { (k, v) -> gest[k] = v }; if (bad) say(R.string.err_gesture_kept)
    }
    private fun need(): Boolean { if (!connected) { say(R.string.err_connect_first); return false }; return true }
    fun setAnc(mode: Int) {
        if (!need() || mode !in 0..2) return
        pendingAnc = mode
        ancSaveState = SaveState.SAVING
        ancSaveMessage = "Sending Noise Control setting…"
        ancVerifyJob?.cancel()
        send(4, Protocol.GRP_SET, 1, 1, ancCode[mode])
        ancVerifyJob = scope.launch {
            delay(450)
            if (connected && pendingAnc == mode) send(0x0c, Protocol.GRP_QUERY, 1, 1)
            delay(1800)
            if (connected && pendingAnc == mode) {
                pendingAnc = -1
                ancSaveState = SaveState.FAILED
                ancSaveMessage = "No matching confirmation received; showing the last reported device state"
                query(100, 0x0c, 1, 1)
                notifyChanged()
            }
        }
        notifyChanged()
    }
    fun updateHoldMask(mask: Int) {
        if (!need()) return
        val m = mask and 7
        if (m == 0) { holdSaveState = SaveState.FAILED; holdSaveMessage = "Select at least one Hold mode"; return }
        pendingHoldMask = m; holdVerifyTries = 0; holdSaveState = SaveState.SAVING
        holdSaveMessage = "Sending setting to earbuds…"
        holdVerifyJob?.cancel()
        send(4, Protocol.GRP_SET, 2, 1, m)
        holdVerifyJob = scope.launch {
            delay(500)
            if (connected && pendingHoldMask != null) send(0x0c, Protocol.GRP_QUERY, 2, 1)
            delay(1600)
            if (connected && pendingHoldMask != null) {
                pendingHoldMask = null; holdSaveState = SaveState.FAILED
                holdSaveMessage = "No matching confirmation received. Current earbud value is shown."
                query(100, 0x0c, 2, 1); notifyChanged()
            }
        }
        notifyChanged()
    }
    fun queryHold() {
        if (connected) {
            if (pendingHoldMask == null) { holdSaveState = SaveState.IDLE; holdSaveMessage = "" }
            send(0x0c, Protocol.GRP_QUERY, 2, 1)
        }
    }
    fun setGesture(side: Int, gid: Int, fn: Int) { if (!need()) return; val k = side * 16 + gid; gest[k] = fn; pendingGest[k] = fn; send(1, Protocol.GRP_SET, 1, side, 1, gid, fn) }
    fun setEq(id: Int) {
        if (!need()) return
        if (PRESETS.none { it.first == id }) return
        pendingEqPreset = id; eqSaveState = SaveState.SAVING; eqSaveMessage = "Sending EQ preset to earbuds…"
        eqVerifyJob?.cancel()
        send(6, Protocol.GRP_SET, id)
        eqVerifyJob = scope.launch {
            delay(450)
            if (connected && pendingEqPreset != null) send(0x0f, Protocol.GRP_QUERY)
            delay(1800)
            if (connected && pendingEqPreset != null) {
                pendingEqPreset = null; eqSaveState = SaveState.FAILED
                eqSaveMessage = "No confirmation from earbuds. EQ command may not be supported by this firmware."
                send(0x0f, Protocol.GRP_QUERY); notifyChanged()
            }
        }
        notifyChanged()
    }
    fun setGame(on: Boolean) { if (!need()) return; gameMode = on; send(3, Protocol.GRP_SET, 0x06, if (on) 1 else 0) }
    fun setBassOn(on: Boolean) { if (!need()) return; bassOn = on; send(3, Protocol.GRP_SET, 0x1d, if (on) 1 else 0) }
    fun setBassLevel(level: Int) { if (!need()) return; val l = level.coerceIn(bassMin, bassMax); bassLevel = l; send(0x1b, Protocol.GRP_SET, bassRawMin, bassRawMax, l and 255) }
    fun setFlag(id: Int, on: Boolean) { if (!need()) return; flags[id] = if (on) 1 else 0; send(3, Protocol.GRP_SET, id, if (on) 1 else 0) }
    fun setWearDetect(on: Boolean) { setFlag(0x0b, on) }
    fun writeCustomEq(bands: List<Pair<Int, Int>>) { if (!need() || bands.isEmpty()) return; val name = customEqProfiles.firstOrNull()?.name ?: "Custom"; send(0x22, Protocol.GRP_SET, *Protocol.buildCustomEqPayload(Protocol.CustomEqProfile(name, true, bands), -10, 10)) }
    fun renameDevice(name: String?) { customName = name?.trim()?.takeIf { it.isNotEmpty() }; prefs.customName = customName; if (connected) status = str(R.string.status_connected_to, displayName); notifyChanged() }
}
