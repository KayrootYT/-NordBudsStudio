package com.nordbuds.studio.tile

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.nordbuds.studio.Buds
import com.nordbuds.studio.MainActivity
import com.nordbuds.studio.R

class BudsTileService : TileService() {
    override fun onStartListening() { super.onStartListening(); refresh() }
    override fun onClick() {
        super.onClick()
        if (Buds.connected) Buds.setGame(Buds.gameMode != true)
        else startActivityAndCollapse(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        refresh()
    }
    private fun refresh() {
        val t = qsTile ?: return
        if (Buds.connected) { t.state = if (Buds.gameMode == true) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE; t.label = getString(R.string.tile_label); t.subtitle = getString(R.string.tile_battery, Buds.battery[0].coerceAtLeast(0), Buds.battery[1].coerceAtLeast(0)) }
        else { t.state = Tile.STATE_UNAVAILABLE; t.label = getString(R.string.tile_label); t.subtitle = getString(R.string.notif_disconnected) }
        t.updateTile()
    }
}
