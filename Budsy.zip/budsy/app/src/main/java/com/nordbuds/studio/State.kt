package com.nordbuds.studio

import com.nordbuds.studio.buds.Prefs

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val prefs: Prefs, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit,
    val dark: Boolean, val accentIdx: Int, val setDark: (Boolean) -> Unit, val setAccent: (Int) -> Unit,
    val audio: Set<String>, val audioKnown: Boolean,
    val amoled: Boolean = false, val setAmoled: (Boolean) -> Unit = {},
    val askNotifPerm: () -> Unit = {}, val notifGranted: Boolean = true
)
