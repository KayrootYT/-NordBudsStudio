package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color,
    val sheet: Color, val edgeA: Color, val edgeB: Color, val glow: List<Color>, val amoled: Boolean = false
)

/** Accent palettes shown in Settings. */
val PaletteNames = listOf("Space", "Ocean", "Cosmic", "Cyberpunk", "Emerald")
private val PaletteAccent = listOf(
    Color(0xFF007AFF), Color(0xFF0A84FF), Color(0xFFAF52DE),
    Color(0xFFFF9500), Color(0xFF30B566)
)
private val PaletteGlow = listOf(
    listOf(Color(0xFF8BC5FF), Color(0xFFB6D8FF), Color(0xFFE7F2FF)),
    listOf(Color(0xFF86C7FF), Color(0xFFA9DFFF), Color(0xFFEAF7FF)),
    listOf(Color(0xFFD9B4F4), Color(0xFFE9D7FA), Color(0xFFF6ECFF)),
    listOf(Color(0xFFFFD09A), Color(0xFFFFE3BE), Color(0xFFFFF2E1)),
    listOf(Color(0xFF9DE5BE), Color(0xFFC8F0D9), Color(0xFFECFAF1))
)
private val PaletteGlowLight = PaletteGlow

fun makePal(dark: Boolean, idx: Int, amoled: Boolean = false, visualStyle: Int = 0): Pal {
    val i = idx.coerceIn(0, PaletteAccent.size - 1)
    val acc = PaletteAccent[i]
    if (dark && amoled) return Pal(
        true, Color(0xFF000000), Color(0xFF1C1C1E), Color(0xFF2C2C2E), Color(0xFFF5F5F7), Color(0xFF98989D),
        Color(0xFF38383A), Color(0xFF48484A), acc, acc.copy(alpha = 0.18f), Color(0xFF30D158), Color(0xFFFF9F0A),
        Color(0xFF1C1C1E), Color(0x1FFFFFFF), Color(0x08FFFFFF), PaletteGlow[i], true
    )
    return if (dark) Pal(
        true, Color(0xFF000000), Color(0xFF1C1C1E), Color(0xFF2C2C2E), Color(0xFFF5F5F7), Color(0xFF98989D),
        Color(0xFF38383A), Color(0xFF48484A), acc, acc.copy(alpha = 0.18f), Color(0xFF30D158), Color(0xFFFF9F0A),
        Color(0xFF1C1C1E), Color(0x1FFFFFFF), Color(0x08FFFFFF), PaletteGlow[i]
    ) else Pal(
        false, Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFF2F2F7), Color(0xFF1C1C1E), Color(0xFF8E8E93),
        Color(0xFFE5E5EA), Color(0xFFD1D1D6), acc, acc.copy(alpha = 0.12f), Color(0xFF248A3D), Color(0xFFB86E00),
        Color(0xFFFFFFFF), Color(0x33FFFFFF), Color(0x0A000000), PaletteGlowLight[i]
    )
}

val LocalPal = staticCompositionLocalOf { makePal(true, 0) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, accentIdx: Int, amoled: Boolean = false, visualStyle: Int = 0, content: @Composable () -> Unit) {
    val base = makePal(dark, accentIdx, amoled)
    // iOS-inspired surfaces: neutral system backgrounds, crisp cards and restrained accent colour.
    val p = if (visualStyle == 1) base.copy(
        bg = if (dark) Color(0xFF000000) else Color(0xFFF2F2F7),
        card = if (dark) Color(0xFF1C1C1E) else Color(0xFFFFFFFF),
        tile = if (dark) Color(0xFF2C2C2E) else Color(0xFFF2F2F7),
        line = if (dark) Color(0xFF38383A) else Color(0xFFE5E5EA),
        edgeA = if (dark) Color(0x1FFFFFFF) else Color(0x14000000),
        edgeB = if (dark) Color(0x08FFFFFF) else Color(0x08000000),
        glow = if (dark) listOf(Color(0xFF202024), Color(0xFF242428), Color(0xFF1C1C1E)) else listOf(Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFF8F8FA))
    ) else base
    val cs = if (dark) darkColorScheme(primary = p.accent, secondary = p.glow.last(), background = p.bg, surface = p.sheet, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}

fun paletteColor(i: Int): Color = PaletteAccent[i.coerceIn(0, PaletteAccent.size - 1)]
