package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** The three stock themes. Stored in prefs as these ints. */
object ThemeMode {
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

/** Flat, iOS-style palette. One accent (system blue), no gradients, no glass. */
@Immutable
class Pal(
    val dark: Boolean,
    val amoled: Boolean,
    val bg: Color,      // page
    val tile: Color,    // segmented track, secondary buttons, input fields
    val thumb: Color,   // selected segment
    val text: Color,
    val sub: Color,
    val line: Color,    // hairline separators
    val track: Color,   // switch off / slider inactive
    val accent: Color,
    val green: Color,
    val amber: Color,
    val red: Color,
    val sheet: Color
)

fun makePal(mode: Int): Pal = when (mode) {
    ThemeMode.AMOLED -> Pal(
        true, true,
        bg = Color(0xFF05070D), tile = Color(0xFF171D2B), thumb = Color(0xFF26334A),
        text = Color(0xFFF5F8FF), sub = Color(0xFF9BA9BF), line = Color(0xFF29364A), track = Color(0xFF33445D),
        accent = Color(0xFF0A84FF), green = Color(0xFF30D158), amber = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
        sheet = Color(0xE61B2535)
    )
    ThemeMode.DARK -> Pal(
        true, false,
        bg = Color(0xFF0A101C), tile = Color(0xFF172235), thumb = Color(0xFF293A55),
        text = Color(0xFFF5F8FF), sub = Color(0xFF9BA9BF), line = Color(0xFF2B3A51), track = Color(0xFF354760),
        accent = Color(0xFF0A84FF), green = Color(0xFF30D158), amber = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
        sheet = Color(0xE61A2639)
    )
    else -> Pal(
        false, false,
        bg = Color(0xFFF3F6FC), tile = Color(0xFFE5ECF7), thumb = Color(0xFFFFFFFF),
        text = Color(0xFF111A2B), sub = Color(0xFF69778F), line = Color(0xFFD5DFEE), track = Color(0xFFD8E2F0),
        accent = Color(0xFF007AFF), green = Color(0xFF34C759), amber = Color(0xFFFF9500), red = Color(0xFFFF3B30),
        sheet = Color(0xEFFFFFFF)
    )
}

val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.LIGHT) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, content: @Composable () -> Unit) {
    val p = makePal(mode)
    val cs = if (p.dark) darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    ) else lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    )
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
