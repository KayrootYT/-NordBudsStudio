package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color,
    val sheet: Color, val edgeA: Color, val edgeB: Color, val glow: List<Color>, val amoled: Boolean = false
)

/** Accent palettes shown in Settings. */
val PaletteNames = listOf("Aurora", "Ocean", "Cosmic", "Sunset", "Emerald")
private val PaletteAccent = listOf(
    Color(0xFFFF6B4F), Color(0xFF3395FF), Color(0xFFA66BFF),
    Color(0xFFFF8A3D), Color(0xFF20C997)
)
private val PaletteGlow = listOf(
    listOf(Color(0xFFFF6B4F), Color(0xFF7B5CFF), Color(0xFF22C3A6)),
    listOf(Color(0xFF3395FF), Color(0xFF22D3EE), Color(0xFF6C5CE7)),
    listOf(Color(0xFFA66BFF), Color(0xFFFF5CAA), Color(0xFF3395FF)),
    listOf(Color(0xFFFF8A3D), Color(0xFFFF477E), Color(0xFFFFC857)),
    listOf(Color(0xFF20C997), Color(0xFF2DD4BF), Color(0xFF84CC16))
)

private val PaletteGlowLight = listOf(
    listOf(Color(0xFFFFB199), Color(0xFFC3B5FF), Color(0xFFA8EBD8)),
    listOf(Color(0xFFA5D0FF), Color(0xFFA5EEF7), Color(0xFFC5BDFA)),
    listOf(Color(0xFFDCC3FF), Color(0xFFFFB5D8), Color(0xFFB3D4FF)),
    listOf(Color(0xFFFFD0A8), Color(0xFFFFB7C5), Color(0xFFFFE3A3)),
    listOf(Color(0xFFA7F3D0), Color(0xFF99F6E4), Color(0xFFD9F99D))
)

fun makePal(dark: Boolean, idx: Int, amoled: Boolean = false): Pal {
    val i = idx.coerceIn(0, PaletteAccent.size - 1)
    val acc = PaletteAccent[i]
    if (dark && amoled) return Pal(
        true, Color(0xFF000000), Color(0xD10D0D12), Color(0xE616161D), Color(0xFFF2F3F8), Color(0xFF9A9DB2),
        Color(0xFF22232C), Color(0xFF3A3C4C), acc, acc.copy(alpha = 0.22f), Color(0xFF3CCB8B), Color(0xFFF0B429),
        Color(0xFF0D0D12), Color(0x33FFFFFF), Color(0x08FFFFFF), PaletteGlow[i], true
    )
    return if (dark) Pal(
        true, Color(0xFF0B0C1A), Color(0xD11D1F36), Color(0xE62A2C48), Color(0xFFF2F3F8), Color(0xFFA2A5BE),
        Color(0xFF30324F), Color(0xFF4A4D6A), acc, acc.copy(alpha = 0.22f), Color(0xFF3CCB8B), Color(0xFFF0B429),
        Color(0xFF1D1F36), Color(0x40FFFFFF), Color(0x0DFFFFFF), PaletteGlow[i]
    ) else Pal(
        false, Color(0xFFF7F2EB), Color(0xCCFFFFFF), Color(0xE6F1EBE3), Color(0xFF17181F), Color(0xFF7C7F8C),
        Color(0xFFE6DFD6), Color(0xFFC9C5BE), acc, acc.copy(alpha = 0.16f), Color(0xFF1FA86A), Color(0xFFE0A100),
        Color(0xFFFFFBF6), Color(0xCCFFFFFF), Color(0x33FFFFFF), PaletteGlowLight[i]
    )
}

val LocalPal = staticCompositionLocalOf { makePal(true, 0) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, accentIdx: Int, amoled: Boolean = false, content: @Composable () -> Unit) {
    val p = makePal(dark, accentIdx, amoled)
    val cs = if (dark) darkColorScheme(primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}

fun paletteColor(i: Int): Color = PaletteAccent[i.coerceIn(0, PaletteAccent.size - 1)]
