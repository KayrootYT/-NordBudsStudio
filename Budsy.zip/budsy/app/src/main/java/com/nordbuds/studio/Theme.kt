package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** The three stock themes. Stored in prefs as these ints. */
object ThemeMode {
    const val LIGHT = 0
    const val DARK = 1
    const val AMOLED = 2
}

/** Flat, iOS-style palette. One accent (system blue), no gradients, no glass. */
@Immutable
class Pal(
    val dark: Boolean,
    val amoled: Boolean,
    val bg: Color,      // page
    val tile: Color,    // segmented track, secondary buttons, input fields
    val thumb: Color,   // selected segment
    val text: Color,
    val sub: Color,
    val line: Color,    // hairline separators
    val track: Color,   // switch off / slider inactive
    val accent: Color,
    val green: Color,
    val amber: Color,
    val red: Color,
    val sheet: Color
)

fun makePal(mode: Int): Pal = when (mode) {
    ThemeMode.AMOLED -> Pal(
        true, true,
        bg = Color(0xFF000000), tile = Color(0xFF1C1C1E), thumb = Color(0xFF3A3A3C),
        text = Color(0xFFFFFFFF), sub = Color(0xFF8E8E93), line = Color(0xFF2C2C2E), track = Color(0xFF39393D),
        accent = Color(0xFF0A84FF), green = Color(0xFF30D158), amber = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
        sheet = Color(0xFF1C1C1E)
    )
    ThemeMode.DARK -> Pal(
        true, false,
        bg = Color(0xFF1C1C1E), tile = Color(0xFF2C2C2E), thumb = Color(0xFF636366),
        text = Color(0xFFFFFFFF), sub = Color(0xFF98989F), line = Color(0xFF3A3A3C), track = Color(0xFF48484A),
        accent = Color(0xFF0A84FF), green = Color(0xFF30D158), amber = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
        sheet = Color(0xFF2C2C2E)
    )
    else -> Pal(
        false, false,
        bg = Color(0xFFFFFFFF), tile = Color(0xFFEFEFF4), thumb = Color(0xFFFFFFFF),
        text = Color(0xFF000000), sub = Color(0xFF8E8E93), line = Color(0xFFD1D1D6), track = Color(0xFFE5E5EA),
        accent = Color(0xFF007AFF), green = Color(0xFF34C759), amber = Color(0xFFFF9500), red = Color(0xFFFF3B30),
        sheet = Color(0xFFF2F2F7)
    )
}

val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.LIGHT) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, content: @Composable () -> Unit) {
    val p = makePal(mode)
    val cs = if (p.dark) darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    ) else lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    )
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
