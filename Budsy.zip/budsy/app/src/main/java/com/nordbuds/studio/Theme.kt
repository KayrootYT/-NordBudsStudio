package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color,
    val sheet: Color, val edgeA: Color, val edgeB: Color, val glow: List<Color>, val amoled: Boolean = false
)

/** Accent palettes shown in Settings. */
val PaletteNames = listOf("Aurora", "Ocean", "Cosmic", "Fusion", "Emerald", "Titanium", "Prism", "Sunset", "Ice")
private val PaletteAccent = listOf(
    Color(0xFF8B5CF6), Color(0xFF0A84FF), Color(0xFFBF5AF2),
    Color(0xFFFF4D8D), Color(0xFF30D69A), Color(0xFFB9C6D8),
    Color(0xFF35D6D0), Color(0xFFFF8A3D), Color(0xFF7DD3FC)
)
private val PaletteGlow = listOf(
    listOf(Color(0xFF8B5CF6), Color(0xFF35D6D0), Color(0xFF6D8DFF)),
    listOf(Color(0xFF0A84FF), Color(0xFF42D9FF), Color(0xFFB8F0FF)),
    listOf(Color(0xFFBF5AF2), Color(0xFF7C4DFF), Color(0xFFFF72D2)),
    listOf(Color(0xFFFF4D8D), Color(0xFFFF8A3D), Color(0xFFFFC857)),
    listOf(Color(0xFF30D69A), Color(0xFF00A878), Color(0xFFB5F7D5)),
    listOf(Color(0xFFB9C6D8), Color(0xFF7E91AB), Color(0xFFE8EEF6)),
    listOf(Color(0xFF35D6D0), Color(0xFF8B5CF6), Color(0xFFFF6BCB)),
    listOf(Color(0xFFFF8A3D), Color(0xFFFF4D8D), Color(0xFFFFD166)),
    listOf(Color(0xFF7DD3FC), Color(0xFF60A5FA), Color(0xFFE0F2FE))
)
private val PaletteGlowLight = PaletteGlow

fun makePal(dark: Boolean, idx: Int, amoled: Boolean = false, visualStyle: Int = 0): Pal {
    val i = 1 // fixed clean iOS-blue accent; no user-selectable colour themes
    val acc = PaletteAccent[i]
    if (dark && amoled) return Pal(
        true, Color(0xFF080A14), Color(0xFF14182A), Color(0xFF20263D), Color(0xFFF5F6FF), Color(0xFFA0A8C2),
        Color(0xFF343B58), Color(0xFF424A6B), acc, acc.copy(alpha = 0.20f), Color(0xFF48E6A0), Color(0xFFFFC46B),
        Color(0xFF171B2E), Color(0x30FFFFFF), Color(0x0AFFFFFF), PaletteGlow[i], true
    )
    return if (dark) Pal(
        true, Color(0xFF080A14), Color(0xFF14182A), Color(0xFF20263D), Color(0xFFF5F6FF), Color(0xFFA0A8C2),
        Color(0xFF343B58), Color(0xFF424A6B), acc, acc.copy(alpha = 0.20f), Color(0xFF48E6A0), Color(0xFFFFC46B),
        Color(0xFF171B2E), Color(0x30FFFFFF), Color(0x0AFFFFFF), PaletteGlow[i]
    ) else Pal(
        false, Color(0xFFF4F5FF), Color(0xFFFFFFFF), Color(0xFFEAEDFF), Color(0xFF171A2C), Color(0xFF777F9D),
        Color(0xFFDDE1F5), Color(0xFFC9D0EC), acc, acc.copy(alpha = 0.13f), Color(0xFF188A5B), Color(0xFFB86E00),
        Color(0xFFFFFFFF), Color(0x33FFFFFF), Color(0x0A000000), PaletteGlowLight[i]
    )
}

val LocalPal = staticCompositionLocalOf { makePal(true, 0) }
val LocalAnimationIntensity = staticCompositionLocalOf { 1 }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, accentIdx: Int, amoled: Boolean = false, visualStyle: Int = 0, animationIntensity: Int = 1, content: @Composable () -> Unit) {
    val base = makePal(dark, accentIdx, amoled)
    // iOS-inspired surfaces: neutral system backgrounds, crisp cards and restrained accent colour.
    val p = base.copy(
        bg = if (dark) Color(0xFF000000) else Color(0xFFF2F2F7),
        card = if (dark) Color(0xFF1C1C1E) else Color(0xFFFFFFFF),
        tile = if (dark) Color(0xFF2C2C2E) else Color(0xFFF2F2F7),
        line = if (dark) Color(0xFF38383A) else Color(0xFFE5E5EA),
        edgeA = if (dark) Color(0x1FFFFFFF) else Color(0x14000000),
        edgeB = if (dark) Color(0x08FFFFFF) else Color(0x08000000),
        glow = if (dark) listOf(Color(0xFF202024), Color(0xFF242428), Color(0xFF1C1C1E)) else listOf(Color(0xFFF2F2F7), Color(0xFFFFFFFF), Color(0xFFF8F8FA))
    )
    val cs = if (dark) darkColorScheme(primary = p.accent, secondary = p.glow.last(), background = p.bg, surface = p.sheet, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p, LocalAnimationIntensity provides animationIntensity.coerceIn(0, 2)) { MaterialTheme(colorScheme = cs, content = content) }
}

fun paletteColor(i: Int): Color = PaletteAccent[i.coerceIn(0, PaletteAccent.size - 1)]
