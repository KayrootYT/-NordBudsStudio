package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color,
    val sheet: Color, val edgeA: Color, val edgeB: Color, val glow: List<Color>, val amoled: Boolean = false
)

// One consistent visual identity. Only system Light and Dark modes are supported.
val PaletteNames = listOf("System Blue")
private val SystemBlue = Color(0xFF0A84FF)
private val NeutralGlow = listOf(Color(0xFF202124), Color(0xFF25272B), Color(0xFF1C1C1E))

fun makePal(dark: Boolean, idx: Int, amoled: Boolean = false, visualStyle: Int = 0): Pal {
    val accent = SystemBlue
    return if (dark) Pal(
        true,
        if (amoled) Color(0xFF000000) else Color(0xFF0B0C0F),
        if (amoled) Color(0xFF101114) else Color(0xFF17191D),
        if (amoled) Color(0xFF191B20) else Color(0xFF22252B),
        Color(0xFFF5F6F8), Color(0xFFA2A6AF),
        Color(0xFF30343B), Color(0xFF3A3F48), accent, Color(0x332D8CFF),
        Color(0xFF30D49A), Color(0xFFFFC15A), Color(0xFF17191D),
        Color(0x24FFFFFF), Color(0x08FFFFFF), NeutralGlow, amoled
    ) else Pal(
        false, Color(0xFFF4F5F7), Color(0xFFFFFFFF), Color(0xFFEBEDF0),
        Color(0xFF17191D), Color(0xFF737984), Color(0xFFE0E3E8), Color(0xFFD0D5DD),
        accent, Color(0x1F0A84FF), Color(0xFF16865B), Color(0xFFAE6C00),
        Color(0xFFFFFFFF), Color(0x99FFFFFF), Color(0x0A000000),
        listOf(Color(0xFFF1F3F6), Color(0xFFFFFFFF), Color(0xFFF4F5F7))
    )
}

val LocalPal = staticCompositionLocalOf { makePal(true, 0) }
val LocalAnimationIntensity = staticCompositionLocalOf { 1 }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, accentIdx: Int, amoled: Boolean = false, visualStyle: Int = 0, animationIntensity: Int = 1, content: @Composable () -> Unit) {
    val p = makePal(dark, 0, amoled)
    val cs = if (dark) darkColorScheme(
        primary = p.accent, secondary = p.accent, background = p.bg,
        surface = p.card, onSurface = p.text, onBackground = p.text
    ) else lightColorScheme(
        primary = p.accent, secondary = p.accent, background = p.bg,
        surface = p.card, onSurface = p.text, onBackground = p.text
    )
    CompositionLocalProvider(
        LocalPal provides p,
        LocalAnimationIntensity provides animationIntensity.coerceIn(0, 2)
    ) { MaterialTheme(colorScheme = cs, content = content) }
}

fun paletteColor(i: Int): Color = SystemBlue
