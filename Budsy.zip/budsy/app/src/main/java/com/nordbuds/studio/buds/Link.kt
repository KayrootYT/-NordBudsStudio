package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.nordbuds.studio.protocol.Protocol
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Classic Bluetooth RFCOMM control transport (the same channel HeyMelody uses).
 *
 * The earbuds publish a vendor service record (0000079a-d102-11e1-9b23-00025b00a5a5). That is tried first,
 * then plain SPP, then any other record the device lists. Each one is tried secure, then insecure.
 */
@SuppressLint("MissingPermission")
class Link(
    @Suppress("unused") private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var context: Context? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    @Volatile private var generation = 0
    private var seq = 0
    private val lock = Any()
    private var writer: ExecutorService = Executors.newSingleThreadExecutor()

    fun setContext(ctx: Context) { context = ctx.applicationContext }

    private fun adapter(): BluetoothAdapter? =
        try { context?.getSystemService(BluetoothManager::class.java)?.adapter } catch (_: Exception) { null }

    /** Opens the control channel. Returns the device on success, null when no record could be opened. */
    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = true)
        val token = synchronized(lock) { generation += 1; expectedClose = false; seq = 0; generation }
        // Discovery slows down and often breaks RFCOMM connects.
        try { adapter()?.cancelDiscovery() } catch (_: Exception) { }
        val advertised = try { device.uuids?.map { it.uuid } ?: emptyList() } catch (_: Exception) { emptyList() }
        for (uuid in orderCandidates(advertised)) {
            for (secure in booleanArrayOf(true, false)) {
                if (token != generation) return@withContext null
                val started = System.currentTimeMillis()
                var s: BluetoothSocket? = null
                try {
                    val sock = if (secure) device.createRfcommSocketToServiceRecord(uuid) else device.createInsecureRfcommSocketToServiceRecord(uuid)
                    s = sock
                    sock.connect()
                    val input = sock.inputStream
                    val output = sock.outputStream
                    val stale = synchronized(lock) {
                        if (token != generation) true else { socket = sock; out = output; active = true; false }
                    }
                    if (stale) { try { sock.close() } catch (_: Exception) { }; return@withContext null }
                    startReader(sock, input, token)
                    return@withContext device
                } catch (_: Exception) {
                    try { s?.close() } catch (_: Exception) { }
                }
                // A slow failure means the earbuds are not reachable at all: stop instead of trying every record.
                if (System.currentTimeMillis() - started > SLOW_FAIL_MS) return@withContext null
            }
        }
        null
    }

    private fun startReader(s: BluetoothSocket, input: InputStream, token: Int) {
        Thread({
            val parser = Protocol.Parser()
            val buf = ByteArray(1024)
            try {
                while (token == generation) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n > 0) parser.feed(buf, n).forEach { if (token == generation) onFrame(it) }
                }
            } catch (_: Exception) { }
            val lost = synchronized(lock) {
                if (token == generation && active) { active = false; true } else false
            }
            if (lost) {
                try { s.close() } catch (_: Exception) { }
                if (!expectedClose) onDropped("Earbuds link lost")
            }
        }, "budsy-rfcomm-reader").apply { isDaemon = true }.start()
    }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        val packet = synchronized(lock) {
            if (!active) return
            val p = Protocol.buildFrame(cmd, group, seq, payload)
            seq = (seq + 1) and 0xff
            p
        }
        val token = generation
        try {
            writer.execute {
                val o = out
                if (token != generation || o == null) return@execute
                try { o.write(packet); o.flush() } catch (_: Exception) {
                    val lost = synchronized(lock) { if (token == generation && active) { active = false; true } else false }
                    if (lost) { try { socket?.close() } catch (_: Exception) { }; if (!expectedClose) onDropped("Could not send to earbuds") }
                }
            }
        } catch (_: Exception) { }
    }

    fun close(expected: Boolean = true) {
        val s: BluetoothSocket?
        synchronized(lock) {
            expectedClose = expected; active = false; generation += 1
            s = socket; socket = null; out = null
        }
        try { s?.close() } catch (_: Exception) { }
    }

    companion object {
        private const val SLOW_FAIL_MS = 4000L
        val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")
        val VENDOR: UUID = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5")
        /** 16-bit ids of audio / OBEX style records that never carry the control channel. */
        private val SKIP_SHORT = setOf(0x1108, 0x110a, 0x110b, 0x110c, 0x110d, 0x110e, 0x110f, 0x1112, 0x111e, 0x111f)

        private val BASE_LSB = UUID.fromString("00000000-0000-1000-8000-00805f9b34fb").leastSignificantBits

        /** 16-bit id for UUIDs built on the Bluetooth base UUID, otherwise null (vendor UUIDs). */
        private fun shortId(u: UUID): Int? {
            val msb = u.mostSignificantBits
            return if (u.leastSignificantBits == BASE_LSB && (msb and 0xFFFFFFFFL) == 0x1000L && (msb ushr 48) == 0L) ((msb ushr 32) and 0xFFFFL).toInt() else null
        }

        /** Vendor record first, then SPP, then the other advertised records (audio profiles removed, duplicates dropped). */
        fun orderCandidates(advertised: List<UUID>): List<UUID> {
            val out = LinkedHashSet<UUID>()
            if (advertised.contains(VENDOR)) out.add(VENDOR)
            out.add(SPP)
            advertised.forEach { u -> val id = shortId(u); if (id == null || id !in SKIP_SHORT) out.add(u) }
            return out.toList()
        }
    }
}
