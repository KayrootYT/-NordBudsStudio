package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.os.Build
import com.nordbuds.studio.protocol.Protocol
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

/** BLE GATT control link for the OnePlus/OPPO earbud command service. */
@SuppressLint("MissingPermission")
class Link(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var writeChar: BluetoothGattCharacteristic? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    @Volatile private var generation = 0
    private val sequence = AtomicInteger(0x20)
    private val lock = Any()
    private val parser = Protocol.Parser()
    private val descriptorQueue = ArrayDeque<Pair<BluetoothGattDescriptor, ByteArray>>()
    private var ready = CompletableDeferred<Boolean>()

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = false)
        expectedClose = false
        active = false
        ready = CompletableDeferred()
        val token = synchronized(lock) { ++generation }
        try {
            val newGatt = device.connectGatt(context, false, callback(token), BluetoothDevice.TRANSPORT_LE)
            synchronized(lock) { if (token == generation) gatt = newGatt else newGatt.close() }
            val ok = withTimeout(18_000) { ready.await() }
            if (!ok || token != generation) {
                close(expected = false)
                return@withContext null
            }
            active = true
            delay(250)
            // HeyMelody protocol reference: notifications are enabled before handshake.
            // The reference handshake bytes include their own framing/check byte; don't wrap them again.
            writeRaw(HELLO)
            delay(2_000)
            if (token != generation || !active) return@withContext null
            writeRaw(REGISTER)
            delay(1_500)
            if (token == generation && active) device else null
        } catch (e: CancellationException) {
            close(expected = false)
            throw e
        } catch (_: Exception) {
            close(expected = false)
            null
        }
    }

    private fun callback(token: Int) = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (token != generation) { g.close(); return }
            if (status != BluetoothGatt.GATT_SUCCESS || newState == BluetoothProfile.STATE_DISCONNECTED) {
                ready.complete(false)
                val notify = active && !expectedClose
                active = false
                synchronized(lock) { if (gatt === g) gatt = null; writeChar = null }
                try { g.close() } catch (_: Exception) { }
                if (notify) onDropped("BLE GATT disconnected (status $status)")
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (token != generation) return
            if (status != BluetoothGatt.GATT_SUCCESS) { ready.complete(false); return }
            val service = g.getService(SERVICE_UUID)
            val characteristic = service?.getCharacteristic(WRITE_UUID)
            if (characteristic == null) { ready.complete(false); return }
            if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE == 0 &&
                characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE == 0) {
                ready.complete(false); return
            }
            synchronized(lock) { if (token == generation) writeChar = characteristic }

            // Subscribe to notify/indicate characteristics on the command service and FE2C telemetry service.
            val notifyChars = g.services.orEmpty().filter { it.uuid == SERVICE_UUID || it.uuid == FE2C_SERVICE_UUID }
                .flatMap { it.characteristics }
                .filter { c -> c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 }
            synchronized(lock) {
                descriptorQueue.clear()
                notifyChars.forEach { c ->
                    try {
                        g.setCharacteristicNotification(c, true)
                        val descriptor = c.getDescriptor(CCCD_UUID)
                        if (descriptor != null) {
                            val value = if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0 &&
                                c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                            else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            descriptorQueue.addLast(descriptor to value)
                        }
                    } catch (_: Exception) { }
                }
            }
            writeNextDescriptor(g, token)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (token != generation) return
            writeNextDescriptor(g, token)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (token != generation) return
            @Suppress("DEPRECATION")
            val bytes = characteristic.value ?: return
            handleIncoming(bytes)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (token != generation) return
            handleIncoming(value)
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (token == generation && status == BluetoothGatt.GATT_SUCCESS) handleIncoming(value)
        }
    }

    private fun writeNextDescriptor(g: BluetoothGatt, token: Int) {
        if (token != generation) return
        val next = synchronized(lock) { if (descriptorQueue.isEmpty()) null else descriptorQueue.removeFirst() }
        if (next == null) {
            ready.complete(true)
            return
        }
        try {
            val (descriptor, value) = next
            val result = if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(descriptor, value) else {
                @Suppress("DEPRECATION")
                descriptor.value = value
                @Suppress("DEPRECATION")
                if (g.writeDescriptor(descriptor)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
            }
            if (Build.VERSION.SDK_INT >= 33 && result != BluetoothStatusCodes.SUCCESS) writeNextDescriptor(g, token)
        } catch (_: Exception) {
            writeNextDescriptor(g, token)
        }
    }

    private fun handleIncoming(bytes: ByteArray) {
        synchronized(lock) {
            parser.feed(bytes).forEach { frame ->
                try { onFrame(frame) } catch (_: Exception) { }
            }
        }
    }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        if (!active) return
        val frame = synchronized(lock) { Protocol.buildFrame(cmd, group, sequence.getAndIncrement() and 0xff, payload) }
        writeRaw(frame)
    }

    private fun writeRaw(bytes: ByteArray) {
        val currentGatt = gatt ?: return
        val characteristic = writeChar ?: return
        try {
            val props = characteristic.properties
            val noResponse = props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
            if (Build.VERSION.SDK_INT >= 33) {
                val writeType = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                val result = currentGatt.writeCharacteristic(characteristic, bytes, writeType)
                if (result != BluetoothStatusCodes.SUCCESS) onDropped("BLE GATT write rejected ($result)")
            } else {
                @Suppress("DEPRECATION")
                characteristic.writeType = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                @Suppress("DEPRECATION")
                if (!currentGatt.writeCharacteristic(characteristic)) onDropped("BLE GATT write rejected")
            }
        } catch (_: Exception) {
            if (active && !expectedClose) onDropped("BLE GATT write failed")
        }
    }

    fun close(expected: Boolean = true) {
        expectedClose = expected
        active = false
        val old: BluetoothGatt?
        synchronized(lock) {
            generation += 1
            old = gatt
            gatt = null
            writeChar = null
            parser.reset()
        }
        ready.complete(false)
        try { old?.disconnect() } catch (_: Exception) { }
        try { old?.close() } catch (_: Exception) { }
    }

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("0000079A-D102-11E1-9B23-00025B00A5A5")
        val WRITE_UUID: UUID = UUID.fromString("0100079A-D102-11E1-9B23-00025B00A5A5")
        val NOTIFY_UUID: UUID = UUID.fromString("0200079A-D102-11E1-9B23-00025B00A5A5")
        val FE2C_SERVICE_UUID: UUID = UUID.fromString("0000FE2C-0000-1000-8000-00805F9B34FB")
        private val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
        // Captured from the supplied OnePlus Buds protocol reference. These are raw complete handshake packets.
        private val HELLO = byteArrayOf(0xAA.toByte(), 0x07, 0x00, 0x00, 0x00, 0x01, 0x23, 0x00, 0x00, 0x12)
        private val REGISTER = byteArrayOf(0xAA.toByte(), 0x0C, 0x00, 0x00, 0x00, 0x85.toByte(), 0x41, 0x05, 0x00, 0x00, 0xB5.toByte(), 0x50, 0xA0.toByte(), 0x69)
    }
}
