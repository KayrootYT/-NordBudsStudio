package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.nordbuds.studio.protocol.Protocol
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** RFCOMM transport for the reverse-engineered control channel. */
@SuppressLint("MissingPermission")
class Link(
    private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    private var seq = 0x20
    @Volatile private var generation = 0
    private val lock = Any()

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = false)
        expectedClose = false
        val token = synchronized(lock) { generation += 1; generation }
        try { device.fetchUuidsWithSdp() } catch (_: Exception) { }
        try { Thread.sleep(500) } catch (_: InterruptedException) { }
        var found = readUuids(device)
        var waited = 0
        while (found.isEmpty() && waited < 6) { try { Thread.sleep(250) } catch (_: InterruptedException) { }; found = readUuids(device); waited++ }
        for (uuid in orderCandidates(found)) {
            // Secure first (what HeyMelody does), then insecure as a fallback for stacks that refuse the secure record.
            for (insecure in booleanArrayOf(false, true)) {
                var s: BluetoothSocket? = null
                val started = System.currentTimeMillis()
                try {
                    s = if (insecure) device.createInsecureRfcommSocketToServiceRecord(uuid) else device.createRfcommSocketToServiceRecord(uuid)
                    s.connect()
                    val input = s.inputStream
                    socket = s; output = s.outputStream; active = true
                    Thread({ reader(input, token) }, "Budsy-Bluetooth-reader-$token").apply { isDaemon = true; start() }
                    return@withContext device
                } catch (_: Exception) {
                    try { s?.close() } catch (_: Exception) { }
                    // A long failure means the earbuds could not be paged (case closed / out of range): stop instead of burning minutes.
                    if (System.currentTimeMillis() - started > 4000) return@withContext null
                }
            }
        }
        null
    }

    private fun readUuids(device: BluetoothDevice): List<UUID> =
        try { device.uuids?.map { it.uuid } ?: emptyList() } catch (_: Exception) { emptyList() }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        val bytes: ByteArray
        synchronized(lock) { bytes = Protocol.buildFrame(cmd, group, seq++ and 0xff, payload) }
        try { synchronized(lock) { output?.write(bytes); output?.flush() } } catch (_: Exception) { close(false); onDropped("Bluetooth control connection lost") }
    }

    private fun reader(input: InputStream, token: Int) {
        val parser = Protocol.Parser(); val buf = ByteArray(512)
        try {
            while (active && token == generation) {
                val n = input.read(buf); if (n < 0) break
                parser.feed(buf.copyOf(n)).forEach { if (token == generation) onFrame(it) }
            }
        } catch (_: Exception) { }
        if (token == generation && active) {
            val shouldNotify = !expectedClose
            close(false)
            if (shouldNotify) onDropped("Bluetooth disconnected")
        }
    }

    fun close(expected: Boolean = true) {
        expectedClose = expected; active = false
        synchronized(lock) { generation += 1 }
        try { socket?.close() } catch (_: Exception) { }
        socket = null; output = null
    }

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val STANDARD_BASE = "-0000-1000-8000-00805f9b34fb"
        private fun isStandard(u: UUID) = u.toString().lowercase().endsWith(STANDARD_BASE)
        private fun isAudioUuid(u: UUID): Boolean = u.toString().startsWith("0000110") || u.toString().startsWith("0000111")

        /** Vendor (non-standard) records first, then plain SPP, then any other non-audio records as a last resort. */
        internal fun orderCandidates(advertised: List<UUID>): List<UUID> {
            val vendor = advertised.filterNot { isStandard(it) }
            val other = advertised.filter { isStandard(it) && !isAudioUuid(it) && it != SPP_UUID }
            return (vendor + SPP_UUID + other).distinct()
        }
    }
}
