package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import com.nordbuds.studio.protocol.Protocol
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** BLE/GATT control transport based on the reverse-engineered HeyMelody service. */
@SuppressLint("MissingPermission")
class Link(
    private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var context: Context? = null
    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var writeChar: BluetoothGattCharacteristic? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    @Volatile private var seq = 0
    @Volatile private var generation = 0
    private val lock = Any()
    private val writes = java.util.ArrayDeque<ByteArray>()
    private var writing = false
    private val parser = Protocol.Parser()

    fun setContext(ctx: Context) { context = ctx.applicationContext }

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = false)
        expectedClose = false
        repeat(2) { attempt ->
            val token = synchronized(lock) { generation += 1; generation }
            val latch = CountDownLatch(1)
            val result = java.util.concurrent.atomic.AtomicInteger(0) // 1 connected, -1 failed
            var localGatt: BluetoothGatt? = null
            val callback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                    if (token != generation) { try { g.close() } catch (_: Exception) {}; return }
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        result.set(-1); try { g.disconnect(); g.close() } catch (_: Exception) {}; latch.countDown(); return
                    }
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        if (!g.discoverServices()) { result.set(-1); latch.countDown() }
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        val wasActive = active
                        active = false
                        if (wasActive && !expectedClose && token == generation) onDropped("Earbuds BLE connection lost")
                        result.set(-1); latch.countDown()
                    }
                }
                override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                    if (token != generation || status != BluetoothGatt.GATT_SUCCESS) { result.set(-1); latch.countDown(); return }
                    val service = g.getService(SERVICE_UUID)
                    val w = service?.getCharacteristic(WRITE_UUID)
                    val n = service?.getCharacteristic(NOTIFY_UUID)
                    if (w == null || n == null || !g.setCharacteristicNotification(n, true)) { result.set(-1); latch.countDown(); return }
                    writeChar = w
                    val descriptor = n.getDescriptor(CCCD_UUID)
                    if (descriptor == null) { result.set(-1); latch.countDown(); return }
                    val started = if (Build.VERSION.SDK_INT >= 33) {
                        g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        g.writeDescriptor(descriptor)
                    }
                    if (!started) { result.set(-1); latch.countDown() }
                }
                override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
                    if (descriptor.uuid == CCCD_UUID) {
                        if (status == BluetoothGatt.GATT_SUCCESS && token == generation) {
                            gatt = g; active = true; result.set(1); latch.countDown()
                        } else { result.set(-1); latch.countDown() }
                    }
                }
                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    if (characteristic.uuid == NOTIFY_UUID && token == generation) receive(value)
                }
                @Suppress("DEPRECATION")
                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    if (characteristic.uuid == NOTIFY_UUID && token == generation) characteristic.value?.let { receive(it) }
                }
                override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
                    synchronized(lock) { writing = false }
                    if (status != BluetoothGatt.GATT_SUCCESS) onDropped("BLE command write failed") else drainWrites()
                }
            }
            try {
                val ctx = context ?: return@withContext null
                localGatt = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
                           else device.connectGatt(ctx, false, callback)
                gatt = localGatt
                if (latch.await(30, TimeUnit.SECONDS) && result.get() == 1 && active) return@withContext device
            } catch (_: Exception) { }
            try { localGatt?.disconnect(); localGatt?.close() } catch (_: Exception) {}
            gatt = null; writeChar = null; active = false
            if (attempt == 0) Thread.sleep(700)
        }
        null
    }

    private fun receive(bytes: ByteArray) {
        synchronized(parser) { parser.feed(bytes).forEach(onFrame) }
    }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        val packet = synchronized(lock) {
            val key = ((group and 0xff) shl 8) or (cmd and 0xff)
            val bytes = Protocol.buildRawFrame(key, seq, payload)
            seq = (seq + 1) and 0xff
            bytes
        }
        synchronized(lock) { if (!active) return; writes.addLast(packet) }
        drainWrites()
    }

    private fun drainWrites() {
        synchronized(lock) {
            if (writing || !active || writes.isEmpty()) return
            val g = gatt ?: return
            val c = writeChar ?: return
            val packet = writes.removeFirst()
            writing = true
            val started = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, packet, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                c.value = packet
                @Suppress("DEPRECATION")
                g.writeCharacteristic(c)
            }
            if (!started) { writing = false; onDropped("Unable to queue BLE command") }
        }
    }

    fun close(expected: Boolean = true) {
        expectedClose = expected; active = false
        synchronized(lock) { generation += 1; writes.clear(); writing = false }
        val old = gatt
        gatt = null; writeChar = null
        try { old?.disconnect() } catch (_: Exception) {}
        try { old?.close() } catch (_: Exception) {}
    }

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5")
        val WRITE_UUID: UUID = UUID.fromString("0100079a-d102-11e1-9b23-00025b00a5a5")
        val NOTIFY_UUID: UUID = UUID.fromString("0200079a-d102-11e1-9b23-00025b00a5a5")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
