package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.nordbuds.studio.protocol.Protocol
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** RFCOMM transport for the reverse-engineered control channel. */
@SuppressLint("MissingPermission")
class Link(
    private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    private var seq = 0x20
    private val lock = Any()

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = false)
        expectedClose = false
        val uuids = try { device.fetchUuidsWithSdp(); Thread.sleep(500); device.uuids?.map { it.uuid } ?: emptyList() } catch (_: Exception) { emptyList() }
        val candidates = (uuids.filterNot { isAudioUuid(it) } + SPP_UUID).distinct()
        for (uuid in candidates) {
            var s: BluetoothSocket? = null
            try {
                s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                val input = s.inputStream
                socket = s; output = s.outputStream; active = true
                Thread({ reader(input) }, "Budsy-Bluetooth-reader").apply { isDaemon = true; start() }
                return@withContext device
            } catch (_: Exception) { try { s?.close() } catch (_: Exception) {} }
        }
        null
    }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        val bytes: ByteArray
        synchronized(lock) { bytes = Protocol.buildFrame(cmd, group, seq++ and 0xff, payload) }
        try { synchronized(lock) { output?.write(bytes); output?.flush() } } catch (_: Exception) { close(false); onDropped("Bluetooth control connection lost") }
    }

    private fun reader(input: InputStream) {
        val parser = Protocol.Parser(); val buf = ByteArray(512)
        try {
            while (active) {
                val n = input.read(buf); if (n < 0) break
                parser.feed(buf.copyOf(n)).forEach(onFrame)
            }
        } catch (_: Exception) { }
        if (active) { close(false); if (!expectedClose) onDropped("Bluetooth disconnected") }
    }

    fun close(expected: Boolean = true) {
        expectedClose = expected; active = false
        try { socket?.close() } catch (_: Exception) { }
        socket = null; output = null
    }

    private fun isAudioUuid(u: UUID): Boolean = u.toString().startsWith("0000110") || u.toString().startsWith("0000111")
    companion object { private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") }
}
