package com.nordbuds.studio

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

// Card-tile design system: gradient glass cards, icon chips that bounce on touch, and a glowing
// gradient border on whatever is active. All continuous animation is read in the draw phase only,
// so idle screens do not recompose.

/** Global feedback switches, set from Settings. */
object Fx {
    @Volatile var sound = true
    @Volatile var haptics = true
}

private fun playBudsyTone(seed: Int = 0) {
    if (!Fx.sound) return
    try {
        val tones = intArrayOf(ToneGenerator.TONE_PROP_ACK, ToneGenerator.TONE_PROP_BEEP, ToneGenerator.TONE_PROP_NACK, ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_7, ToneGenerator.TONE_DTMF_9)
        val gen = ToneGenerator(AudioManager.STREAM_SYSTEM, 35)
        gen.startTone(tones[kotlin.math.abs(seed) % tones.size], 65)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ try { gen.release() } catch (_: Exception) {} }, 120)
    } catch (_: Exception) {}
}

/** Returns a function that gives haptic + tone feedback for a tap. */
@Composable
fun rememberFeedback(): (Int) -> Unit {
    val haptic = LocalHapticFeedback.current
    return remember(haptic) {
        { seed: Int ->
            if (Fx.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            playBudsyTone(seed)
        }
    }
}

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color, size.sp, fontWeight = weight, textAlign = align,
    lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
    letterSpacing = spacing.sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

// ---------------------------------------------------------------- motion helpers

/** Fade + slide-up entrance, staggered by [index]. Replays whenever the screen is opened. */
fun Modifier.enter(index: Int = 0): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index * 55L); a.animateTo(1f, tween(420, easing = FastOutSlowInEasing)) }
    this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 36f }
}

/** 0..1 glow level, pulsing while [active]. Returned as a lambda so it is only read while drawing. */
@Composable
fun rememberGlow(active: Boolean): () -> Float {
    val level = animateFloatAsState(if (active) 1f else 0f, tween(350), label = "glowLevel")
    val pulse = if (active) rememberInfiniteTransition(label = "pulse").animateFloat(
        0.45f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseV"
    ) else null
    return { level.value * (pulse?.value ?: 1f) }
}

/** Soft outer glow around a rounded card (layered translucent strokes, works on every API level). */
fun Modifier.glowBorder(radius: Dp, c1: Color, c2: Color, glow: () -> Float): Modifier = this.drawBehind {
    val g = glow()
    if (g > 0.01f) {
        val brush = Brush.linearGradient(listOf(c1, c2))
        val r = CornerRadius(radius.toPx())
        listOf(16.dp to 0.05f, 11.dp to 0.08f, 6.dp to 0.13f).forEach { (w, a) ->
            drawRoundRect(brush, Offset.Zero, size, r, alpha = (a * g * 2f).coerceAtMost(1f), style = Stroke(w.toPx()))
        }
    }
}

@Composable
private fun cardBrush(): Brush = Brush.linearGradient(listOf(P.sheet.copy(alpha = 0.98f), P.tile.copy(alpha = if (P.dark) 0.55f else 0.40f)))

/** Standard card chrome: glow (when active), clip, gradient fill and a gradient border when active. */
@Composable
private fun Modifier.card(radius: Dp, active: Boolean, glow: () -> Float): Modifier {
    val shape = RoundedCornerShape(radius)
    val accent = P.accent; val accent2 = P.accent2
    val border: Brush = if (active) Brush.linearGradient(listOf(accent, accent2)) else SolidColor(P.line.copy(alpha = 0.8f))
    return this.glowBorder(radius, accent, accent2, glow).clip(shape).background(cardBrush())
        .border(if (active) 1.5.dp else 1.dp, border, shape)
}

// ---------------------------------------------------------------- touch feedback

/** Row tap: springy squash while pressed. */
fun Modifier.tapRow(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val s by animateFloatAsState(if (pressed && enabled) 0.96f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "rowTap")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .background(if (pressed && enabled) P.line.copy(alpha = 0.35f) else Color.Transparent)
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { fb(0); onClick() } }
}

/** Button tap: bounces down and springs back past 1.0. */
fun Modifier.tapFade(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val s by animateFloatAsState(if (pressed && enabled) 0.90f else 1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMedium), label = "tapBounce")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { fb(0); onClick() } }
}

// ---------------------------------------------------------------- layout

/** Scrollable page body used by every tab. */
@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(top = 4.dp, bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    content = content
)

/** Heading above a group of cards: accent icon, small caps title and an optional one-line detail. */
@Composable
fun SectionLabel(text: String, icon: ImageVector? = null, detail: String? = null) {
    Column(Modifier.fillMaxWidth().padding(start = 4.dp, top = 14.dp).enter(1)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Icon(icon, null, tint = P.accent, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(7.dp)) }
            Txt(text.uppercase(), 12, FontWeight.Bold, P.sub, spacing = 1.2f, maxLines = 1)
        }
        if (!detail.isNullOrBlank()) Txt(detail, 12, color = P.sub, modifier = Modifier.padding(top = 2.dp), lineHeight = 16)
    }
}

/** Small grey note under a group of cards. */
@Composable
fun SectionNote(text: String) {
    Txt(text, 12, FontWeight.Normal, P.sub, Modifier.padding(start = 6.dp, end = 6.dp), lineHeight = 17)
}

@Composable
fun Divider() = HorizontalDivider(color = P.line, thickness = 0.5.dp, modifier = Modifier.padding(start = 16.dp))

@Composable
fun FullDivider() = HorizontalDivider(color = P.line, thickness = 0.5.dp)

/** Gradient glass card that groups tiles and controls. */
@Composable
fun GlassPanel(modifier: Modifier = Modifier, index: Int = 0, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.fillMaxWidth().enter(index)
            .shadow(if (P.dark) 0.dp else 8.dp, shape, clip = false, ambientColor = P.accent.copy(alpha = 0.25f), spotColor = P.accent.copy(alpha = 0.25f))
            .clip(shape)
            .background(Brush.linearGradient(listOf(P.sheet.copy(alpha = 0.98f), P.tile.copy(alpha = if (P.dark) 0.70f else 0.55f))))
            .border(1.dp, Brush.linearGradient(listOf(P.accent.copy(alpha = 0.35f), P.line, P.accent2.copy(alpha = 0.30f))), shape)
            .padding(14.dp),
        content = content
    )
}

// ---------------------------------------------------------------- icons

/**
 * Round icon chip. Bounces (squash + tilt) while pressed, pops with an overshoot when it becomes active,
 * and shows a radial glow behind it while glowing.
 */
@Composable
fun BounceIcon(
    icon: ImageVector, active: Boolean, box: Dp = 44.dp, pressed: Boolean = false,
    glow: () -> Float = { 0f }, idleTint: Color = P.sub, plain: Boolean = false
) {
    val pop = remember { Animatable(1f) }
    LaunchedEffect(active) {
        if (active) { pop.snapTo(0.55f); pop.animateTo(1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessLow)) }
    }
    val press by animateFloatAsState(if (pressed) 0.72f else 1f, spring(0.28f, 700f), label = "iconPress")
    val tilt by animateFloatAsState(if (pressed) -14f else 0f, spring(0.25f, 500f), label = "iconTilt")
    val accent = P.accent; val accent2 = P.accent2
    val chip: Brush = when {
        active -> Brush.linearGradient(listOf(accent, accent2))
        plain -> SolidColor(Color.Transparent)
        else -> SolidColor(idleTint.copy(alpha = 0.13f))
    }
    Box(
        Modifier.size(box)
            .graphicsLayer { val s = pop.value * press; scaleX = s; scaleY = s; rotationZ = tilt }
            .drawBehind {
                val g = glow()
                if (g > 0.01f) {
                    val rad = size.minDimension * 0.95f
                    drawCircle(Brush.radialGradient(colors = listOf(accent.copy(alpha = 0.55f * g), Color.Transparent), center = center, radius = rad), rad)
                }
            }
            .clip(CircleShape).background(chip),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = if (active) Color.White else if (plain) P.sub else idleTint, modifier = Modifier.size(box * 0.52f))
    }
}

/** Connection dot with an expanding ring while [pulsing]. */
@Composable
fun PulseDot(color: Color, pulsing: Boolean, dot: Dp = 8.dp) {
    val t = rememberInfiniteTransition(label = "dot")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "dotP")
    Canvas(Modifier.size(dot * 2.4f)) {
        val r = dot.toPx() / 2f
        if (pulsing) drawCircle(color.copy(alpha = (1f - p) * 0.5f), r + r * 1.2f * p, center)
        drawCircle(color, r, center)
    }
}

// ---------------------------------------------------------------- tiles

/** Selectable card tile: icon chip, title, subtitle. Bounces on touch, glows with a gradient border when active. */
@Composable
fun FeatureTile(
    title: String, subtitle: String, icon: ImageVector, active: Boolean, modifier: Modifier = Modifier,
    toneSeed: Int = title.hashCode(), height: Dp = 104.dp, onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.90f else 1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMedium), label = "tileBounce")
    val glow = rememberGlow(active)
    val fb = rememberFeedback()
    val shape = RoundedCornerShape(20.dp)
    val accent = P.accent; val accent2 = P.accent2
    val border: Brush = if (active) Brush.linearGradient(listOf(accent, accent2)) else SolidColor(P.line.copy(alpha = 0.8f))
    Box(
        modifier.height(height)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .glowBorder(20.dp, accent, accent2, glow)
            .clip(shape)
            .background(P.sheet.copy(alpha = if (P.dark) 0.96f else 0.98f))
            .drawBehind {
                val g = glow()
                if (g > 0f) drawRect(Brush.linearGradient(listOf(accent.copy(alpha = 0.10f + 0.12f * g), accent2.copy(alpha = 0.04f + 0.08f * g))))
            }
            .border(if (active) 1.5.dp else 1.dp, border, shape)
            .clickable(interactionSource = src, indication = null) { fb(toneSeed); onClick() }
            .padding(horizontal = 6.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            BounceIcon(icon, active, 42.dp, pressed, glow)
            Spacer(Modifier.height(6.dp))
            Txt(title, 13, FontWeight.SemiBold, if (active) P.accent else P.text, maxLines = 1, align = TextAlign.Center)
            if (subtitle.isNotBlank()) Txt(subtitle, 10, color = if (active) P.accent.copy(alpha = 0.85f) else P.sub, maxLines = 2, lineHeight = 12, align = TextAlign.Center)
        }
        if (active) Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(7.dp).clip(CircleShape).background(P.accent))
    }
}

private fun rowIcon(title: String): ImageVector = when {
    title.contains("single", true) -> Icons.Rounded.TouchApp
    title.contains("double", true) -> Icons.Rounded.Fingerprint
    title.contains("triple", true) -> Icons.Rounded.MoreHoriz
    title.contains("hold", true) -> Icons.Rounded.PanTool
    title.contains("noise", true) -> Icons.Rounded.Waves
    title.contains("find", true) -> Icons.Rounded.LocationSearching
    title.contains("game", true) -> Icons.Rounded.SportsEsports
    title.contains("equal", true) || title.contains("sound", true) -> Icons.Rounded.GraphicEq
    title.contains("firmware", true) || title.contains("update", true) -> Icons.Rounded.SystemUpdate
    title.contains("connect", true) || title.contains("bluetooth", true) -> Icons.Rounded.Bluetooth
    title.contains("tutorial", true) || title.contains("learn", true) -> Icons.Rounded.School
    else -> Icons.Rounded.Tune
}

/** Card row: icon chip, title, value and an optional chevron. Pass [onClick] to make it tappable. */
@Composable
fun ValueRow(title: String, value: String, chevron: Boolean = true, icon: ImageVector? = null, glow: Boolean = false, onClick: (() -> Unit)? = null) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(glow)
    val scale by animateFloatAsState(if (pressed && onClick != null) 0.96f else 1f, spring(0.42f, 450f), label = "rowBounce")
    Row(
        Modifier.fillMaxWidth().enter().graphicsLayer { scaleX = scale; scaleY = scale }
            .card(20.dp, glow, g)
            .then(if (onClick != null) Modifier.clickable(interactionSource = src, indication = null) { fb(title.hashCode()); onClick() } else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon ?: rowIcon(title), glow, 40.dp, pressed, g, P.accent)
        Spacer(Modifier.width(12.dp))
        Txt(title, 15, FontWeight.Medium, P.text, Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        if (value.isNotBlank()) Txt(value, 14, FontWeight.Normal, P.sub, Modifier.widthIn(max = 160.dp), align = TextAlign.End)
        if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = P.sub.copy(alpha = 0.7f), modifier = Modifier.size(22.dp))
    }
}

/** Toggle with a gradient track and a bouncy thumb. */
@Composable
fun IosSwitch(on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 20.dp else 0.dp, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "thumb")
    val t by animateFloatAsState(if (on) 1f else 0f, tween(250), label = "swTrack")
    val fb = rememberFeedback()
    val accent = P.accent; val accent2 = P.accent2
    Box(
        Modifier.alpha(if (enabled) 1f else .5f).size(51.dp, 31.dp).clip(CircleShape).background(P.track)
            .drawBehind { drawRect(Brush.horizontalGradient(listOf(accent, accent2)), alpha = t) }
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { fb(if (on) 31 else 32); onChange(!on) }
            .padding(2.dp)
    ) {
        Box(Modifier.offset(x = x).size(27.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

/** Card row with icon chip and a toggle. Glows while on. */
@Composable
fun SwitchRow(title: String, sub: String?, on: Boolean, enabled: Boolean = true, icon: ImageVector? = null, badge: String? = null, onChange: (Boolean) -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(on && enabled)
    val scale by animateFloatAsState(if (pressed && enabled) 0.97f else 1f, spring(0.42f, 450f), label = "swRow")
    Row(
        Modifier.fillMaxWidth().enter().graphicsLayer { scaleX = scale; scaleY = scale }
            .card(20.dp, on && enabled, g)
            .clickable(interactionSource = src, indication = null, enabled = enabled) { fb(if (on) 31 else 32); onChange(!on) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon ?: rowIcon(title), on && enabled, 40.dp, pressed, g)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(title, 16, FontWeight.Medium, P.text, Modifier.weight(1f, fill = false), maxLines = 2)
                if (badge != null) {
                    Spacer(Modifier.width(8.dp))
                    Txt(badge.uppercase(), 9, FontWeight.Bold, P.amber, Modifier.clip(CircleShape).background(P.amber.copy(alpha = 0.15f)).padding(horizontal = 7.dp, vertical = 2.dp), maxLines = 1, spacing = 0.6f)
                }
            }
            if (sub != null) Txt(sub, 12, lineHeight = 16)
        }
        Spacer(Modifier.width(10.dp))
        IosSwitch(on, enabled, onChange)
    }
}

// ---------------------------------------------------------------- buttons

/** Rounded-rectangle button. Filled = glowing gradient, otherwise a soft tile. */
@Composable
fun WideButton(text: String, filled: Boolean = true, enabled: Boolean = true, destructive: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    val fg = when { filled -> Color.White; destructive -> P.red; else -> P.accent }
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().height(52.dp).alpha(if (enabled) 1f else 0.4f).tapFade(enabled, onClick)
            .then(if (filled) Modifier.shadow(8.dp, shape, clip = false, ambientColor = P.accent, spotColor = P.accent) else Modifier)
            .clip(shape)
            .background(if (filled) Brush.linearGradient(listOf(P.accent, P.accent2)) else SolidColor(P.tile))
            .then(if (!filled) Modifier.border(1.dp, P.line, shape) else Modifier),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Txt(text, 16, FontWeight.SemiBold, fg, maxLines = 1)
    }
}

/** Compact pill button. */
@Composable
fun SmallButton(text: String, filled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.tapFade(onClick = onClick).clip(CircleShape)
            .background(if (filled) Brush.linearGradient(listOf(P.accent, P.accent2)) else SolidColor(P.tile))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = if (filled) Color.White else P.accent, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
        Txt(text, 14, FontWeight.SemiBold, if (filled) Color.White else P.accent, maxLines = 1)
    }
}

/** Large pill button with an optional icon. */
@Composable
fun AccentPill(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.tapFade(onClick = onClick)
            .shadow(10.dp, CircleShape, clip = false, ambientColor = P.accent, spotColor = P.accent)
            .clip(CircleShape).background(Brush.linearGradient(listOf(P.accent, P.accent2))).padding(horizontal = 28.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Txt(text, 16, FontWeight.SemiBold, Color.White, maxLines = 1)
    }
}

// ---------------------------------------------------------------- segmented control (icon tiles)

/** A row of equal icon tiles; the selected one glows. Items without an icon get a generic one. */
@Composable
fun Segmented(items: List<Pair<ImageVector?, String>>, sel: Int, modifier: Modifier = Modifier, onSel: (Int) -> Unit) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, (icon, label) ->
            FeatureTile(label, "", icon ?: Icons.Rounded.Tune, i == sel, Modifier.weight(1f), toneSeed = 50 + i, height = 78.dp) { onSel(i) }
        }
    }
}

// ---------------------------------------------------------------- battery

/** Animated ring gauge with percentage, charging bolt and label. Three sit side by side (L, R, case). */
@Composable
fun BatteryStat(pct: Int, charging: Boolean, label: String, modifier: Modifier = Modifier, desc: String = label, icon: ImageVector = Icons.Rounded.Headphones) {
    val tint = if (charging) P.green else if (pct in 0..19) P.amber else P.green
    val target = if (pct < 0) 0f else pct.coerceAtMost(100) / 100f
    val prog by animateFloatAsState(target, tween(900, easing = FastOutSlowInEasing), label = "battery")
    val bolt by rememberInfiniteTransition(label = "bat").animateFloat(0.4f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "bolt")
    val track = P.track
    Column(
        modifier.semantics(mergeDescendants = true) { contentDescription = desc }.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 7.dp.toPx()
                val inset = w / 2f + 5.dp.toPx()
                val d = size.minDimension - inset * 2f
                val tl = Offset(inset, inset)
                val sz = Size(d, d)
                drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                if (prog > 0f) {
                    drawArc(tint.copy(alpha = 0.25f * (if (charging) bolt else 1f)), -90f, 360f * prog, false, tl, sz, style = Stroke(w + 6.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(tint, -90f, 360f * prog, false, tl, sz, style = Stroke(w, cap = StrokeCap.Round))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Txt(if (pct < 0) "—" else "$pct%", 16, FontWeight.Bold, P.text, maxLines = 1)
                if (charging) Icon(Icons.Rounded.Bolt, null, tint = P.green, modifier = Modifier.size(13.dp).graphicsLayer { alpha = bolt })
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = P.sub, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Txt(label, 12, FontWeight.Medium, P.sub, maxLines = 1)
        }
    }
}

// ---------------------------------------------------------------- drawing

/** A flat stem-style earbud. The accent disc is the touch area and pulses so people know where to tap. */
@Composable
fun BudArt(right: Boolean, height: Dp, modifier: Modifier = Modifier, touchSpot: Boolean = false) {
    val accent = P.accent; val accent2 = P.accent2
    val body = if (P.dark) Color(0xFF636366) else Color(0xFFC7C7CC)
    val hole = if (P.dark) Color(0xFF2C2C2E) else Color(0xFF8E8E93)
    val pulse by rememberInfiniteTransition(label = "bud").animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "budPulse")
    Canvas(modifier.size(height * 0.86f, height)) {
        val s = if (right) -1f else 1f
        val w = size.width; val h = size.height; val cx = w / 2
        val headR = w * 0.31f
        val headC = Offset(cx, h * 0.30f)
        val stemW = w * 0.17f
        drawRoundRect(body, Offset(cx + s * w * 0.05f - stemW / 2, h * 0.40f), Size(stemW, h * 0.58f), CornerRadius(stemW / 2))
        drawCircle(body, headR, headC)
        drawCircle(hole, headR * 0.40f, Offset(cx - s * headR * 0.95f, headC.y + headR * 0.15f))
        if (touchSpot) {
            val c = Offset(cx + s * headR * 0.08f, headC.y)
            drawCircle(accent.copy(alpha = (1f - pulse) * 0.35f), headR * (0.5f + 0.55f * pulse), c)
            val k = headR * 0.5f
            drawCircle(Brush.linearGradient(listOf(accent, accent2), start = Offset(c.x - k, c.y - k), end = Offset(c.x + k, c.y + k)), k, c)
        }
    }
}

/** Slow drifting colour blobs behind every screen. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val c1 = P.accent; val c2 = P.accent2; val c3 = P.green
    val k = if (P.dark) 0.20f else 0.13f
    Canvas(modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        fun blob(col: Color, cx: Float, cy: Float, r: Float) =
            drawCircle(Brush.radialGradient(colors = listOf(col.copy(alpha = k), Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
        blob(c1, w * (0.15f + 0.5f * a), h * (0.10f + 0.15f * b), w * 0.75f)
        blob(c2, w * (0.95f - 0.5f * b), h * (0.45f + 0.2f * a), w * 0.70f)
        blob(c3, w * (0.20f + 0.3f * b), h * (0.95f - 0.2f * a), w * 0.60f)
    }
}

// ---------------------------------------------------------------- sheets

/** Bottom sheet. Content scrolls; the optional footer (buttons) stays pinned above the system bars. */
@Composable
fun SheetDialog(onDismiss: () -> Unit, footer: (@Composable ColumnScope.() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onDismiss)
                .systemBarsPadding().imePadding(),
            contentAlignment = Alignment.BottomCenter
        ) {
            val shape = RoundedCornerShape(28.dp)
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)
                    .shadow(16.dp, shape, clip = false, ambientColor = P.accent, spotColor = P.accent)
                    .clip(shape).background(P.sheet)
                    .border(1.dp, Brush.linearGradient(listOf(P.accent.copy(alpha = 0.5f), P.line, P.accent2.copy(alpha = 0.5f))), shape)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 16.dp)
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(36.dp, 5.dp).background(P.track, CircleShape))
                Spacer(Modifier.height(14.dp))
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), content = content)
                if (footer != null) { Spacer(Modifier.height(12.dp)); footer() }
            }
        }
    }
}

@Composable
fun SheetTitle(text: String) {
    Txt(text, 18, FontWeight.Bold, P.text, Modifier.fillMaxWidth().padding(bottom = 12.dp), align = TextAlign.Center)
}

/** Option card with an icon chip. The chosen one glows and shows a bouncing check. */
@Composable
fun OptionCard(title: String, sub: String?, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val g = rememberGlow(selected)
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "optBounce")
    val check by animateFloatAsState(if (selected) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "check")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .card(18.dp, selected, g)
            .clickable(interactionSource = src, indication = null) { fb(title.hashCode()); onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BounceIcon(icon, selected, 40.dp, pressed, g)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Txt(title, 16, FontWeight.Medium, P.text)
            if (!sub.isNullOrBlank()) Txt(sub, 12, lineHeight = 16)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(26.dp).graphicsLayer { scaleX = check; scaleY = check; alpha = check.coerceIn(0f, 1f) }
                .clip(CircleShape).background(Brush.linearGradient(listOf(P.accent, P.accent2))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
    }
}

/** Single-choice option. */
@Composable
fun RadioRow(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) = OptionCard(label, null, icon, selected, onClick)

/** Multi-choice option. */
@Composable
fun CheckRow(title: String, sub: String, icon: ImageVector, checked: Boolean, onClick: () -> Unit) = OptionCard(title, sub, icon, checked, onClick)

// ---------------------------------------------------------------- navigation

/** Floating glass tab bar. The active tab glows and its icon pops. */
@Composable
fun BottomNav(items: List<Triple<Int, ImageVector, String>>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 10.dp), horizontalArrangement = Arrangement.Center) {
        Row(
            Modifier.fillMaxWidth().widthIn(max = 420.dp)
                .shadow(14.dp, shape, clip = false, ambientColor = P.accent.copy(alpha = 0.4f), spotColor = P.accent.copy(alpha = 0.4f))
                .clip(shape).background(P.sheet.copy(alpha = 0.97f))
                .border(1.dp, Brush.linearGradient(listOf(P.accent.copy(alpha = 0.45f), P.line, P.accent2.copy(alpha = 0.45f))), shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEach { (id, icon, label) -> NavItem(id, icon, label, id == selected, Modifier.weight(1f)) { onSelect(id) } }
        }
    }
}

@Composable
private fun NavItem(id: Int, icon: ImageVector, label: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val fb = rememberFeedback()
    val glow = rememberGlow(sel)
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMedium), label = "navBounce")
    val accent = P.accent; val accent2 = P.accent2
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .glowBorder(24.dp, accent, accent2, glow)
            .clip(shape).background(if (sel) accent.copy(alpha = 0.12f) else Color.Transparent)
            .then(if (sel) Modifier.border(1.2.dp, Brush.linearGradient(listOf(accent, accent2)), shape) else Modifier)
            .clickable(interactionSource = src, indication = null) { fb(id + 1); onClick() }
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BounceIcon(icon, sel, 34.dp, pressed, glow, plain = true)
        Spacer(Modifier.height(2.dp))
        Txt(label, 10, if (sel) FontWeight.Bold else FontWeight.Medium, if (sel) P.accent else P.sub, maxLines = 1)
    }
}
