package com.nordbuds.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color, size.sp, fontWeight = weight, textAlign = align,
    lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
    letterSpacing = spacing.sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

/** Scrollable page body used by every tab. */
@Composable
fun Stack(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
    Arrangement.spacedBy(16.dp), content = content
)

/** Frosted glass block with a soft gradient edge. */
@Composable
fun Panel(modifier: Modifier = Modifier, tint: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(P.card)
            .then(if (tint) Modifier.background(Brush.verticalGradient(listOf(P.accent.copy(alpha = 0.22f), Color.Transparent))) else Modifier)
            .border(1.dp, Brush.linearGradient(listOf(P.edgeA, P.edgeB)), shape),
        content = content
    )
}

@Composable
fun SectionLabel(text: String) {
    Txt(text, 15, FontWeight.Normal, P.sub, Modifier.padding(start = 12.dp, top = 6.dp))
}

@Composable
fun Divider() = HorizontalDivider(color = P.line, modifier = Modifier.padding(horizontal = 20.dp))

/** "Title ........ Value >" row. */
@Composable
fun ValueRow(title: String, value: String, chevron: Boolean = true, divider: Boolean = true, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            Modifier.fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 20.dp, vertical = 19.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(title, 18, FontWeight.Normal, P.text, Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            Txt(value, 15, FontWeight.Normal, P.sub, Modifier.widthIn(max = 170.dp), align = TextAlign.End)
            if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = P.sub, modifier = Modifier.size(22.dp))
        }
        if (divider) Divider()
    }
}

@Composable
fun NordSwitch(on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (on) 26.dp else 2.dp, spring(stiffness = 600f), label = "sw")
    val bg by animateColorAsState(if (on) P.accent else P.track, label = "swc")
    Box(
        Modifier.alpha(if (enabled) 1f else .5f).size(54.dp, 30.dp).clip(CircleShape).background(bg)
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { onChange(!on) },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.offset(x = x).size(26.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, on: Boolean, enabled: Boolean = true, divider: Boolean = true, onChange: (Boolean) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(title, 18, FontWeight.Normal, P.text)
                if (sub != null) Txt(sub, 14, lineHeight = 19)
            }
            Spacer(Modifier.width(12.dp))
            NordSwitch(on, enabled, onChange)
        }
        if (divider) Divider()
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape).background(if (selected) P.accent else P.tile)
            .clickable(onClick = onClick).padding(horizontal = 30.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 18, FontWeight.Normal, if (selected) Color.White else P.text) }
}

@Composable
fun SmallButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .then(if (filled) Modifier.background(P.accent) else Modifier.background(P.tile))
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp)
    ) { Txt(text, 14, FontWeight.SemiBold, if (filled) Color.White else P.text) }
}

@Composable
fun WideButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(54.dp).clip(CircleShape)
            .background(if (filled) P.accent else P.tile).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Txt(text, 18, FontWeight.Medium, if (filled) Color.White else P.text) }
}

/** Three-way selector with icons (noise control). */
@Composable
fun Segmented(items: List<Pair<ImageVector, String>>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    BoxWithConstraints(Modifier.fillMaxWidth().clip(shape).background(P.tile).padding(5.dp)) {
        val w = maxWidth / items.size
        val off by animateDpAsState(w * sel.coerceAtLeast(0), spring(dampingRatio = .8f, stiffness = 500f), label = "seg")
        val inner = RoundedCornerShape(18.dp)
        if (sel >= 0) Box(Modifier.offset(x = off).width(w).height(72.dp).clip(inner).background(P.accent))
        Row {
            items.forEachIndexed { i, it ->
                val tint by animateColorAsState(if (sel == i) Color.White else P.sub, label = "segc")
                Column(
                    Modifier.weight(1f).height(72.dp).clip(inner)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Icon(it.first, null, tint = tint, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(4.dp))
                    Txt(it.second, 13, FontWeight.Medium, tint, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun BatteryCard(pct: Int, charging: Boolean, letter: String, label: String, modifier: Modifier = Modifier, desc: String = label) {
    val shown by animateIntAsState(if (pct < 0) 0 else pct, tween(800), label = "bat")
    val low = pct in 0..19
    val tint = if (charging) P.green else if (low) P.amber else P.accent
    val track = P.line
    Row(
        modifier.semantics(mergeDescendants = true) { contentDescription = desc }.clip(RoundedCornerShape(22.dp)).background(P.tile).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Txt(if (pct < 0) "\u2014%" else "$shown%", 28, FontWeight.Medium, P.text, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            Txt(label, 15, color = P.sub, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 6.dp.toPx()
                val tl = Offset(sw / 2, sw / 2)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(track, -90f, 360f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                if (pct >= 0) drawArc(tint, -90f, 360f * shown / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            if (charging) Icon(Icons.Rounded.Bolt, null, tint = tint, modifier = Modifier.size(22.dp))
            else Txt(letter, 14, FontWeight.Medium, P.text, maxLines = 1)
        }
    }
}

/** Slow aurora glow plus a few drifting particles behind everything. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val p = P
    val t = rememberInfiniteTransition(label = "aurora")
    val phase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    val dots = remember {
        val r = java.util.Random(7L)
        List(28) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.4f + r.nextFloat() * 0.9f, 1.2f + r.nextFloat() * 2.2f) }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(p.bg)
        val a = phase.value * 2f * PI.toFloat()
        val k = if (p.amoled) 0.12f else if (p.dark) 0.34f else 0.45f
        fun blob(c: Color, cx: Float, cy: Float, r: Float) {
            val o = Offset(cx, cy)
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = k), Color.Transparent), o, r), r, o)
        }
        blob(p.glow[0], w * (0.15f + 0.18f * cos(a)), h * (0.10f + 0.06f * sin(a)), w * 0.95f)
        blob(p.glow[1], w * (0.90f + 0.12f * sin(a)), h * (0.42f + 0.08f * cos(a)), w * 0.85f)
        blob(p.glow[2], w * (0.30f + 0.15f * sin(a * 2f)), h * (0.92f + 0.05f * cos(a)), w * 0.9f)
        val dot = if (p.dark) Color.White else p.accent
        dots.forEach { d ->
            val y = h * (1f - ((d[1] + phase.value * d[2]) % 1f))
            val x = w * d[0] + 10f * sin(a + d[1] * 6f)
            drawCircle(dot.copy(alpha = if (p.dark) 0.16f else 0.18f), d[3].dp.toPx(), Offset(x, y))
        }
    }
}

/** Fade + slide in, staggered by index. */
@Composable
fun Appear(index: Int, content: @Composable () -> Unit) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 55L); on = true }
    val a by animateFloatAsState(if (on) 1f else 0f, tween(420), label = "ap")
    Box(Modifier.fillMaxWidth().graphicsLayer { alpha = a; translationY = (1f - a) * 40f }) { content() }
}

/** Small round tinted icon holder used on cards. */
@Composable
fun IconTile(icon: ImageVector, size: Int = 52) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(16.dp)).background(P.soft), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = P.accent, modifier = Modifier.size((size * 0.46f).dp))
    }
}

@Composable
fun CapsLabel(text: String, modifier: Modifier = Modifier) =
    Txt(text.uppercase(), 12, FontWeight.Medium, P.sub, modifier, spacing = 1.6f, maxLines = 1)

/** Big pill button in the accent colour. */
@Composable
fun AccentPill(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(P.accent).clickable(onClick = onClick)
            .padding(horizontal = 34.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)) }
        Txt(text, 18, FontWeight.Medium, Color.White, maxLines = 1)
    }
}

// ---------------------------------------------------------------- bottom sheet dialogs

@Composable
fun SheetDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp)
                    .clip(RoundedCornerShape(36.dp)).background(P.sheet)
                    .verticalScroll(rememberScrollState())
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                    .padding(horizontal = 20.dp, vertical = 22.dp),
                content = content
            )
        }
    }
}

@Composable
fun SheetTitle(text: String) {
    Txt(text, 24, FontWeight.Medium, P.text, Modifier.fillMaxWidth().padding(bottom = 10.dp), align = TextAlign.Center)
}

@Composable
fun RadioDot(selected: Boolean) {
    Box(Modifier.size(26.dp).border(if (selected) 6.dp else 2.dp, if (selected) P.accent else P.track, CircleShape))
}

@Composable
fun RadioRow(label: String, selected: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(label, 20, FontWeight.Normal, P.text, Modifier.weight(1f))
            RadioDot(selected)
        }
        if (divider) HorizontalDivider(color = P.line)
    }
}

@Composable
fun CheckBox(checked: Boolean) {
    Box(
        Modifier.size(26.dp).clip(RoundedCornerShape(7.dp))
            .background(if (checked) P.accent else Color.Transparent)
            .border(2.dp, if (checked) P.accent else P.track, RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center
    ) { if (checked) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
}

@Composable
fun CheckRow(title: String, sub: String, checked: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Txt(title, 20, FontWeight.Normal, P.text)
                Txt(sub, 15, lineHeight = 20)
            }
            Spacer(Modifier.width(10.dp))
            CheckBox(checked)
        }
        if (divider) HorizontalDivider(color = P.line)
    }
}

// ---------------------------------------------------------------- drawing

/** A stem-style earbud. The blue disc is the touch area. */
@Composable
fun BudArt(right: Boolean, height: Dp, modifier: Modifier = Modifier, touchSpot: Boolean = false) {
    val accent = P.accent
    Canvas(modifier.size(height * 0.86f, height)) {
        val s = if (right) -1f else 1f
        val w = size.width; val h = size.height; val cx = w / 2
        val headR = w * 0.31f
        val headC = Offset(cx, h * 0.30f)
        val stemW = w * 0.17f
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF3B3D43), Color(0xFF141518)), h * 0.40f, h),
            Offset(cx + s * w * 0.05f - stemW / 2, h * 0.40f), Size(stemW, h * 0.58f), CornerRadius(stemW / 2)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF5A5D64), Color(0xFF1A1B1E)), Offset(cx - s * headR * 0.35f, headC.y - headR * 0.4f), headR * 1.9f),
            headR, headC
        )
        drawCircle(Color(0xFF0E0E10), headR * 0.46f, Offset(cx - s * headR * 0.95f, headC.y + headR * 0.15f))
        if (touchSpot) drawCircle(accent.copy(alpha = .9f), headR * 0.52f, Offset(cx + s * headR * 0.08f, headC.y))
    }
}


// ---------------------------------------------------------------- navigation

/** Floating pill navigation bar. */
@Composable
fun BottomNav(items: List<Triple<Int, ImageVector, String>>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 10.dp, top = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().shadow(14.dp, shape, clip = false).clip(shape).background(P.sheet.copy(alpha = 0.96f))
                .border(1.dp, Brush.linearGradient(listOf(P.edgeA, P.edgeB)), shape).padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEach { (i, icon, label) ->
                val sel = selected == i
                val bg by animateColorAsState(if (sel) P.soft else Color.Transparent, label = "navbg")
                val tint by animateColorAsState(if (sel) P.accent else P.sub, label = "navtint")
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(bg)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSelect(i) }
                        .padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.height(2.dp))
                    Txt(label, 11, if (sel) FontWeight.SemiBold else FontWeight.Medium, tint, maxLines = 1)
                }
            }
        }
    }
}
