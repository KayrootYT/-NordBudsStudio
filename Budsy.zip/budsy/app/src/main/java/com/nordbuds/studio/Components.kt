package com.nordbuds.studio

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// Compact Liquid Glass-inspired cards, subtle depth and springy touch feedback.

private fun playBudsyTone(seed: Int = 0) {
    try {
        val tones = intArrayOf(ToneGenerator.TONE_PROP_ACK, ToneGenerator.TONE_PROP_BEEP, ToneGenerator.TONE_PROP_NACK, ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_7, ToneGenerator.TONE_DTMF_9)
        val gen = ToneGenerator(AudioManager.STREAM_SYSTEM, 35)
        gen.startTone(tones[kotlin.math.abs(seed) % tones.size], 65)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ try { gen.release() } catch (_: Exception) {} }, 120)
    } catch (_: Exception) {}
}

@Composable
fun Txt(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal, color: Color = P.sub,
    modifier: Modifier = Modifier, align: TextAlign? = null, lineHeight: Int = 0,
    spacing: Float = 0f, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color, size.sp, fontWeight = weight, textAlign = align,
    lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
    letterSpacing = spacing.sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

// ---------------------------------------------------------------- touch feedback

/** Row tap: the row greys out while pressed, like a UITableViewCell. */
fun Modifier.tapRow(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    this.graphicsLayer { val target = if (pressed && enabled) 0.975f else 1f; scaleX = target; scaleY = target }
        .background(if (pressed && enabled) P.line.copy(alpha = 0.35f) else Color.Transparent)
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { playBudsyTone(); onClick() } }
}

/** Button tap: fades to 60% while pressed, like a UIButton. */
fun Modifier.tapFade(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    this.graphicsLayer { val target = if (pressed && enabled) 0.92f else 1f; scaleX = target; scaleY = target; alpha = if (pressed && enabled) 0.92f else 1f }
        .clickable(interactionSource = src, indication = null, enabled = enabled) { if (enabled) { playBudsyTone(); onClick() } }
}

// ---------------------------------------------------------------- layout

/** Scrollable page body used by every tab. */
@Composable
fun Stack(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp),
    content = content
)

/** Small grey heading above a group of rows. */
@Composable
fun SectionLabel(text: String) {
    Txt(text.uppercase(), 13, FontWeight.Normal, P.sub, Modifier.padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = 8.dp), maxLines = 1)
}

/** Small grey note under a group of rows. */
@Composable
fun SectionNote(text: String) {
    Txt(text, 13, FontWeight.Normal, P.sub, Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp), lineHeight = 18)
}

@Composable
fun Divider() = HorizontalDivider(color = P.line, thickness = 0.5.dp, modifier = Modifier.padding(start = 16.dp))

@Composable
fun FullDivider() = HorizontalDivider(color = P.line, thickness = 0.5.dp)

/** Compact selectable feature tile: animated icon, active glow, distinct sound cue and spring bounce. */
@Composable
fun FeatureTile(title: String, subtitle: String, icon: ImageVector, active: Boolean, modifier: Modifier = Modifier, toneSeed: Int = title.hashCode(), onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.42f, stiffness = 420f), label = "featureBounce")
    val glow = if (active) P.accent else Color.Transparent
    val pulse = rememberInfiniteTransition(label = "glassPulse")
    val glowAlpha by pulse.animateFloat(initialValue = 0.10f, targetValue = if (active) 0.30f else 0.13f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glowAlpha")
    val iconTilt by animateFloatAsState(if (pressed) -9f else 0f, spring(dampingRatio = 0.35f, stiffness = 500f), label = "iconTilt")
    LaunchedEffect(active) { if (active) playBudsyTone(toneSeed + 3) }
    Column(
        modifier = modifier.height(72.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (active) 12.dp else 3.dp, RoundedCornerShape(18.dp), clip = false)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(
                (if (active) P.accent else P.sheet).copy(alpha = if (active) glowAlpha + 0.12f else 0.92f),
                P.sheet.copy(alpha = if (P.dark) 0.96f else 0.82f),
                P.accent.copy(alpha = if (active) 0.10f else 0.025f)
            )))
            .border(1.dp, if (active) P.accent.copy(alpha = 0.82f) else P.line.copy(alpha = 0.82f), RoundedCornerShape(18.dp))
            .clickable(interactionSource = src, indication = null) { playBudsyTone(toneSeed); onClick() }
            .padding(horizontal = 6.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(27.dp).shadow(if (active) 5.dp else 0.dp, CircleShape).clip(CircleShape)
            .background(if (active) glow.copy(alpha = 0.20f) else P.tile), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (active) P.accent else P.sub, modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = iconTilt })
        }
        Spacer(Modifier.height(2.dp))
        Txt(title, 11, FontWeight.SemiBold, if (active) P.accent else P.text, maxLines = 1, align = TextAlign.Center)
        if (subtitle.isNotBlank()) Txt(subtitle, 9, color = if (active) P.accent.copy(alpha = 0.9f) else P.sub, maxLines = 1, align = TextAlign.Center)
    }
}

private fun rowIcon(title: String): ImageVector = when {
    title.contains("single", true) -> Icons.Rounded.TouchApp
    title.contains("double", true) -> Icons.Rounded.Fingerprint
    title.contains("triple", true) -> Icons.Rounded.MoreHoriz
    title.contains("hold", true) -> Icons.Rounded.PanTool
    title.contains("noise", true) -> Icons.Rounded.Waves
    title.contains("find", true) -> Icons.Rounded.LocationSearching
    title.contains("game", true) -> Icons.Rounded.SportsEsports
    title.contains("equal", true) || title.contains("sound", true) -> Icons.Rounded.GraphicEq
    title.contains("firmware", true) || title.contains("update", true) -> Icons.Rounded.SystemUpdate
    title.contains("connect", true) || title.contains("bluetooth", true) -> Icons.Rounded.Bluetooth
    title.contains("tutorial", true) || title.contains("learn", true) -> Icons.Rounded.School
    else -> Icons.Rounded.Tune
}

/** "Title ........ Value >" compact card row. */
@Composable
fun ValueRow(title: String, value: String, chevron: Boolean = true, divider: Boolean = true, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(16.dp)).background(P.tile.copy(alpha = if (P.dark) 0.72f else 0.62f))
                .then(if (onClick != null) Modifier.tapRow(onClick = onClick) else Modifier)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val active = value.isNotBlank() && value != "—" && !value.equals("None", true) && !value.equals("Off", true)
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(if (active) P.accent.copy(alpha = 0.14f) else P.bg.copy(alpha = 0.65f)), contentAlignment = Alignment.Center) {
                Icon(rowIcon(title), null, tint = if (active) P.accent else P.sub, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.width(10.dp))
            Txt(title, 15, FontWeight.Medium, P.text, Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Txt(value, 17, FontWeight.Normal, P.sub, Modifier.widthIn(max = 170.dp), align = TextAlign.End)
            if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = P.sub.copy(alpha = 0.7f), modifier = Modifier.size(22.dp))
        }
        if (divider) Spacer(Modifier.height(1.dp))
    }
}

/** iOS toggle: 51x31, green when on. */
@Composable
fun IosSwitch(on: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Box(
        Modifier.alpha(if (enabled) 1f else .5f).size(51.dp, 31.dp).clip(CircleShape)
            .background(if (on) P.green else P.track)
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { playBudsyTone(if (on) 31 else 32); onChange(!on) }
            .padding(2.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(Modifier.size(27.dp).background(Color.White, CircleShape))
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, on: Boolean, enabled: Boolean = true, divider: Boolean = true, onChange: (Boolean) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(P.tile.copy(alpha = if (P.dark) 0.72f else 0.62f)).padding(horizontal = 14.dp, vertical = 10.dp).heightIn(min = 34.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(if (on) P.accent.copy(alpha = 0.14f) else P.bg.copy(alpha = 0.65f)), contentAlignment = Alignment.Center) { Icon(rowIcon(title), null, tint = if (on) P.accent else P.sub, modifier = Modifier.size(19.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Txt(title, 17, FontWeight.Normal, P.text)
                if (sub != null) Txt(sub, 13, lineHeight = 17)
            }
            Spacer(Modifier.width(12.dp))
            IosSwitch(on, enabled, onChange)
        }
        if (divider) Divider()
    }
}

// ---------------------------------------------------------------- buttons

/** Rounded-rectangle button. Filled = system blue, otherwise a grey tile. */
@Composable
fun WideButton(text: String, filled: Boolean = true, enabled: Boolean = true, destructive: Boolean = false, icon: ImageVector? = null, onClick: () -> Unit) {
    val fg = when {
        filled -> Color.White
        destructive -> P.red
        else -> P.accent
    }
    Row(
        Modifier.fillMaxWidth().height(50.dp).alpha(if (enabled) 1f else 0.4f).tapFade(enabled, onClick)
            .clip(RoundedCornerShape(14.dp)).background(if (filled) P.accent else P.tile),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Txt(text, 17, FontWeight.SemiBold, fg, maxLines = 1)
    }
}

/** Compact pill button. */
@Composable
fun SmallButton(text: String, filled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.tapFade(onClick = onClick).clip(CircleShape).background(if (filled) P.accent else P.tile)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Txt(text, 15, FontWeight.SemiBold, if (filled) Color.White else P.accent, maxLines = 1) }
}

/** Pill button with an optional icon. */
@Composable
fun AccentPill(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.tapFade(onClick = onClick).clip(CircleShape).background(P.accent).padding(horizontal = 28.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Txt(text, 17, FontWeight.SemiBold, Color.White, maxLines = 1)
    }
}

// ---------------------------------------------------------------- segmented control

/**
 * iOS segmented control. With icons the segments are tall (noise control), without icons they are the
 * regular 32dp text segments.
 */
@Composable
fun Segmented(items: List<Pair<ImageVector?, String>>, sel: Int, modifier: Modifier = Modifier, onSel: (Int) -> Unit) {
    val withIcons = items.any { it.first != null }
    val h = if (withIcons) 62.dp else 34.dp
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(P.tile).padding(2.dp)) {
        items.forEachIndexed { i, (icon, label) ->
            val on = i == sel
            val fg = if (on && withIcons) P.accent else if (on) P.text else if (withIcons) P.sub else P.text
            Column(
                Modifier.weight(1f).height(h).clip(RoundedCornerShape(8.dp))
                    .background(if (on) P.thumb else Color.Transparent)
                    .then(if (on && !P.dark) Modifier.border(0.5.dp, P.line, RoundedCornerShape(8.dp)) else Modifier)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSel(i) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(24.dp)); Spacer(Modifier.height(3.dp)) }
                Txt(label, if (withIcons) 12 else 14, if (on) FontWeight.SemiBold else FontWeight.Medium, fg, maxLines = 1)
            }
        }
    }
}

// ---------------------------------------------------------------- battery

/** Label, percentage and a thin level bar. Three of these sit side by side (L, R, case). */
@Composable
fun BatteryStat(pct: Int, charging: Boolean, label: String, modifier: Modifier = Modifier, desc: String = label) {
    val tint = if (charging) P.green else if (pct in 0..19) P.amber else P.green
    Column(
        modifier.semantics(mergeDescendants = true) { contentDescription = desc }.padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Txt(label, 13, FontWeight.Normal, P.sub, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(if (pct < 0) "—" else "$pct%", 24, FontWeight.SemiBold, P.text, maxLines = 1)
            if (charging) Icon(Icons.Rounded.Bolt, null, tint = P.green, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.width(44.dp).height(6.dp).clip(CircleShape).background(P.track)) {
            if (pct > 0) Box(Modifier.fillMaxHeight().fillMaxWidth(pct.coerceAtMost(100) / 100f).background(tint, CircleShape))
        }
    }
}

// ---------------------------------------------------------------- drawing

/** A flat stem-style earbud. The accent disc is the touch area. */
@Composable
fun BudArt(right: Boolean, height: Dp, modifier: Modifier = Modifier, touchSpot: Boolean = false) {
    val accent = P.accent
    val body = if (P.dark) Color(0xFF636366) else Color(0xFFC7C7CC)
    val hole = if (P.dark) Color(0xFF2C2C2E) else Color(0xFF8E8E93)
    androidx.compose.foundation.Canvas(modifier.size(height * 0.86f, height)) {
        val s = if (right) -1f else 1f
        val w = size.width; val h = size.height; val cx = w / 2
        val headR = w * 0.31f
        val headC = Offset(cx, h * 0.30f)
        val stemW = w * 0.17f
        drawRoundRect(body, Offset(cx + s * w * 0.05f - stemW / 2, h * 0.40f), Size(stemW, h * 0.58f), CornerRadius(stemW / 2))
        drawCircle(body, headR, headC)
        drawCircle(hole, headR * 0.40f, Offset(cx - s * headR * 0.95f, headC.y + headR * 0.15f))
        if (touchSpot) drawCircle(accent, headR * 0.50f, Offset(cx + s * headR * 0.08f, headC.y))
    }
}

// ---------------------------------------------------------------- sheets

/** Bottom sheet. Content scrolls; the optional footer (buttons) stays pinned above the system bars. */
@Composable
fun SheetDialog(onDismiss: () -> Unit, footer: (@Composable ColumnScope.() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onDismiss)
                .systemBarsPadding().imePadding(),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp)).background(P.sheet)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 16.dp)
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).size(36.dp, 5.dp).background(P.track, CircleShape))
                Spacer(Modifier.height(14.dp))
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), content = content)
                if (footer != null) { Spacer(Modifier.height(12.dp)); footer() }
            }
        }
    }
}

@Composable
fun SheetTitle(text: String) {
    Txt(text, 17, FontWeight.SemiBold, P.text, Modifier.fillMaxWidth().padding(bottom = 12.dp), align = TextAlign.Center)
}

/** Single-choice row: the chosen one gets a blue check mark on the right. */
@Composable
fun RadioRow(label: String, selected: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().tapRow(onClick = onClick).padding(horizontal = 4.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(label, 17, FontWeight.Normal, P.text, Modifier.weight(1f))
            if (selected) Icon(Icons.Rounded.Check, null, tint = P.accent, modifier = Modifier.size(24.dp))
        }
        if (divider) HorizontalDivider(color = P.line, thickness = 0.5.dp)
    }
}

/** Multi-choice row, same check mark style. */
@Composable
fun CheckRow(title: String, sub: String, checked: Boolean, divider: Boolean = true, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().tapRow(onClick = onClick).padding(horizontal = 4.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Txt(title, 17, FontWeight.Normal, P.text)
                Txt(sub, 13, lineHeight = 18)
            }
            Spacer(Modifier.width(10.dp))
            if (checked) Icon(Icons.Rounded.Check, null, tint = P.accent, modifier = Modifier.size(24.dp))
            else Spacer(Modifier.size(24.dp))
        }
        if (divider) HorizontalDivider(color = P.line, thickness = 0.5.dp)
    }
}

// ---------------------------------------------------------------- navigation

/** Compact floating glass tab bar with safe-area spacing. */
@Composable
fun BottomNav(items: List<Triple<Int, ImageVector, String>>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 24.dp, end = 24.dp, top = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth().widthIn(max = 390.dp).shadow(12.dp, RoundedCornerShape(25.dp))
            .clip(RoundedCornerShape(25.dp)).background(P.sheet.copy(alpha = 0.96f))
            .border(1.dp, P.line.copy(alpha = 0.7f), RoundedCornerShape(25.dp)).padding(horizontal = 5.dp, vertical = 5.dp)) {
            items.forEach { (id, icon, label) ->
                val sel = id == selected
                val scale by animateFloatAsState(if (sel) 1f else 0.94f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "tabScale")
                Column(Modifier.weight(1f).graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(RoundedCornerShape(19.dp)).background(if (sel) P.accent.copy(alpha = 0.13f) else Color.Transparent)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { playBudsyTone(id + 1); onSelect(id) }
                    .padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = if (sel) P.accent else P.sub, modifier = Modifier.size(21.dp))
                    Spacer(Modifier.height(2.dp))
                    Txt(label, 10, if (sel) FontWeight.SemiBold else FontWeight.Medium, if (sel) P.accent else P.sub, maxLines = 1)
                }
            }
        }
    }
}
