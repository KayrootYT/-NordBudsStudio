package com.nordbuds.studio

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.IntentCompat

/**
 * Reacts to Android's own "device connected / disconnected" broadcasts so Budsy connects its control
 * channel as soon as the earbuds come out of the case, even when the app UI has not been opened.
 */
@SuppressLint("MissingPermission")
class BudsLinkReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (Build.VERSION.SDK_INT >= 31 && app.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val d = IntentCompat.getParcelableExtra(intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) ?: return
        Buds.attach(app)
        val name = try { d.name ?: "" } catch (_: Exception) { "" }
        val known = d.address == Buds.prefs.lastAddr || name.contains("nord buds", ignoreCase = true)
        if (!known) return
        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                try { BudsService.start(app) } catch (_: Throwable) { }
                Buds.autoConnect(d)
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> Buds.onAclDisconnected(d.address)
        }
    }
}
