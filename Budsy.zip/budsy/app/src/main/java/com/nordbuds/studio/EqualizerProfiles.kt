package com.nordbuds.studio

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import com.nordbuds.studio.protocol.Protocol
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.nordbuds.studio.buds.Prefs
import com.nordbuds.studio.buds.SavedEqProfile
import kotlin.math.roundToInt

private val EQ_FREQS = listOf(62, 250, 1000, 4000, 8000, 16000)
private val EQ_LABELS = listOf("62", "250", "1k", "4k", "8k", "16k")
private val TEMPLATES = linkedMapOf(
    "Music" to listOf(3, 1, 1, 3, 3, 2),
    "Movie" to listOf(1, 0, 3, 3, 2, 2),
    "Game" to listOf(3, 0, 3, 5, 3, 2),
    "Podcast" to listOf(-2, 2, 4, 1, 0, -1)
)
private val MANUAL = listOf("Manual 1", "Manual 2", "Manual 3")
private val FLAT = List(6) { 0 }
private const val DRAFT = "Draft"

/** Earbud slot n (1..3): the profile named "Manual n", or by position when the earbuds use other names. */
private fun deviceSlot(n: Int): Protocol.CustomEqProfile? {
    val l = Buds.customEqProfiles
    return l.firstOrNull { it.name.equals("Manual $n", true) }
        ?: if (l.none { it.name.startsWith("Manual ", true) }) l.getOrNull(n - 1) else null
}
/** The earbuds and this screen both use -6..+6 dB. */
private fun slotCurve(n: Int): List<Int>? =
    deviceSlot(n)?.bands?.takeIf { it.size == EQ_FREQS.size }?.map { it.second.coerceIn(-6, 6) }

@Composable
fun SoundMasterEqCard(connected: Boolean, toast: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { Prefs(context) }
    val saved = remember { mutableStateListOf<SavedEqProfile>().apply { addAll(prefs.loadEqProfiles()) } }
    var selected by remember { mutableStateOf("Manual 1") }
    var values by remember { mutableStateOf(FLAT) }
    var target by remember { mutableIntStateOf(1) }
    var editMode by remember { mutableStateOf(false) }
    var dirty by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("Custom 1") }
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    var renameFrom by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }

    fun persist() { prefs.saveEqProfiles(saved.toList()) }
    fun select(name: String) {
        val curve = when {
            name in TEMPLATES -> TEMPLATES.getValue(name)
            name in MANUAL -> { val n = MANUAL.indexOf(name) + 1; target = n; slotCurve(n) ?: saved.firstOrNull { it.name.equals(name, true) }?.values ?: FLAT }
            else -> saved.firstOrNull { it.name == name }?.values ?: values
        }
        selected = name; values = curve.toList(); editMode = false; dirty = false
    }
    val canDrag = selected in TEMPLATES || selected == DRAFT || editMode
    fun changeBand(index: Int, value: Int) {
        if (!canDrag) return
        values = values.toMutableList().also { it[index] = value.coerceIn(-6, 6) }
        dirty = true
        if (selected in TEMPLATES) { selected = DRAFT; profileName = "Custom ${saved.size + 1}" }
    }

    // Load the curve the earbuds report for the selected slot whenever their slot list changes.
    val slotsKey = Buds.customEqProfiles.joinToString("|") { it.name + it.bands }
    LaunchedEffect(slotsKey) {
        if (!dirty && selected in MANUAL) slotCurve(MANUAL.indexOf(selected) + 1)?.let { values = it }
    }
    // Let finished save / error messages fade instead of sticking around.
    LaunchedEffect(Buds.eqSaveState) {
        if (Buds.eqSaveState == Buds.SaveState.SAVED || Buds.eqSaveState == Buds.SaveState.FAILED) {
            kotlinx.coroutines.delay(6000); Buds.clearEqStatus()
        }
    }

    Panel {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, null, tint = P.accent, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Txt("Master EQ", 18, FontWeight.SemiBold, P.text)
                    Txt("Presets · Manual 1 / 2 / 3 (3 slots on the earbuds)", 12, color = P.sub)
                }
                Text("EQ", color = P.accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
            val descriptions = mapOf("Music" to "Balanced sound", "Movie" to "Cinematic feel", "Game" to "Positional clarity", "Podcast" to "Voice clarity")
            Txt("Master EQ presets", 16, FontWeight.SemiBold, P.text)
            (TEMPLATES.keys.toList() + MANUAL).chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { name ->
                        val active = selected == name
                        val tileColor by animateColorAsState(if (active) P.accent.copy(alpha = .16f) else P.tile, animationSpec = tween(180), label = "eq-profile-color")
                        val borderColor by animateColorAsState(if (active) P.accent else P.soft, animationSpec = tween(180), label = "eq-profile-border")
                        val manualN = MANUAL.indexOf(name) + 1
                        val desc = descriptions[name] ?: if (!connected) "Your custom slot $manualN" else if (deviceSlot(manualN) != null) "Saved on earbuds" else "Empty slot"
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(tileColor)
                                .border(1.dp, borderColor, RoundedCornerShape(18.dp))
                                .clickableNoRipple { select(name) }.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Icon(when (name) { "Music" -> Icons.Rounded.MusicNote; "Movie" -> Icons.Rounded.Movie; "Game" -> Icons.Rounded.SportsEsports; "Podcast" -> Icons.Rounded.Mic; else -> Icons.Rounded.GraphicEq }, null, tint = if (active) P.accent else P.sub, modifier = Modifier.size(22.dp))
                            Txt(name, 16, FontWeight.SemiBold, P.text)
                            Txt(desc, 12, color = P.sub, maxLines = 1)
                            if (active) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Rounded.CheckCircle, null, tint = P.accent, modifier = Modifier.size(14.dp))
                                    Txt("Selected", 10, FontWeight.Medium, P.accent)
                                }
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (saved.isNotEmpty()) {
                Txt("MY PROFILES (on this phone)", 10, FontWeight.SemiBold, P.sub)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    saved.filter { it.name !in MANUAL }.forEach { item ->
                        FilterChip(selected = selected == item.name, onClick = { select(item.name) }, label = { Text(item.name, maxLines = 1) })
                    }
                }
            }
            // Edit / rename / delete for the selected stored profile or earbud slot.
            val isSlot = selected in MANUAL
            val isSavedProfile = !isSlot && saved.any { it.name == selected }
            if (isSlot || isSavedProfile) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { editMode = !editMode; toast(if (editMode) "Drag the sliders, then Apply or Save" else "Editing off") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                        Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text(if (editMode) "Editing…" else "Edit", fontSize = 11.sp)
                    }
                    if (isSavedProfile) OutlinedButton(onClick = { renameFrom = selected; renameText = selected }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                        Icon(Icons.Rounded.DriveFileRenameOutline, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("Rename", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { confirmDelete = selected },
                        enabled = if (isSlot) connected && deviceSlot(MANUAL.indexOf(selected) + 1) != null else true,
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Rounded.Delete, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("Delete", fontSize = 11.sp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Txt("+6 dB", 10, color = P.sub); Txt("0 dB", 10, color = P.sub); Txt("−6 dB", 10, color = P.sub)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Top) {
                EQ_FREQS.indices.forEach { index ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Txt(if (values[index] > 0) "+${values[index]}" else values[index].toString(), 9, FontWeight.Medium, P.accent, maxLines = 1)
                        VerticalEqKnob(value = values[index], enabled = canDrag, onChange = { changeBand(index, it) }, modifier = Modifier.fillMaxWidth().height(104.dp))
                        Txt(EQ_LABELS[index], 9, color = P.sub, maxLines = 1)
                    }
                }
            }
            if (!canDrag) Txt("Tap Edit to change this profile. Presets can be dragged directly.", 11, color = P.sub)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    selected = DRAFT; editMode = false; dirty = true
                    profileName = "Custom ${saved.size + 1}"
                    toast("Copy created. Adjust it, then Save or Apply")
                }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                    Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("Copy as new", fontSize = 11.sp)
                }
                Button(onClick = { profileName = if (isSavedProfile) selected else "Custom ${saved.size + 1}"; saveDialog = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                    Icon(Icons.Rounded.Save, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("Save on phone", fontSize = 11.sp)
                }
            }
            Txt("Apply to earbud slot", 11, FontWeight.Medium, P.sub)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MANUAL.forEachIndexed { i, label -> FilterChip(selected = target == i + 1, onClick = { target = i + 1 }, label = { Text(label, maxLines = 1) }) }
            }
            Button(onClick = {
                if (!connected) toast("Connect your Nord Buds 3 before applying EQ")
                else {
                    val name = deviceSlot(target)?.name ?: "Manual $target"
                    val bands = EQ_FREQS.mapIndexed { i, hz -> hz to values[i].coerceIn(-6, 6) }
                    if (Buds.writeCustomEq(name, bands)) { selected = "Manual $target"; editMode = false; dirty = false; toast("Sending to Manual $target…") }
                    else toast(Buds.eqSaveMessage.ifBlank { "Could not send EQ" })
                }
            }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 10.dp)) { Text(if (connected) "Apply to Manual $target" else "Connect earbuds to apply") }
            if (connected && Buds.eqSaveState != Buds.SaveState.IDLE) {
                Txt(Buds.eqSaveMessage, 12, color = if (Buds.eqSaveState == Buds.SaveState.FAILED) P.amber else P.sub, lineHeight = 16)
            }
            Txt("The earbuds keep 3 slots with -6..+6 dB per band. My profiles stay on this phone only.", size = 11, color = P.sub, lineHeight = 15)
        }
    }

    if (saveDialog) {
        AlertDialog(
            onDismissRequest = { saveDialog = false },
            title = { Text("Save on this phone") },
            text = { OutlinedTextField(value = profileName, onValueChange = { profileName = it.take(32) }, label = { Text("Profile name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val clean = profileName.trim()
                val existing = saved.indexOfFirst { it.name.equals(clean, true) }
                when {
                    clean.isBlank() -> toast("Enter a profile name")
                    clean in MANUAL -> toast("Manual 1-3 are earbud slots. Use Apply to write them.")
                    existing >= 0 && !clean.equals(selected, true) -> toast("That name already exists. Choose a new name.")
                    else -> {
                        val item = SavedEqProfile(clean, values.toList())
                        if (existing >= 0) saved[existing] = item else saved.add(item)
                        while (saved.size > 24) saved.removeAt(0)
                        persist(); selected = clean; editMode = false; dirty = false; saveDialog = false
                        toast("Saved $clean on this phone")
                    }
                }
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { saveDialog = false }) { Text("Cancel") } }
        )
    }
    renameFrom?.let { old ->
        AlertDialog(
            onDismissRequest = { renameFrom = null },
            title = { Text("Rename profile") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it.take(32) }, singleLine = true, label = { Text("Profile name") }) },
            confirmButton = { TextButton(onClick = {
                val clean = renameText.trim()
                val i = saved.indexOfFirst { it.name == old }
                when {
                    clean.isBlank() -> toast("Enter a profile name")
                    clean in MANUAL -> toast("Manual 1-3 are reserved for earbud slots.")
                    saved.any { it.name.equals(clean, true) && it.name != old } -> toast("That name already exists.")
                    i >= 0 -> { saved[i] = SavedEqProfile(clean, saved[i].values); persist(); if (selected == old) selected = clean; renameFrom = null }
                    else -> renameFrom = null
                }
            }) { Text("Rename") } },
            dismissButton = { TextButton(onClick = { renameFrom = null }) { Text("Cancel") } }
        )
    }
    confirmDelete?.let { name ->
        val onEarbuds = name in MANUAL
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete $name?") },
            text = { Text(if (onEarbuds) "This removes the custom EQ slot from your earbuds." else "This removes the profile from this phone.") },
            confirmButton = { TextButton(onClick = {
                if (onEarbuds) {
                    val dev = deviceSlot(MANUAL.indexOf(name) + 1)
                    if (dev != null && Buds.deleteCustomEq(dev.name)) { toast("Delete sent to earbuds"); values = FLAT; dirty = false }
                    else toast("Could not delete (connect the earbuds first)")
                } else {
                    saved.removeAll { it.name == name }; persist(); select("Music"); toast("Deleted $name")
                }
                confirmDelete = null
            }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VerticalEqKnob(value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val canDrag by rememberUpdatedState(enabled)
    val latestOnChange by rememberUpdatedState(onChange)
    BoxWithConstraints(modifier.pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { p -> if (canDrag) latestOnChange((6 - (p.y / size.height.coerceAtLeast(1) * 12)).roundToInt().coerceIn(-6, 6)) },
            onDrag = { change, _ ->
                if (!canDrag) return@detectDragGestures
                change.consume()
                latestOnChange((6 - (change.position.y / size.height.coerceAtLeast(1) * 12)).roundToInt().coerceIn(-6, 6))
            }
        )
    }) {
        val fraction = (6 - value) / 12f
        Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight(0.96f).clip(CircleShape).background(P.text.copy(alpha = 0.78f)))
        Box(Modifier.align(Alignment.Center).fillMaxWidth().height(1.dp).background(P.sub.copy(alpha = 0.35f)))
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = maxHeight * fraction - 9.dp)
                .size(18.dp).clip(CircleShape).background(P.card)
                .border(2.dp, P.accent, CircleShape), contentAlignment = Alignment.Center
        ) { Box(Modifier.size(6.dp).clip(CircleShape).background(P.accent)) }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(
    Modifier.clickable(onClick = onClick)
)
