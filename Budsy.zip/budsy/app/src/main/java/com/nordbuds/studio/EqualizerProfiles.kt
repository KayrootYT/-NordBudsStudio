package com.nordbuds.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.nordbuds.studio.buds.Prefs
import com.nordbuds.studio.buds.SavedEqProfile
import kotlin.math.roundToInt

private val EQ_FREQS = listOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
private val EQ_LABELS = listOf("32", "64", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
private val EQ_PRESETS = linkedMapOf(
    "Music" to listOf(3, 4, 3, 1, 0, 1, 2, 3, 3, 2),
    "Movie" to listOf(1, 2, 1, 0, 2, 3, 4, 3, 2, 2),
    "Game" to listOf(2, 3, 2, 0, 1, 3, 5, 5, 3, 2),
    "Podcast" to listOf(-2, -1, 0, 2, 4, 4, 3, 1, 0, -1)
)

@Composable
fun DolbyEqProfilesCard(connected: Boolean, onApply: (String, List<Pair<Int, Int>>) -> Unit, toast: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { Prefs(context) }
    val saved = remember { mutableStateListOf<SavedEqProfile>().apply { addAll(prefs.loadEqProfiles()) } }
    var selected by remember { mutableStateOf("Game") }
    var values by remember { mutableStateOf(EQ_PRESETS.getValue("Game")) }
    var editing by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("Custom 1") }

    fun selectPreset(name: String, curve: List<Int>) {
        selected = name; values = curve.toList(); editing = false
    }
    fun changeBand(index: Int, value: Int) {
        val next = values.toMutableList(); next[index] = value.coerceIn(-12, 12); values = next
        if (!editing) {
            selected = "Custom"
            profileName = "Custom ${saved.size + 1}"
            editing = true
        }
    }

    Panel {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, null, tint = P.accent, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Txt("Spatial Sound EQ", 18, FontWeight.SemiBold, P.text)
                    Txt("10-band profiles · system Atmos support varies", 12, color = P.sub)
                }
                Text("EQ", color = P.accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
            // The profile curve changes with each selected preset; editing never overwrites a preset.
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                EQ_PRESETS.forEach { (name, curve) ->
                    val active = selected == name && !editing
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                            .background(if (active) P.accent else P.tile)
                            .then(Modifier.border(1.dp, if (active) P.accent else P.soft, RoundedCornerShape(12.dp)))
                            .clickableNoRipple { selectPreset(name, curve) }
                            .padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally
                    ) { Txt(name, 11, FontWeight.Medium, if (active) Color.White else P.text, maxLines = 1) }
                }
            }
            if (saved.isNotEmpty()) {
                Txt("SAVED CUSTOM PROFILES", 10, FontWeight.SemiBold, P.sub)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    saved.forEach { item ->
                        FilterChip(selected = selected == item.name, onClick = { selectPreset(item.name, item.values) }, label = { Text(item.name, maxLines = 1) })
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Txt("+12 dB", 10, color = P.sub)
                Txt("0 dB", 10, color = P.sub)
                Txt("−12 dB", 10, color = P.sub)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Top) {
                EQ_FREQS.indices.forEach { index ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Txt(if (values[index] > 0) "+${values[index]}" else values[index].toString(), 9, FontWeight.Medium, P.accent, maxLines = 1)
                        VerticalEqKnob(value = values[index], onChange = { changeBand(index, it) }, modifier = Modifier.fillMaxWidth().height(104.dp))
                        Txt(EQ_LABELS[index], 9, color = P.sub, maxLines = 1)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (editing) { values = List(10) { 0 } }
                    else selectPreset(selected, EQ_PRESETS[selected] ?: saved.firstOrNull { it.name == selected }?.values ?: List(10) { 0 })
                    editing = true; selected = "Custom"; profileName = "Custom ${saved.size + 1}"
                }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) { Text("Reset / Custom", fontSize = 11.sp) }
                Button(onClick = { profileName = if (selected.startsWith("Custom")) selected else "Custom ${saved.size + 1}"; saveDialog = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)) {
                    Icon(Icons.Rounded.Save, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("Save profile", fontSize = 11.sp)
                }
            }
            Button(onClick = {
                if (!connected) toast("Connect your Nord Buds 3 before applying EQ")
                else onApply(selected, EQ_FREQS.mapIndexed { i, hz -> hz to values[i].coerceIn(-10, 10) })
            }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 10.dp)) { Text(if (connected) "Apply to earbuds" else "Connect earbuds to apply") }
            Text("Custom profiles are saved on this phone. Applying a custom curve depends on firmware support; EQ values are clamped to the currently documented protocol range when sent.", color = P.sub, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }

    if (saveDialog) {
        AlertDialog(
            onDismissRequest = { saveDialog = false },
            title = { Text("Save custom EQ") },
            text = { OutlinedTextField(value = profileName, onValueChange = { profileName = it.take(32) }, label = { Text("Profile name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val clean = profileName.trim()
                if (clean.isBlank()) { toast("Enter a profile name") }
                else {
                    val item = SavedEqProfile(clean, values.toList())
                    val existing = saved.indexOfFirst { it.name.equals(clean, true) }
                    if (existing >= 0) saved[existing] = item else saved.add(item)
                    while (saved.size > 24) saved.removeAt(0)
                    prefs.saveEqProfiles(saved.toList())
                    selected = clean; editing = false; saveDialog = false
                    toast("Saved EQ profile: $clean")
                }
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { saveDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VerticalEqKnob(value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    val latestOnChange by rememberUpdatedState(onChange)
    BoxWithConstraints(modifier.pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { p -> latestOnChange((12 - (p.y / size.height.coerceAtLeast(1) * 24)).roundToInt().coerceIn(-12, 12)) },
            onDrag = { change, _ ->
                change.consume()
                latestOnChange((12 - (change.position.y / size.height.coerceAtLeast(1) * 24)).roundToInt().coerceIn(-12, 12))
            }
        )
    }) {
        val fraction = (12 - value) / 24f
        Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight(0.96f).clip(CircleShape).background(P.text.copy(alpha = 0.78f)))
        Box(Modifier.align(Alignment.Center).fillMaxWidth().height(1.dp).background(P.sub.copy(alpha = 0.35f)))
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = maxHeight * fraction - 9.dp)
                .size(18.dp).clip(CircleShape).background(P.card)
                .border(2.dp, P.accent, CircleShape), contentAlignment = Alignment.Center
        ) { Box(Modifier.size(6.dp).clip(CircleShape).background(P.accent)) }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(
    Modifier.clickable(onClick = onClick)
)
