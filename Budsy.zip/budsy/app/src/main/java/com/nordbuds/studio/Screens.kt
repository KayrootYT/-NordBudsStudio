package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.MaterialTheme
import com.nordbuds.studio.protocol.Protocol
import androidx.compose.material3.TextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }


/** Original Compose-drawn earbud and case artwork; no stock/product photo is used. */
@Composable
private fun PremiumBudsArt(modifier: Modifier = Modifier) {
    val glow = P.accent
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = .28f), Color.Transparent), Offset(cx, h * .52f), w * .48f), w * .48f, Offset(cx, h * .52f))
        // charging case
        val caseW = w * .72f; val caseH = h * .29f
        val caseTop = h * .61f
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFF34435F), Color(0xFF11182B), Color(0xFF26334B)), Offset(0f, caseTop), Offset(w, caseTop + caseH)), Offset(cx-caseW/2, caseTop), androidx.compose.ui.geometry.Size(caseW, caseH), androidx.compose.ui.geometry.CornerRadius(caseH*.28f))
        drawRoundRect(glow.copy(alpha=.7f), Offset(cx-w*.055f, caseTop+caseH*.18f), androidx.compose.ui.geometry.Size(w*.11f, h*.012f), androidx.compose.ui.geometry.CornerRadius(h*.01f))
        // two stem-style earbuds with glossy heads
        listOf(.31f, .69f).forEachIndexed { i, xFrac ->
            val x = w*xFrac
            val headY = h*.20f
            drawRoundRect(Brush.linearGradient(listOf(Color(0xFF4D5B78), Color(0xFF111729), Color(0xFF26324A)), Offset(x-w*.045f, headY), Offset(x+w*.045f, h*.58f)), Offset(x-w*.042f, headY+h*.055f), androidx.compose.ui.geometry.Size(w*.084f, h*.36f), androidx.compose.ui.geometry.CornerRadius(w*.042f))
            drawCircle(Brush.linearGradient(listOf(Color(0xFF65718B), Color(0xFF1C253B)), Offset(x-w*.06f, headY-h*.04f), Offset(x+w*.06f, headY+h*.10f)), w*.078f, Offset(x, headY))
            drawCircle(Color(0xFF080D19), w*.028f, Offset(x, headY))
            drawCircle(glow.copy(alpha=.85f), w*.009f, Offset(x, h*.47f))
        }
    }
}

// ================================================================= OVERVIEW

@Composable
private fun HeroDisc() {
    PremiumTabHero("overview", Modifier.fillMaxWidth())
}

@Composable
fun NeedConnect(x: Ctx) {
    Panel {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(stringResource(R.string.earbuds_not_connected), 16, FontWeight.Medium, P.text)
                Txt(stringResource(R.string.connect_on_the_overview_tab_first), 14)
            }
            SmallButton(stringResource(R.string.overview)) { x.go(0) }
        }
    }
}

fun openBluetooth(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { }
}

/** Request audio-profile disconnect first, then close Budsy's separate BLE control link.
 * Profile calls are best-effort because Android/OEM hidden-API policy may reject them. */
private fun disconnectControlAndOpenBluetooth(ctx: Context, b: Buds) {
    val address = b.deviceAddr
    if (address.isNotBlank()) {
        AudioProfileDisconnect.request(ctx, address) { result ->
            android.widget.Toast.makeText(ctx, result, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    b.disconnect()
}

@Composable
private fun AudioWarning(name: String) {
    val ctx = LocalContext.current
    Panel {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Warning, null, tint = P.amber, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(stringResource(R.string.audio_is_not_connected), 16, FontWeight.Medium, P.text)
                Txt("Control link is connected, but media audio is not. Tap Connect audio, then select $name in Bluetooth settings and enable Media audio.", 14, lineHeight = 19)
            }
            Spacer(Modifier.width(8.dp))
            SmallButton("Connect audio") { openBluetooth(ctx) }
        }
    }
}

@Composable
fun OverviewScreen(x: Ctx) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val b = x.b
    var findConfirm by rememberSaveable { mutableIntStateOf(0) }
    if (findConfirm != 0) {
        AlertDialog(
            onDismissRequest = { findConfirm = 0 },
            title = { Text(stringResource(R.string.find_my_earbuds)) },
            text = { Text(stringResource(R.string.plays_a_loud_tone_only_use_it_when_the_earbuds_a)) },
            confirmButton = { TextButton(onClick = { b.findEarbuds(findConfirm); findConfirm = 0 }) { Text(stringResource(R.string.confirm)) } },
            dismissButton = { TextButton(onClick = { findConfirm = 0 }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    Stack {
        if (b.connected && x.audioKnown && b.deviceAddr !in x.audio) {
            Appear(0) { AudioWarning(if (b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.your_earbuds)) }
        }
        Appear(0) {
            Panel(tint = true) {
                Column(Modifier.padding(22.dp)) {
                    CapsLabel(stringResource(R.string.your_audio_space))
                    Spacer(Modifier.height(4.dp))
                    Txt((if (b.connected && b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.default_device_name)).removePrefix("OnePlus ").trim(), 30, FontWeight.SemiBold, P.text, maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bluetooth, null, tint = if (b.connected) P.green else P.accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Txt(if (b.connected) stringResource(R.string.connected) else b.status, 15, color = if (b.connected) P.green else P.sub, maxLines = 1)
                    }
                    Spacer(Modifier.height(16.dp))
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        HeroDisc()
                        Spacer(Modifier.height(18.dp))
                        if (!b.connected) {
                            if (b.autoPaused) {
                                Txt(stringResource(R.string.auto_connect_is_off_because_you_disconnected), 14, color = P.sub, align = TextAlign.Center)
                                Spacer(Modifier.height(10.dp))
                            }
                            AccentPill(if (b.autoPaused) stringResource(R.string.connect_auto_on) else stringResource(R.string.connect_earbuds), Icons.Rounded.Bluetooth) {
                                b.resumeAutoConnect()
                                if (!x.perm) x.askPerm() else x.openDevicePicker()
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                SmallButton(stringResource(R.string.refresh_2), false) { b.refreshAll() }
                                SmallButton("Disconnect", false) { disconnectControlAndOpenBluetooth(ctx, b) }
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BatteryCard(b.battery[0], b.charging[0], "L", stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc), compact = true)
                        BatteryCard(b.battery[1], b.charging[1], "R", stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc), compact = true)
                    }
                    if (b.connected && b.battery[2] >= 0) {
                        Spacer(Modifier.height(12.dp))
                        BatteryCard(b.battery[2], b.charging[2], "Case", stringResource(R.string.widget_case_label), Modifier.fillMaxWidth(), desc = stringResource(R.string.battery_case_desc))
                    }
                }
            }
        }
        if (b.connected) {
            Appear(1) {
                Panel {
                    Column(Modifier.padding(16.dp)) {
                        CapsLabel(stringResource(R.string.noise_control), Modifier.padding(start = 6.dp, bottom = 10.dp))
                        val items = listOf(Icons.Rounded.Waves to stringResource(R.string.noise_cancel), Icons.Rounded.Block to stringResource(R.string.hold_off), Icons.Rounded.Hearing to stringResource(R.string.hold_transparency))
                        val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                        Segmented(items, ids.indexOf(b.ancMode)) { i -> b.setAnc(ids[i]) }
                        if (b.ancSaveState != Buds.SaveState.IDLE && b.ancSaveMessage.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            val stateColor = when (b.ancSaveState) {
                                Buds.SaveState.SAVED -> P.green
                                Buds.SaveState.FAILED -> P.amber
                                Buds.SaveState.SAVING -> P.accent
                                else -> P.sub
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (b.ancSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(Modifier.size(15.dp), color = stateColor, strokeWidth = 2.dp)
                                else Icon(if (b.ancSaveState == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = stateColor, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Txt(b.ancSaveMessage, 12, color = stateColor, lineHeight = 16)
                            }
                        }
                    }
                }
            }
        }
        if (b.connected) {
            Appear(2) {
                Panel {
                    Column(Modifier.padding(16.dp)) {
                        CapsLabel(stringResource(R.string.find_my_earbuds), Modifier.padding(start = 6.dp, bottom = 6.dp))
                        Txt(stringResource(R.string.plays_a_loud_tone_only_use_it_when_the_earbuds_a), 14, lineHeight = 19, modifier = Modifier.padding(start = 6.dp, bottom = 12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SmallButton(stringResource(R.string.left_2), false) { findConfirm = 1 }
                            SmallButton(stringResource(R.string.right_2), false) { findConfirm = 2 }
                            SmallButton(stringResource(R.string.both_2), false) { findConfirm = 3 }
                        }
                        if (b.findAlertRequested || b.findAlertMessage.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.VolumeUp, null, tint = P.accent, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Txt("${if (b.findAlertRequested) "Alert requested" else "Stop requested"} · ${when (b.findAlertSide) { 1 -> "Left"; 2 -> "Right"; else -> "Both" }}", 13, color = P.sub, modifier = Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.weight(1f)) { SmallButton("Play again", false) { b.findEarbuds(b.findAlertSide) } }
                                Box(Modifier.weight(1f)) { SmallButton("Pause / Stop", true) { b.stopFindEarbuds() } }
                            }
                            Txt(b.findAlertMessage.ifBlank { "Tone stop acknowledgement is not exposed by the currently verified protocol." }, 11, color = P.sub, lineHeight = 15)
                        }
                        if (b.wear.any { it >= 0 }) {
                            Spacer(Modifier.height(14.dp))
                            Txt(stringResource(R.string.wear_sides, wearText(b.wear[0]), wearText(b.wear[1])), 14, modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Shortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Panel(modifier) {
        Column(Modifier.fillMaxWidth().bounceClick(0.97f, onClick = onClick).padding(20.dp)) {
            IconTile(icon, 56)
            Spacer(Modifier.height(18.dp))
            Txt(title, 21, FontWeight.Medium, P.text, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Txt(sub, 14, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Icon(Icons.Rounded.ChevronRight, null, tint = P.accent, modifier = Modifier.size(24.dp))
        }
    }
}

// ================================================================= SOUND

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b
    val context = androidx.compose.ui.platform.LocalContext.current
    val connectFirstText = stringResource(R.string.err_connect_first)
    Stack {
        if (!b.connected) Appear(0) { NeedConnect(x) }
        Appear(1) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.padding(start = 2.dp, top = 4.dp, bottom = 2.dp)) {
                    CapsLabel("AUDIO & SOUND")
                    Spacer(Modifier.height(4.dp))
                    Txt("Sound Studio", 30, FontWeight.SemiBold, P.text)
                    Spacer(Modifier.height(6.dp))
                    Txt("Choose an EQ preset and tune BassWave. Changes are sent to the earbuds when supported by their firmware.", 14, color = P.sub, lineHeight = 19)
                }
                PremiumTabHero("sound")
                Panel {
                Column(Modifier.padding(22.dp)) {
                    Spacer(Modifier.height(6.dp))
                    Txt(stringResource(R.string.master_eq_presets), 16)
                    // EQ commands can be accepted over the control channel while media audio
                    // is still routed to the phone speaker. Make this distinction explicit.
                    val mediaAudioConnected = x.audioKnown && b.deviceAddr.isNotBlank() && b.deviceAddr in x.audio
                    if (b.connected && x.audioKnown && !mediaAudioConnected) {
                        Spacer(Modifier.height(12.dp))
                        Panel {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = P.amber, modifier = Modifier.size(24.dp))
                                Column(Modifier.weight(1f)) {
                                    Txt("Media audio is not connected", 15, FontWeight.SemiBold, P.text)
                                    Txt("EQ may be saved, but sound is playing from the phone. Open Bluetooth settings and enable Media audio for Nord Buds 3.", 13, color = P.sub, lineHeight = 18)
                                }
                                TextButton(onClick = {
                                    try {
                                        val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        context.startActivity(intent)
                                    } catch (_: Exception) { x.toast("Open Settings > Bluetooth > Nord Buds 3 > enable Media audio") }
                                }) { Text("Open") }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Buds.PRESETS.forEach { p ->
                            val sel = b.connected && b.eqPreset == p.first
                            Column(
                                Modifier.weight(1f).bounceClick(0.88f) { if (b.connected) b.setEq(p.first) else x.toast(connectFirstText) }
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (sel) P.accent else P.tile)
                                    .padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.GraphicEq, null, tint = if (sel) Color.White else P.accent, modifier = Modifier.size(24.dp))
                                Spacer(Modifier.height(6.dp))
                                Txt(stringResource(p.second), 15, FontWeight.Medium, if (sel) Color.White else P.text, maxLines = 1)
                            }
                        }
                    }
                    val cur = Buds.PRESETS.firstOrNull { it.first == b.eqPreset }
                    if (b.connected && cur != null) {
                        Spacer(Modifier.height(10.dp))
                        Txt(stringResource(cur.third), 14)
                    }
                    if (b.connected && b.eqSaveState != Buds.SaveState.IDLE) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (b.eqSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp, color = P.accent)
                            Icon(
                                imageVector = when (b.eqSaveState) {
                                    Buds.SaveState.SAVED -> Icons.Rounded.CheckCircle
                                    Buds.SaveState.FAILED -> Icons.Rounded.WarningAmber
                                    else -> Icons.Rounded.Sync
                                },
                                contentDescription = null,
                                tint = when (b.eqSaveState) {
                                    Buds.SaveState.SAVED -> P.green
                                    Buds.SaveState.FAILED -> P.amber
                                    else -> P.accent
                                }, modifier = Modifier.size(18.dp)
                            )
                            Txt(b.eqSaveMessage, 13, color = P.text, lineHeight = 18)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    if (!b.connected) {
                        Txt(stringResource(R.string.connect_your_earbuds_to_adjust_the_bass), 14)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val bassEnabled = b.bassOn == true
                            val bassRotation by animateFloatAsState(
                                targetValue = if (bassEnabled) 360f else 0f,
                                animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
                                label = "basswave-activation"
                            )
                            Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                                    .background(if (bassEnabled) P.accent.copy(alpha = .15f) else P.tile),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Rounded.GraphicEq, contentDescription = null,
                                    tint = if (bassEnabled) P.accent else P.sub,
                                    modifier = Modifier.size(25.dp).graphicsLayer { rotationZ = bassRotation }
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Txt(stringResource(R.string.basswave), 22, FontWeight.Medium, P.text)
                                Txt(if (bassEnabled) "Bass enhancement active" else stringResource(R.string.adjust_the_low_end), 14)
                            }
                            NordSwitch(bassEnabled) { b.setBassOn(it) }
                        }
                        val lv = b.bassLevel
                        if (lv != null) {
                            var drag by remember { mutableStateOf<Float?>(null) }
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth()) {
                                Txt(stringResource(R.string.level), 16, FontWeight.Normal, P.text, Modifier.weight(1f))
                                val shown = (drag ?: lv.toFloat()).roundToInt()
                                Txt(if (shown > 0) "+$shown" else "$shown", 18, FontWeight.SemiBold, P.accent)
                            }
                            Slider(
                                value = drag ?: lv.toFloat(),
                                onValueChange = { drag = it },
                                onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null },
                                valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(),
                                steps = (b.bassMax - b.bassMin - 1).coerceAtLeast(0),
                                enabled = b.bassOn == true,
                                colors = SliderDefaults.colors(
                                    thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.soft,
                                    activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                                )
                            )
                        }
                    }

                }
                }
                SpatialEqProfilesCard(
                    connected = b.connected,
                    onApply = { profileName, bands ->
                        if (b.writeCustomEq(profileName, bands)) x.toast("EQ command sent; waiting for earbud confirmation")
                        else x.toast(connectFirstText)
                    },
                    toast = { x.toast(it) }
                )
            }
        }
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt(stringResource(R.string.bluetooth_permission_is_needed_to_find_your_pair), 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton(stringResource(R.string.allow_bluetooth)) { x.askPerm() }
        return
    }
    val adapter = remember { ctx.getSystemService(BluetoothManager::class.java)?.adapter }
    val nearby = remember { mutableStateListOf<BluetoothDevice>() }
    var scanRunning by remember { mutableStateOf(false) }
    var scanRefresh by remember { mutableIntStateOf(0) }
    fun scanNearby() {
        if (adapter == null || !x.perm) return
        try {
            nearby.clear()
            if (adapter.isDiscovering) adapter.cancelDiscovery()
            scanRunning = adapter.startDiscovery()
        } catch (_: SecurityException) { scanRunning = false }
    }
    DisposableEffect(x.perm, adapter) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d = if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) else intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                        if (d != null && nearby.none { it.address == d.address }) nearby.add(d)
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanRunning = false
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> scanRefresh++
                }
            }
        }
        val filter = IntentFilter().apply { addAction(BluetoothDevice.ACTION_FOUND); addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED) }
        try { ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED) } catch (_: Exception) { }
        onDispose {
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) { }
            try { if (adapter?.isDiscovering == true) adapter.cancelDiscovery() } catch (_: Exception) { }
        }
    }
    LaunchedEffect(x.perm) { if (x.perm) scanNearby() }
    val list = remember(b.connected, x.perm, b.connecting, nearby.size, scanRefresh) {
        (bondedDevices(ctx) + nearby).distinctBy { it.address }.sortedByDescending { it.name?.contains("Nord Buds", true) == true || it.name?.contains("Buds", true) == true }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt("Bluetooth scanning", 18, FontWeight.Medium, P.text)
                Txt(if (scanRunning) "Looking for nearby devices…" else "Scan and select your earbuds here", 13, color = P.sub)
            }
            SmallButton(if (scanRunning) "Scanning…" else "Scan nearby", false) { if (!scanRunning) scanNearby() }
        }
        if (b.searching || b.connecting || scanRunning) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), color = P.accent, strokeWidth = 3.dp)
                Spacer(Modifier.width(12.dp))
                Txt(if (b.connecting) "Connecting\u2026" else "Scanning for your earbuds\u2026", 16, FontWeight.Medium, P.text)
            }
        }
        Txt(stringResource(R.string.select_a_device_to_connect), 18, FontWeight.Medium, P.text)
        if (list.isEmpty()) Txt(if (scanRunning) "Scanning nearby Bluetooth devices…" else stringResource(R.string.no_paired_devices_found), 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Headphones, null, tint = P.accent, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                val up = d.address in x.audio
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(if (up) stringResource(R.string.connected_for_audio) else if (x.audioKnown) stringResource(R.string.not_connected_for_audio) else stringResource(R.string.paired), 13, color = if (up) P.green else P.sub)
                }
                val paired = try { d.bondState == BluetoothDevice.BOND_BONDED } catch (_: Exception) { false }
                if (!paired) {
                    SmallButton("Pair") { try { d.createBond() } catch (_: Exception) { } }
                } else {
                    SmallButton(if (b.connecting) "…" else if (b.connected && b.deviceAddr == d.address) "Disconnect" else "Connect") {
                        if (b.connected && b.deviceAddr == d.address) b.disconnect() else if (!b.connecting) b.connect(d)
                    }
                }
            }
        }
        Row(
            Modifier.clip(CircleShape).clickable {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt(stringResource(R.string.open_bluetooth_settings), 14, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val labelRes: Int)
private val NONE = Opt(Buds.F_NONE, R.string.fn_none)
private val PLAY = Opt(Buds.F_PLAY, R.string.fn_play)
private val PREV = Opt(Buds.F_PREV, R.string.fn_prev)
private val NEXT = Opt(Buds.F_NEXT, R.string.fn_next)
private val VOICE = Opt(Buds.F_VOICE, R.string.fn_voice)
private val GAME = Opt(Buds.F_GAME, R.string.fn_game)
private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, R.string.fn_vol_up), Opt(Buds.F_VOL_DN, R.string.fn_vol_down))
private fun optsFor(gid: Int) = when (gid) { Buds.G_SINGLE -> SINGLE_OPTS; Buds.G_DOUBLE -> DOUBLE_OPTS; Buds.G_TRIPLE -> TRIPLE_OPTS; else -> LONG_OPTS }

@Composable
private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return stringResource(it.labelRes) }
    return when (fn) {
        0x07 -> stringResource(R.string.fn_volume)
        0x0A -> stringResource(R.string.fn_switch_track)
        Buds.F_ANC -> stringResource(R.string.fn_anc)
        else -> stringResource(R.string.unknown_action, Protocol.hex(fn).uppercase())
    }
}

@Composable
private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add(stringResource(R.string.hold_anc))
        if ((mask and Buds.M_OFF) != 0) add(stringResource(R.string.hold_off))
        if ((mask and Buds.M_TRANSP) != 0) add(stringResource(R.string.hold_transparency))
    }
    return n.joinToString(", ")
}

@Composable
private fun wearText(f: Int): String = when {
    f < 0 -> "—"
    (f and 2) != 0 -> stringResource(R.string.wear_in_ear)
    (f and 1) == 0 -> stringResource(R.string.wear_in_case)
    else -> stringResource(R.string.wear_out_case)
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) stringResource(R.string.left) else stringResource(R.string.right)
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast(connectFirstText) }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null

    Stack {
        Appear(0) {
            Column(Modifier.padding(start = 2.dp, top = 4.dp, bottom = 2.dp)) {
                CapsLabel("NOISE & TOUCH")
                Spacer(Modifier.height(4.dp))
                Txt("Controls", 30, FontWeight.SemiBold, P.text)
                Spacer(Modifier.height(6.dp))
                Txt("Choose a listening mode and manage touch gestures. Hardware settings are sent only when supported by the connected earbuds.", 14, color = P.sub, lineHeight = 19)
            }
        }
        Appear(1) { PremiumTabHero("controls") }
        if (!live) Appear(0) { NeedConnect(x) }

        Appear(1) {
            Panel {
                Column(Modifier.padding(22.dp)) {
                    Txt(stringResource(R.string.control_center), 30, FontWeight.SemiBold, P.text)
                    Spacer(Modifier.height(16.dp))
                    val ancLabel = when (b.ancMode) {
                        Buds.ANC_ON -> stringResource(R.string.hold_anc)
                        Buds.ANC_OFF -> stringResource(R.string.hold_off)
                        Buds.ANC_TRANSP -> stringResource(R.string.hold_transparency)
                        else -> "\u2014"
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.Waves, 48)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(stringResource(R.string.noise_control), 18, FontWeight.Medium, P.text)
                            Txt(if (live) ancLabel else stringResource(R.string.connect_to_use), 14)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    val items = listOf(Icons.Rounded.Waves to stringResource(R.string.noise_cancel), Icons.Rounded.Block to stringResource(R.string.hold_off), Icons.Rounded.Hearing to stringResource(R.string.hold_transparency))
                    val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                    Segmented(items, if (live) ids.indexOf(b.ancMode) else -1) { i -> if (live) b.setAnc(ids[i]) else x.toast(connectFirstText) }
                    if (live && b.ancSaveState != Buds.SaveState.IDLE && b.ancSaveMessage.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Txt(b.ancSaveMessage, 12, color = when (b.ancSaveState) { Buds.SaveState.SAVED -> P.green; Buds.SaveState.FAILED -> P.amber; Buds.SaveState.SAVING -> P.accent; else -> P.sub }, lineHeight = 16)
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.SportsEsports, 48)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(stringResource(R.string.game_mode), 18, FontWeight.Medium, P.text)
                            Txt(stringResource(R.string.lower_audio_latency), 14)
                        }
                        NordSwitch(b.gameMode == true, live) { b.setGame(it) }
                    }
                }
            }
        }

        Appear(2) {
            Panel {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.Mic, 44)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Txt("Call clarity", 18, FontWeight.SemiBold, P.text)
                            Txt("AI Clear Calls · published feature", 13, color = P.sub)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp)) {
                            Txt("Microphones", 12, color = P.sub)
                            Txt("2 per bud", 19, FontWeight.SemiBold, P.text)
                            Txt("4 in total", 11, color = P.sub)
                        }
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp)) {
                            Txt("In calls", 12, color = P.sub)
                            Txt("Noise reduction", 17, FontWeight.SemiBold, P.text)
                            Txt("Background suppression", 11, color = P.sub, lineHeight = 14)
                        }
                    }
                }
            }
        }

        Appear(3) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                BudArt(side == 2, 170.dp, touchSpot = true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Chip(stringResource(R.string.left_2), side == 1) { side = 1 }
                    Chip(stringResource(R.string.right_2), side == 2) { side = 2 }
                }
            }
        }

        Appear(4) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel(stringResource(R.string.when_not_on_a_call))
                Panel {
                    ValueRow(stringResource(R.string.g_single) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE))) { open(Buds.G_SINGLE) }
                    ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE))) { open(Buds.G_DOUBLE) }
                    ValueRow(stringResource(R.string.g_triple) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE))) { open(Buds.G_TRIPLE) }
                    ValueRow(stringResource(R.string.touch_and_hold), if (live) holdLabel(b.holdMask) else "\u2014") { open(Buds.G_HOLD) }
                    ValueRow(stringResource(R.string.long_touch_and_hold), fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), divider = false) { open(Buds.G_LONG) }
                }
            }
        }

        Appear(5) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel(stringResource(R.string.when_on_a_call))
                Panel {
                    ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), stringResource(R.string.answer_end_call), chevron = false)
                    ValueRow(stringResource(R.string.long_touch_and_hold), stringResource(R.string.decline_call), chevron = false, divider = false)
                }
            }
        }

        Appear(6) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.tile)
                    .clickable { tutorial = true }.padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Txt(stringResource(R.string.learn_earbud_controls), 15)
                Spacer(Modifier.height(14.dp))
                Txt(stringResource(R.string.view_tutorial), 18, FontWeight.Normal, P.text)
            }
        }
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> stringResource(R.string.g_single); Buds.G_DOUBLE -> stringResource(R.string.g_double); else -> stringResource(R.string.g_triple) }) + " $sideName " + stringResource(R.string.earbud)
        val opts = optsFor(g)
        val now = cur(g)
        // Pick-to-apply dialog (same pattern as HeyMelody): tapping an option writes it and closes.
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }) {
            SheetTitle(title)
            opts.forEachIndexed { index, o ->
                RadioRow(stringResource(o.labelRes), now == o.fn, divider = index < opts.lastIndex) {
                    if (!b.connected) x.toast(connectFirstText)
                    else if (now == null || o.fn != now) b.setGesture(side, g, o.fn)
                    dlg = 0
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }) {
            SheetTitle(stringResource(R.string.g_long))
            Txt(stringResource(R.string.long_touch_volume_help), 14, lineHeight = 20)
            Spacer(Modifier.height(8.dp))
            Txt(stringResource(R.string.long_touch_anc_help), 14, lineHeight = 20)
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEachIndexed { i, o ->
                RadioRow(stringResource(o.labelRes), now == o.fn, divider = i < LONG_OPTS.lastIndex) {
                    if (!b.connected) x.toast(connectFirstText)
                    else if (now == null || o.fn != now) b.setGesture(side, Buds.G_LONG, o.fn)
                    dlg = 0
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (g == Buds.G_HOLD) {
        LaunchedEffect(Unit) { b.queryHold() }
        var sel by rememberSaveable { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        var holdTouched by remember { mutableStateOf(false) }
        var holdConfirmRequested by remember { mutableStateOf(false) }
        LaunchedEffect(b.holdMask) { if (!holdTouched && b.holdMask > 0) sel = b.holdMask and 7 }
        LaunchedEffect(b.holdSaveState, holdConfirmRequested) {
            if (holdConfirmRequested && b.holdSaveState == Buds.SaveState.SAVED) {
                kotlinx.coroutines.delay(500)
                dlg = 0
            }
        }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) { sel = v; holdTouched = true } }
        SheetDialog({ dlg = 0 }, footer = {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton(if (b.holdSaveState == Buds.SaveState.SAVING) "Saving…" else stringResource(R.string.confirm), true) { if (b.holdSaveState != Buds.SaveState.SAVING) { holdConfirmRequested = true; b.updateHoldMask(sel) } } }
            }
        }) {
            SheetTitle(stringResource(R.string.g_hold))
            Txt(if (n == 1) stringResource(R.string.hold_one_option) else stringResource(R.string.hold_many_options, n), 16, lineHeight = 22)
            Spacer(Modifier.height(6.dp))
            CheckRow(stringResource(R.string.hold_anc), stringResource(R.string.hold_anc_sub), (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow(stringResource(R.string.hold_off), stringResource(R.string.hold_off_sub), (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow(stringResource(R.string.hold_transparency), stringResource(R.string.hold_transparency_sub), (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            if (b.holdSaveState != Buds.SaveState.IDLE || b.holdSaveMessage.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                val saveColor = when (b.holdSaveState) {
                    Buds.SaveState.SAVED -> P.green
                    Buds.SaveState.FAILED -> P.amber
                    Buds.SaveState.SAVING -> P.accent
                    else -> P.sub
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (b.holdSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = saveColor)
                    else Icon(if (b.holdSaveState == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = saveColor, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Txt(b.holdSaveMessage, 12, color = saveColor, lineHeight = 17)
                }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle(stringResource(R.string.earbud_controls))
            Txt(stringResource(R.string.single_double_and_triple_tap_tap_the_touch_area_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.touch_and_hold_hold_until_you_hear_a_beep_then_l), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.long_touch_and_hold_keep_holding_until_you_hear_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.during_a_call_double_tap_to_answer_or_end_it_lon), 16, lineHeight = 23)
            Spacer(Modifier.height(18.dp))
            WideButton(stringResource(R.string.got_it), true) { tutorial = false }
        }
    }
}

// ================================================================= SETTINGS

@Composable
private fun ThemeButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.bounceClick(0.9f, onClick = onClick).clip(RoundedCornerShape(22.dp)).background(if (sel) P.accent else P.tile).padding(vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (sel) Color.White else P.text, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Txt(label, 20, FontWeight.Medium, if (sel) Color.White else P.text, maxLines = 1)
    }
}

@Composable
private fun PaletteOption(index: Int, name: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val scale by animateFloatAsState(if (sel) 1f else 0.96f, spring(dampingRatio = 0.62f, stiffness = 420f), label = "themeScale")
    val ring by androidx.compose.animation.animateColorAsState(if (sel) paletteColor(index) else P.line, tween(260), label = "themeRing")
    Column(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .bounceClick(0.94f, onClick = onClick).clip(shape)
            .background(if (sel) paletteColor(index).copy(alpha = 0.10f) else P.card)
            .border(if (sel) 2.dp else 1.dp, ring, shape)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(paletteColor(index), paletteColor(index).copy(alpha = .48f), paletteColor(index)))), contentAlignment = Alignment.Center) {
            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(8.dp))
        Txt(name, 16, if (sel) FontWeight.SemiBold else FontWeight.Normal, P.text, maxLines = 1)
    }
}

@Composable
fun SettingsScreen(x: Ctx) {
    var diag by rememberSaveable { mutableStateOf(x.prefs.diag) }
    var batteryNotif by rememberSaveable { mutableStateOf(Buds.prefs.batteryNotif) }
    var rename by rememberSaveable { mutableStateOf(false) }
    var nameDraft by rememberSaveable { mutableStateOf(Buds.customName ?: Buds.deviceName) }
    val ctx = LocalContext.current

    // Screenshot-first layout: device/connectivity and specification cards come first.
    // Keep native Budsy options below them so the reference sections are not buried.
    Stack {
        Appear(0) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.padding(start = 2.dp, top = 4.dp, bottom = 2.dp)) {
                    CapsLabel("CONNECTIVITY & DEVICE")
                    Spacer(Modifier.height(4.dp))
                    Txt("Settings", 30, FontWeight.SemiBold, P.text)
                }
                PremiumTabHero("settings")

                Panel {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconTile(Icons.Rounded.Settings, 42)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Txt("Budsy app settings", 19, FontWeight.SemiBold, P.text)
                                Txt("Native app and device options", 13)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        ValueRow(stringResource(R.string.rename_device), Buds.displayName.ifEmpty { stringResource(R.string.app_name) }, divider = true) {
                            nameDraft = Buds.customName ?: Buds.deviceName
                            rename = true
                        }
                        SwitchRow(stringResource(R.string.battery_notification), stringResource(R.string.battery_notification_sub), batteryNotif) { enabled ->
                            batteryNotif = enabled
                            Buds.prefs.batteryNotif = enabled
                            if (!enabled) BatteryNotifier.cancel(ctx) else if (!x.notifGranted) x.askNotifPerm() else BatteryNotifier.update(ctx)
                        }
                        SwitchRow(stringResource(R.string.wear_detection), stringResource(R.string.wear_detection_sub), Buds.wearDetect == true, divider = false) { Buds.setWearDetect(it) }
                    }
                }

                Panel {
                    Column(Modifier.padding(18.dp)) {
                        Txt(stringResource(R.string.appearance), 20, FontWeight.SemiBold, P.text)
                        Txt("Premium iOS · Classic · Dark / Light / AMOLED", 12, color = P.sub)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ThemeButton(Icons.Rounded.DarkMode, stringResource(R.string.dark), x.dark, Modifier.weight(1f)) { x.setDark(true) }
                            ThemeButton(Icons.Rounded.LightMode, stringResource(R.string.light), !x.dark, Modifier.weight(1f)) { x.setDark(false) }
                        }
                        if (x.dark) {
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Txt(stringResource(R.string.amoled_black), 16, FontWeight.Medium, P.text); Txt("Pure black surfaces for OLED screens", 12) }
                                NordSwitch(x.amoled) { x.setAmoled(it) }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            ThemeButton(Icons.Rounded.Public, "Classic", x.visualStyle == 0, Modifier.weight(1f)) { x.setVisualStyle(0) }
                            ThemeButton(Icons.Rounded.Palette, "Premium iOS", x.visualStyle == 1, Modifier.weight(1f)) { x.setVisualStyle(1) }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PaletteNames.forEachIndexed { i, n -> PaletteOption(i, n, x.accentIdx == i, Modifier.width(112.dp)) { x.setAccent(i) } }
                        }
                    }
                }

                SettingsReferenceSections(x)

                Panel {
                    Column {
                        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconTile(Icons.Rounded.ShowChart, 44)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) { Txt(stringResource(R.string.diagnostics), 19, FontWeight.SemiBold, P.text); Txt(stringResource(R.string.show_gesture_table_and_protocol_log), 13) }
                            NordSwitch(diag) { diag = it; x.prefs.diag = it }
                        }
                        if (diag) Diagnostics(x)
                    }
                }
            }
        }
    }
    if (rename) AlertDialog(onDismissRequest = { rename = false }, title = { Text(stringResource(R.string.rename_device)) }, text = { TextField(value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true, label = { Text(stringResource(R.string.rename_hint)) }) }, confirmButton = { TextButton(onClick = { Buds.renameDevice(nameDraft); rename = false }) { Text(stringResource(R.string.save)) } }, dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun SettingsReferenceSections(x: Ctx) {
    val settingsContext = LocalContext.current
    val b = x.b
    var specQuery by rememberSaveable { mutableStateOf("") }
    val specs = listOf(
        "Drivers" to "12.4 mm titanium dynamic",
        "BassWave" to "BassWave 2.0 bass adjustment",
        "EQ presets" to "Balanced, Serenade, Bass",
        "3D Audio" to "On supported OnePlus phones",
        "Bluetooth" to "Bluetooth 5.4",
        "Water resistance" to "IP55 earbuds only",
        "Charging case" to "USB-C"
    ).filter { (a, c) -> specQuery.isBlank() || a.contains(specQuery, true) || c.contains(specQuery, true) }
    Panel {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Bluetooth, 42); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Txt("Connections", 19, FontWeight.SemiBold, P.text); Txt("Devices the earbuds report as connected", 13) }
            }
            Spacer(Modifier.height(12.dp))
            if (b.connected && b.peers.isNotEmpty()) {
                b.peers.forEach { name ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(22.dp)).background(P.tile).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Smartphone, null, tint = P.sub, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(12.dp))
                        Txt(name, 14, FontWeight.Medium, P.text, Modifier.weight(1f), maxLines = 1)
                    }
                }
            } else {
                Txt(if (b.connected) "No devices reported yet. Tap Refresh on the Device tab." else "Connect your earbuds to see the devices they are paired with.", 13, color = P.sub, lineHeight = 18)
            }
            Spacer(Modifier.height(12.dp))
            SmallButton("Open Bluetooth settings", false) { openBluetooth(settingsContext) }
        }
    }
    Panel {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { IconTile(Icons.Rounded.WaterDrop, 42); Spacer(Modifier.width(12.dp)); Column { Txt("Protection & design", 19, FontWeight.SemiBold, P.text); Txt("Published specifications", 13) } }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("IP55" to "Earbuds", "Lightweight" to "In-ear fit", "USB-C" to "Compact case").forEach { (v, l) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(P.tile).padding(12.dp)) { Txt(v, 16, FontWeight.SemiBold, P.text); Spacer(Modifier.height(5.dp)); Txt(l, 11) }
                }
            }
            Spacer(Modifier.height(10.dp)); Txt("IP55 applies to the earbuds only, not the charging case. Avoid swimming or showering with them.", 12, color = P.sub, lineHeight = 17)
        }
    }
    Panel {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { IconTile(Icons.Rounded.Checklist, 42); Spacer(Modifier.width(12.dp)); Column { Txt("Features & specifications", 19, FontWeight.SemiBold, P.text); Txt("OnePlus Nord Buds 3 · published claims", 12) } }
            Spacer(Modifier.height(12.dp))
            TextField(value = specQuery, onValueChange = { specQuery = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search e.g. latency, IP55, codec…") })
            Spacer(Modifier.height(8.dp))
            specs.forEach { (name, value) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Txt(name, 13, FontWeight.Medium, P.accent, Modifier.weight(1f)); Txt(value, 12, color = P.sub, modifier = Modifier.weight(1.2f), align = TextAlign.End)
                }
                HorizontalDivider(color = P.line.copy(alpha = .65f))
            }
            Spacer(Modifier.height(8.dp)); Txt("Some controls above are visual previews and do not configure proprietary earbud features.", 12, color = P.sub, lineHeight = 17)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Diagnostics(x: Ctx) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val b = x.b
    val logCopiedText = stringResource(R.string.log_copied)
    val clip = LocalClipboardManager.current
    Column(Modifier.padding(bottom = 22.dp)) {
        ValueRow(stringResource(R.string.name_2), if (b.connected) b.deviceName else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.bluetooth_address_2), if (b.connected) b.deviceAddr else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.status_2), if (b.connected) stringResource(R.string.connected) else b.status, chevron = false)
        ValueRow(stringResource(R.string.firmware_2), if (b.connected) (b.firmware ?: "\u2014") else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.connected_to_buds_2), if (b.connected && b.peers.isNotEmpty()) b.peers.joinToString(", ") else "\u2014", chevron = false, divider = false)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(8.dp))
            if (b.connected) WideButton("Disconnect control", false) { disconnectControlAndOpenBluetooth(ctx, b) } else ConnectBlock(x)

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.custom_eq_saved_on_the_buds_read_only), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            Txt(b.customEq ?: stringResource(R.string.nothing_read_yet), 13, FontWeight.Normal, P.sub, lineHeight = 18)

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.feature_flags), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.scan_2), false) { b.scanFlags() }
            }
            Spacer(Modifier.height(4.dp))
            Txt(stringResource(R.string.to_find_a_switch_such_as_ear_detection_or_dual_c), 12, lineHeight = 17)
            Spacer(Modifier.height(6.dp))
            if (b.flags.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 13)
            b.flags.toSortedMap().forEach { (id, v) ->
                SwitchRow(title = stringResource(R.string.flag_name_unknown, Protocol.hex(id).uppercase()), sub = "ID 0x${Protocol.hex(id).uppercase()}", on = v == 1) { Buds.setFlag(id, it) }
            }

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.gesture_table_reported_by_the_buds), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            val keys = b.gest.keys.sorted()
            if (keys.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 14)
            keys.forEach { k ->
                Txt(stringResource(R.string.gesture_table_entry, if (k / 16 == 1) stringResource(R.string.left) else if (k / 16 == 2) stringResource(R.string.right) else stringResource(R.string.gesture_side, k / 16), k % 16, Protocol.hex(b.gest[k] ?: 0).uppercase()), 13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp))
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.protocol_log), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.copy), false) { clip.setText(AnnotatedString(b.logText())); x.toast(logCopiedText) }
            }
            Spacer(Modifier.height(6.dp))
            val ver = b.logVersion
            val lines = remember(ver) { b.logText().lines().takeLast(14) }
            Txt(if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) stringResource(R.string.empty) else lines.joinToString("\n"), 11, FontWeight.Normal, P.sub, lineHeight = 15)
            Spacer(Modifier.height(16.dp))
            Txt(stringResource(R.string.unofficial_disclaimer), 13, lineHeight = 19)
        }
    }
}
