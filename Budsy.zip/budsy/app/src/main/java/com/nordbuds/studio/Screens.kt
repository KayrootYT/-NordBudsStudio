package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.MaterialTheme
import com.nordbuds.studio.protocol.Protocol
import androidx.compose.material3.TextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

// ================================================================= OVERVIEW

@Composable
private fun HeroDisc() {
    val t = rememberInfiniteTransition(label = "hero")
    val glow = t.animateFloat(0.25f, 0.75f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    val ring = P.accent
    Box(Modifier.size(width = 280.dp, height = 220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f * 1.15f
            drawCircle(Brush.radialGradient(listOf(ring.copy(alpha = glow.value * 0.45f), Color.Transparent), center, r), r, center)
        }
        Image(
            painterResource(R.drawable.hero_buds), "OnePlus Nord Buds 3 in its case",
            Modifier.width(230.dp), contentScale = ContentScale.Fit
        )
    }
}

@Composable
fun NeedConnect(x: Ctx) {
    Panel {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(stringResource(R.string.earbuds_not_connected), 16, FontWeight.Medium, P.text)
                Txt(stringResource(R.string.connect_on_the_overview_tab_first), 14)
            }
            SmallButton(stringResource(R.string.overview)) { x.go(0) }
        }
    }
}

fun openBluetooth(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { }
}

@Composable
private fun AudioWarning(name: String) {
    val ctx = LocalContext.current
    Panel {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Warning, null, tint = P.amber, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(stringResource(R.string.audio_is_not_connected), 16, FontWeight.Medium, P.text)
                Txt(stringResource(R.string.audio_warning_detail, name), 14, lineHeight = 19)
            }
            Spacer(Modifier.width(8.dp))
            SmallButton(stringResource(R.string.open_2)) { openBluetooth(ctx) }
        }
    }
}

@Composable
fun OverviewScreen(x: Ctx) {
    val b = x.b
    var showList by rememberSaveable { mutableStateOf(false) }
    Stack {
        if (b.connected && x.audioKnown && b.deviceAddr !in x.audio) {
            Appear(0) { AudioWarning(if (b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.your_earbuds)) }
        }
        Appear(0) {
            Panel(tint = true) {
                Column(Modifier.padding(22.dp)) {
                    CapsLabel(stringResource(R.string.your_audio_space))
                    Spacer(Modifier.height(4.dp))
                    Txt((if (b.connected && b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.default_device_name)).removePrefix("OnePlus ").trim(), 30, FontWeight.SemiBold, P.text, maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bluetooth, null, tint = if (b.connected) P.green else P.accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Txt(if (b.connected) stringResource(R.string.connected) else b.status, 15, color = if (b.connected) P.green else P.sub, maxLines = 1)
                    }
                    Spacer(Modifier.height(16.dp))
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        HeroDisc()
                        Spacer(Modifier.height(8.dp))
                        Txt(stringResource(R.string.your_sound_your_world), 24, FontWeight.Medium, P.text, align = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        Txt(stringResource(R.string.immersive_audio_experience), 16, color = P.sub, align = TextAlign.Center)
                        Spacer(Modifier.height(18.dp))
                        if (!b.connected) {
                            if (b.autoPaused) {
                                Txt(stringResource(R.string.auto_connect_is_off_because_you_disconnected), 14, color = P.sub, align = TextAlign.Center)
                                Spacer(Modifier.height(10.dp))
                            }
                            AccentPill(if (b.autoPaused) stringResource(R.string.connect_auto_on) else stringResource(R.string.connect_earbuds), Icons.Rounded.Bluetooth) {
                                b.resumeAutoConnect()
                                if (!x.perm) x.askPerm() else showList = !showList
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                SmallButton(stringResource(R.string.refresh_2), false) { b.refreshAll() }
                                SmallButton(stringResource(R.string.disconnect_2), false) { b.disconnect() }
                            }
                        }
                    }
                    if (!b.connected && showList) {
                        Spacer(Modifier.height(16.dp))
                        ConnectBlock(x)
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BatteryCard(b.battery[0], b.charging[0], "L", stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc))
                        BatteryCard(b.battery[1], b.charging[1], "R", stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc))
                    }
                    if (b.connected && b.battery[2] >= 0) {
                        Spacer(Modifier.height(12.dp))
                        BatteryCard(b.battery[2], b.charging[2], "Case", stringResource(R.string.widget_case_label), Modifier.fillMaxWidth(), desc = stringResource(R.string.battery_case_desc))
                    }
                }
            }
        }
        if (b.connected) {
            Appear(1) {
                Panel {
                    Column(Modifier.padding(16.dp)) {
                        CapsLabel(stringResource(R.string.noise_control), Modifier.padding(start = 6.dp, bottom = 10.dp))
                        val items = listOf(Icons.Rounded.Waves to stringResource(R.string.noise_cancel), Icons.Rounded.Block to stringResource(R.string.hold_off), Icons.Rounded.Hearing to stringResource(R.string.hold_transparency))
                        val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                        Segmented(items, ids.indexOf(b.ancMode)) { i -> b.setAnc(ids[i]) }
                    }
                }
            }
        }
        if (b.connected) {
            Appear(2) {
                Panel {
                    Column(Modifier.padding(16.dp)) {
                        CapsLabel(stringResource(R.string.find_my_earbuds), Modifier.padding(start = 6.dp, bottom = 6.dp))
                        Txt(stringResource(R.string.plays_a_loud_tone_only_use_it_when_the_earbuds_a), 14, lineHeight = 19, modifier = Modifier.padding(start = 6.dp, bottom = 12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SmallButton(stringResource(R.string.left_2), false) { b.findEarbuds(1) }
                            SmallButton(stringResource(R.string.right_2), false) { b.findEarbuds(2) }
                            SmallButton(stringResource(R.string.both_2), false) { b.findEarbuds(3) }
                        }
                        if (b.wear.any { it >= 0 }) {
                            Spacer(Modifier.height(14.dp))
                            Txt(stringResource(R.string.wear_sides, wearText(b.wear[0]), wearText(b.wear[1])), 14, modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
            }
        }
        Appear(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Shortcut(Icons.Rounded.GraphicEq, stringResource(R.string.sound_lab), stringResource(R.string.eq_bass_audio), Modifier.weight(1f)) { x.go(1) }
                Shortcut(Icons.Rounded.Tune, stringResource(R.string.smart_controls), stringResource(R.string.anc_gestures), Modifier.weight(1f)) { x.go(2) }
            }
        }
    }
}

@Composable
private fun Shortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Panel(modifier) {
        Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(20.dp)) {
            IconTile(icon, 56)
            Spacer(Modifier.height(18.dp))
            Txt(title, 21, FontWeight.Medium, P.text, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Txt(sub, 14, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Icon(Icons.Rounded.ChevronRight, null, tint = P.accent, modifier = Modifier.size(24.dp))
        }
    }
}

// ================================================================= SOUND

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var showCustomEq by rememberSaveable { mutableStateOf(false) }
    Stack {
        if (!b.connected) Appear(0) { NeedConnect(x) }
        Appear(1) {
            Panel {
                Column(Modifier.padding(22.dp)) {
                    Txt(stringResource(R.string.sound_lab), 30, FontWeight.SemiBold, P.text)
                    Spacer(Modifier.height(6.dp))
                    Txt(stringResource(R.string.master_eq_presets), 16)
                    if (b.connected) {
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BatteryCard(b.battery[0], b.charging[0], "L", stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc))
                            BatteryCard(b.battery[1], b.charging[1], "R", stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc))
                        }
                        if (b.battery[2] >= 0) {
                            Spacer(Modifier.height(10.dp))
                            BatteryCard(b.battery[2], b.charging[2], "Case", stringResource(R.string.widget_case_label), Modifier.fillMaxWidth(), desc = stringResource(R.string.battery_case_desc))
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Buds.PRESETS.forEach { p ->
                            val sel = b.connected && b.eqPreset == p.first
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                                    .background(if (sel) P.accent else P.tile)
                                    .clickable { if (b.connected) b.setEq(p.first) else x.toast(connectFirstText) }
                                    .padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.GraphicEq, null, tint = if (sel) Color.White else P.accent, modifier = Modifier.size(24.dp))
                                Spacer(Modifier.height(6.dp))
                                Txt(stringResource(p.second), 15, FontWeight.Medium, if (sel) Color.White else P.text, maxLines = 1)
                            }
                        }
                    }
                    val cur = Buds.PRESETS.firstOrNull { it.first == b.eqPreset }
                    if (b.connected && cur != null) {
                        Spacer(Modifier.height(10.dp))
                        Txt(stringResource(cur.third), 14)
                    }
                    Spacer(Modifier.height(24.dp))
                    if (!b.connected) {
                        Txt(stringResource(R.string.connect_your_earbuds_to_adjust_the_bass), 14)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Txt(stringResource(R.string.basswave), 22, FontWeight.Medium, P.text)
                                Txt(stringResource(R.string.adjust_the_low_end), 14)
                            }
                            NordSwitch(b.bassOn == true) { b.setBassOn(it) }
                        }
                        val lv = b.bassLevel
                        if (lv != null) {
                            var drag by remember { mutableStateOf<Float?>(null) }
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth()) {
                                Txt(stringResource(R.string.level), 16, FontWeight.Normal, P.text, Modifier.weight(1f))
                                val shown = (drag ?: lv.toFloat()).roundToInt()
                                Txt(if (shown > 0) "+$shown" else "$shown", 18, FontWeight.SemiBold, P.accent)
                            }
                            Slider(
                                value = drag ?: lv.toFloat(),
                                onValueChange = { drag = it },
                                onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null },
                                valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(),
                                steps = (b.bassMax - b.bassMin - 1).coerceAtLeast(0),
                                enabled = b.bassOn == true,
                                colors = SliderDefaults.colors(
                                    thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.soft,
                                    activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                                )
                            )
                        }
                    }
                    if (b.connected && b.customEqProfiles.isNotEmpty()) {
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Txt(stringResource(R.string.custom_eq_edit), 18, FontWeight.Medium, P.text)
                                Txt(stringResource(R.string.custom_eq_hint), 13, lineHeight = 18)
                            }
                            SmallButton(stringResource(R.string.edit), false) { showCustomEq = true }
                        }
                    }
                }
            }
        }
    }
    if (showCustomEq && b.customEqProfiles.isNotEmpty()) {
        val profile = b.customEqProfiles.first()
        var gains by remember(profile) { mutableStateOf(profile.bands.map { it.second.coerceIn(-10, 10) }) }
        SheetDialog({ showCustomEq = false }) {
            SheetTitle(stringResource(R.string.custom_eq_edit))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.custom_eq_hint), 13, modifier = Modifier.weight(1f), lineHeight = 18)
                Text(stringResource(R.string.experimental), color = P.amber, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(8.dp))
            profile.bands.forEachIndexed { i, band ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt(if (band.first >= 1000) "${band.first / 1000} kHz" else "${band.first} Hz", 14, modifier = Modifier.weight(1f))
                    Txt(if (gains[i] > 0) "+${gains[i]} dB" else "${gains[i]} dB", 14, FontWeight.Medium, P.accent)
                }
                Slider(value = gains[i].toFloat(), onValueChange = { v -> gains = gains.toMutableList().also { it[i] = v.roundToInt().coerceIn(-10, 10) } }, valueRange = -10f..10f, steps = 19)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false) { showCustomEq = false } }
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.apply), true) { b.writeCustomEq(profile.bands.mapIndexed { i, band -> band.first to gains[i] }); showCustomEq = false } }
            }
        }
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt(stringResource(R.string.bluetooth_permission_is_needed_to_find_your_pair), 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton(stringResource(R.string.allow_bluetooth)) { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting) { bondedDevices(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (b.searching || b.connecting) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), color = P.accent, strokeWidth = 3.dp)
                Spacer(Modifier.width(12.dp))
                Txt(if (b.connecting) "Connecting\u2026" else "Scanning for your earbuds\u2026", 16, FontWeight.Medium, P.text)
            }
        }
        Txt(stringResource(R.string.select_a_device_to_connect), 18, FontWeight.Medium, P.text)
        Txt(stringResource(R.string.connect_the_earbuds_for_audio_in_bluetooth_setti), 14, lineHeight = 20)
        if (list.isEmpty()) Txt(stringResource(R.string.no_paired_devices_found), 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if ((d.name ?: "").contains("buds", ignoreCase = true))
                    Image(painterResource(R.drawable.hero_buds), null, Modifier.width(54.dp), contentScale = ContentScale.Fit)
                else Icon(Icons.Rounded.Headphones, null, tint = P.accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                val up = d.address in x.audio
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(if (up) stringResource(R.string.connected_for_audio) else if (x.audioKnown) stringResource(R.string.not_connected_for_audio) else stringResource(R.string.paired), 13, color = if (up) P.green else P.sub)
                }
                if (x.audioKnown && !up) {
                    SmallButton(stringResource(R.string.bluetooth)) { openBluetooth(ctx) }
                    Spacer(Modifier.width(6.dp))
                    SmallButton(if (b.connecting) "\u2026" else stringResource(R.string.control), false) { if (!b.connecting) b.connect(d) }
                } else {
                    SmallButton(if (b.connecting) "\u2026" else stringResource(R.string.connect)) { if (!b.connecting) b.connect(d) }
                }
            }
        }
        Row(
            Modifier.clip(CircleShape).clickable {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt(stringResource(R.string.open_bluetooth_settings), 14, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val labelRes: Int)
private val NONE = Opt(Buds.F_NONE, R.string.fn_none)
private val PLAY = Opt(Buds.F_PLAY, R.string.fn_play)
private val PREV = Opt(Buds.F_PREV, R.string.fn_prev)
private val NEXT = Opt(Buds.F_NEXT, R.string.fn_next)
private val VOICE = Opt(Buds.F_VOICE, R.string.fn_voice)
private val GAME = Opt(Buds.F_GAME, R.string.fn_game)
private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, R.string.fn_vol_up), Opt(Buds.F_VOL_DN, R.string.fn_vol_down))
private fun optsFor(gid: Int) = when (gid) { Buds.G_SINGLE -> SINGLE_OPTS; Buds.G_DOUBLE -> DOUBLE_OPTS; Buds.G_TRIPLE -> TRIPLE_OPTS; else -> LONG_OPTS }

@Composable
private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return stringResource(it.labelRes) }
    return when (fn) {
        0x07 -> stringResource(R.string.fn_volume)
        0x0A -> stringResource(R.string.fn_switch_track)
        Buds.F_ANC -> stringResource(R.string.fn_anc)
        else -> stringResource(R.string.unknown_action, Protocol.hex(fn).uppercase())
    }
}

@Composable
private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add(stringResource(R.string.hold_anc))
        if ((mask and Buds.M_OFF) != 0) add(stringResource(R.string.hold_off))
        if ((mask and Buds.M_TRANSP) != 0) add(stringResource(R.string.hold_transparency))
    }
    return n.joinToString(", ")
}

@Composable
private fun wearText(f: Int): String = when {
    f < 0 -> "—"
    (f and 2) != 0 -> stringResource(R.string.wear_in_ear)
    (f and 1) == 0 -> stringResource(R.string.wear_in_case)
    else -> stringResource(R.string.wear_out_case)
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) stringResource(R.string.left) else stringResource(R.string.right)
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast(connectFirstText) }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null

    Stack {
        if (!live) Appear(0) { NeedConnect(x) }

        Appear(1) {
            Panel {
                Column(Modifier.padding(22.dp)) {
                    Txt(stringResource(R.string.control_center), 30, FontWeight.SemiBold, P.text)
                    Spacer(Modifier.height(16.dp))
                    val ancLabel = when (b.ancMode) {
                        Buds.ANC_ON -> stringResource(R.string.hold_anc)
                        Buds.ANC_OFF -> stringResource(R.string.hold_off)
                        Buds.ANC_TRANSP -> stringResource(R.string.hold_transparency)
                        else -> "\u2014"
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.Waves, 48)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(stringResource(R.string.noise_control), 18, FontWeight.Medium, P.text)
                            Txt(if (live) ancLabel else stringResource(R.string.connect_to_use), 14)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    val items = listOf(Icons.Rounded.Waves to stringResource(R.string.noise_cancel), Icons.Rounded.Block to stringResource(R.string.hold_off), Icons.Rounded.Hearing to stringResource(R.string.hold_transparency))
                    val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                    Segmented(items, if (live) ids.indexOf(b.ancMode) else -1) { i -> if (live) b.setAnc(ids[i]) else x.toast(connectFirstText) }
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.SportsEsports, 48)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Txt(stringResource(R.string.game_mode), 18, FontWeight.Medium, P.text)
                            Txt(stringResource(R.string.lower_audio_latency), 14)
                        }
                        NordSwitch(b.gameMode == true, live) { b.setGame(it) }
                    }
                }
            }
        }

        Appear(2) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                BudArt(side == 2, 170.dp, touchSpot = true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Chip(stringResource(R.string.left_2), side == 1) { side = 1 }
                    Chip(stringResource(R.string.right_2), side == 2) { side = 2 }
                }
            }
        }

        Appear(3) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel(stringResource(R.string.when_not_on_a_call))
                Panel {
                    ValueRow(stringResource(R.string.g_single) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE))) { open(Buds.G_SINGLE) }
                    ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE))) { open(Buds.G_DOUBLE) }
                    ValueRow(stringResource(R.string.g_triple) + " $sideName " + stringResource(R.string.earbud), fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE))) { open(Buds.G_TRIPLE) }
                    ValueRow(stringResource(R.string.touch_and_hold), if (live) holdLabel(b.holdMask) else "\u2014") { open(Buds.G_HOLD) }
                    ValueRow(stringResource(R.string.long_touch_and_hold), fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), divider = false) { open(Buds.G_LONG) }
                }
            }
        }

        Appear(4) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel(stringResource(R.string.when_on_a_call))
                Panel {
                    ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), stringResource(R.string.answer_end_call), chevron = false)
                    ValueRow(stringResource(R.string.long_touch_and_hold), stringResource(R.string.decline_call), chevron = false, divider = false)
                }
            }
        }

        Appear(5) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.tile)
                    .clickable { tutorial = true }.padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Txt(stringResource(R.string.learn_earbud_controls), 15)
                Spacer(Modifier.height(14.dp))
                Txt(stringResource(R.string.view_tutorial), 18, FontWeight.Normal, P.text)
            }
        }
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> stringResource(R.string.g_single); Buds.G_DOUBLE -> stringResource(R.string.g_double); else -> stringResource(R.string.g_triple) }) + " $sideName " + stringResource(R.string.earbud)
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(stringResource(o.labelRes), now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton(stringResource(R.string.cancel), false) { dlg = 0 }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }) {
            SheetTitle(stringResource(R.string.g_long))
            Txt(stringResource(R.string.long_touch_volume_help), 16, lineHeight = 23)
            Spacer(Modifier.height(14.dp))
            Txt(stringResource(R.string.long_touch_anc_help), 16, lineHeight = 23)
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEachIndexed { i, o ->
                RadioRow(stringResource(o.labelRes), now == o.fn, divider = i < LONG_OPTS.size - 1) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton(stringResource(R.string.cancel), false) { dlg = 0 }
        }
    }

    if (g == Buds.G_HOLD) {
        var sel by remember { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) sel = v }
        SheetDialog({ dlg = 0 }) {
            SheetTitle(stringResource(R.string.g_hold))
            Txt(if (n == 1) stringResource(R.string.hold_one_option) else stringResource(R.string.hold_many_options, n), 16, lineHeight = 22)
            Spacer(Modifier.height(6.dp))
            CheckRow(stringResource(R.string.hold_anc), stringResource(R.string.hold_anc_sub), (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow(stringResource(R.string.hold_off), stringResource(R.string.hold_off_sub), (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow(stringResource(R.string.hold_transparency), stringResource(R.string.hold_transparency_sub), (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.confirm), true) { b.setHoldMask(sel); dlg = 0 } }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle(stringResource(R.string.earbud_controls))
            Txt(stringResource(R.string.single_double_and_triple_tap_tap_the_touch_area_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.touch_and_hold_hold_until_you_hear_a_beep_then_l), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.long_touch_and_hold_keep_holding_until_you_hear_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.during_a_call_double_tap_to_answer_or_end_it_lon), 16, lineHeight = 23)
            Spacer(Modifier.height(18.dp))
            WideButton(stringResource(R.string.got_it), true) { tutorial = false }
        }
    }
}

// ================================================================= SETTINGS

@Composable
private fun ThemeButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(if (sel) P.accent else P.tile).clickable(onClick = onClick).padding(vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (sel) Color.White else P.text, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Txt(label, 20, FontWeight.Medium, if (sel) Color.White else P.text, maxLines = 1)
    }
}

@Composable
private fun PaletteOption(index: Int, name: String, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(shape).border(2.dp, if (sel) paletteColor(index) else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(paletteColor(index)), contentAlignment = Alignment.Center) {
            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(8.dp))
        Txt(name, 16, FontWeight.Normal, P.text, maxLines = 1)
    }
}

@Composable
fun SettingsScreen(x: Ctx) {
    var diag by remember { mutableStateOf(x.prefs.diag) }
    var batteryNotif by remember { mutableStateOf(Buds.prefs.batteryNotif) }
    var rename by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf(Buds.customName ?: Buds.deviceName) }
    val ctx = LocalContext.current
    Stack {
        Appear(0) {
            Panel {
                Column(Modifier.padding(22.dp)) {
                    Txt(stringResource(R.string.personalize_budsy), 30, FontWeight.SemiBold, P.text)
                    ValueRow(stringResource(R.string.rename_device), Buds.displayName.ifEmpty { stringResource(R.string.app_name) }, divider = true) { nameDraft = Buds.customName ?: Buds.deviceName; rename = true }
                    SwitchRow(stringResource(R.string.battery_notification), stringResource(R.string.battery_notification_sub), batteryNotif) { enabled ->
                        batteryNotif = enabled
                        Buds.prefs.batteryNotif = enabled
                        if (!enabled) BatteryNotifier.cancel(ctx) else if (!x.notifGranted) x.askNotifPerm() else BatteryNotifier.update(ctx)
                    }
                    SwitchRow(stringResource(R.string.wear_detection), stringResource(R.string.wear_detection_sub), Buds.wearDetect == true) { Buds.setWearDetect(it) }
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, top = 2.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.experimental).uppercase(), color = P.amber, style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(12.dp))
                    Txt(stringResource(R.string.appearance), 17)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ThemeButton(Icons.Rounded.DarkMode, stringResource(R.string.dark), x.dark, Modifier.weight(1f)) { x.setDark(true) }
                        ThemeButton(Icons.Rounded.LightMode, stringResource(R.string.light), !x.dark, Modifier.weight(1f)) { x.setDark(false) }
                    }
                    if (x.dark) {
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Txt(stringResource(R.string.amoled_black), 17, FontWeight.Medium, P.text); Txt(stringResource(R.string.pure_black_background_saves_battery_on_oled_scre), 13) }
                            Spacer(Modifier.width(10.dp)); NordSwitch(x.amoled) { x.setAmoled(it) }
                        }
                    }
                    Spacer(Modifier.height(22.dp)); Txt(stringResource(R.string.accent_palette), 17); Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { PaletteNames.forEachIndexed { i, n -> PaletteOption(i, n, x.accentIdx == i, Modifier.weight(1f)) { x.setAccent(i) } } }
                }
            }
        }
        Appear(1) {
            Panel {
                Column {
                    Row(Modifier.fillMaxWidth().padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Rounded.ShowChart, 48); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) { Txt(stringResource(R.string.diagnostics), 21, FontWeight.Medium, P.text); Txt(stringResource(R.string.show_gesture_table_and_protocol_log), 14) }
                        Spacer(Modifier.width(10.dp)); NordSwitch(diag) { diag = it; x.prefs.diag = it }
                    }
                    if (diag) Diagnostics(x)
                }
            }
        }
    }
    if (rename) AlertDialog(onDismissRequest = { rename = false }, title = { Text(stringResource(R.string.rename_device)) }, text = { TextField(value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true, label = { Text(stringResource(R.string.rename_hint)) }) }, confirmButton = { TextButton(onClick = { Buds.setCustomName(nameDraft); rename = false }) { Text(stringResource(R.string.save)) } }, dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun Diagnostics(x: Ctx) {
    val b = x.b
    val logCopiedText = stringResource(R.string.log_copied)
    val clip = LocalClipboardManager.current
    Column(Modifier.padding(bottom = 22.dp)) {
        ValueRow(stringResource(R.string.name_2), if (b.connected) b.deviceName else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.bluetooth_address_2), if (b.connected) b.deviceAddr else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.status_2), if (b.connected) stringResource(R.string.connected) else b.status, chevron = false)
        ValueRow(stringResource(R.string.firmware_2), if (b.connected) (b.firmware ?: "\u2014") else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.connected_to_buds_2), if (b.connected && b.peers.isNotEmpty()) b.peers.joinToString(", ") else "\u2014", chevron = false, divider = false)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(8.dp))
            if (b.connected) WideButton(stringResource(R.string.disconnect_2), false) { b.disconnect() } else ConnectBlock(x)

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.custom_eq_saved_on_the_buds_read_only), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            Txt(b.customEq ?: stringResource(R.string.nothing_read_yet), 13, FontWeight.Normal, P.sub, lineHeight = 18)

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.feature_flags), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.scan_2), false) { b.scanFlags() }
            }
            Spacer(Modifier.height(4.dp))
            Txt(stringResource(R.string.to_find_a_switch_such_as_ear_detection_or_dual_c), 12, lineHeight = 17)
            Spacer(Modifier.height(6.dp))
            if (b.flags.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 13)
            b.flags.toSortedMap().forEach { (id, v) ->
                SwitchRow(title = stringResource(R.string.flag_name_unknown, Protocol.hex(id).uppercase()), sub = "ID 0x${Protocol.hex(id).uppercase()}", on = v == 1) { Buds.setFlag(id, it) }
            }

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.gesture_table_reported_by_the_buds), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            val keys = b.gest.keys.sorted()
            if (keys.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 14)
            keys.forEach { k ->
                Txt(stringResource(R.string.gesture_table_entry, if (k / 16 == 1) stringResource(R.string.left) else if (k / 16 == 2) stringResource(R.string.right) else stringResource(R.string.gesture_side, k / 16), k % 16, Protocol.hex(b.gest[k] ?: 0).uppercase()), 13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp))
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.protocol_log), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.copy), false) { clip.setText(AnnotatedString(b.logText())); x.toast(logCopiedText) }
            }
            Spacer(Modifier.height(6.dp))
            val ver = b.logVersion
            val lines = remember(ver) { b.logText().lines().takeLast(14) }
            Txt(if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) stringResource(R.string.empty) else lines.joinToString("\n"), 11, FontWeight.Normal, P.sub, lineHeight = 15)
            Spacer(Modifier.height(16.dp))
            Txt(stringResource(R.string.unofficial_disclaimer), 13, lineHeight = 19)
        }
    }
}
