package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nordbuds.studio.protocol.Protocol
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

fun openBluetooth(ctx: Context) {
    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { }
}

/** Flat notice row: icon, two lines of text and an optional button. */
@Composable
private fun NoticeRow(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, title: String, detail: String, action: String, onAction: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt(title, 16, FontWeight.SemiBold, P.text)
                Txt(detail, 14, lineHeight = 19)
            }
            Spacer(Modifier.width(10.dp))
            SmallButton(action, false, onAction)
        }
        FullDivider()
    }
}

@Composable
fun NeedConnect(x: Ctx) {
    NoticeRow(
        Icons.Rounded.Bluetooth, P.accent,
        stringResource(R.string.earbuds_not_connected), stringResource(R.string.connect_on_the_overview_tab_first),
        stringResource(R.string.overview)
    ) { x.go(0) }
}

@Composable
private fun AudioWarning(name: String) {
    val ctx = LocalContext.current
    NoticeRow(
        Icons.Rounded.Warning, P.amber,
        stringResource(R.string.audio_is_not_connected), stringResource(R.string.audio_warning_detail, name),
        stringResource(R.string.open_2)
    ) { openBluetooth(ctx) }
}

/** Little "saved / saving / failed" line under a setting. */
@Composable
private fun SaveLine(state: Buds.SaveState, message: String) {
    if (state == Buds.SaveState.IDLE || message.isBlank()) return
    val c = when (state) { Buds.SaveState.SAVED -> P.green; Buds.SaveState.FAILED -> P.amber; Buds.SaveState.SAVING -> P.accent; else -> P.sub }
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (state == Buds.SaveState.SAVING) CircularProgressIndicator(Modifier.size(15.dp), color = c, strokeWidth = 2.dp)
        else Icon(if (state == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = c, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Txt(message, 13, color = c, lineHeight = 17)
    }
}

/** Left / right / case battery, side by side. */
@Composable
private fun BatteryRow(b: Buds) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        BatteryStat(b.battery[0], b.charging[0], stringResource(R.string.left), Modifier.weight(1f), desc = stringResource(R.string.battery_left_desc))
        BatteryStat(b.battery[1], b.charging[1], stringResource(R.string.right), Modifier.weight(1f), desc = stringResource(R.string.battery_right_desc))
        if (b.connected && b.battery[2] >= 0)
            BatteryStat(b.battery[2], b.charging[2], stringResource(R.string.widget_case_label), Modifier.weight(1f), desc = stringResource(R.string.battery_case_desc))
    }
}

private val NoiseIds = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)

@Composable
private fun noiseItems() = listOf(
    Icons.Rounded.Waves to stringResource(R.string.noise_cancel),
    Icons.Rounded.Block to stringResource(R.string.hold_off),
    Icons.Rounded.Hearing to stringResource(R.string.hold_transparency)
)

// ================================================================= OVERVIEW

@Composable
fun OverviewScreen(x: Ctx) {
    val b = x.b
    var showList by rememberSaveable { mutableStateOf(false) }
    Stack {
        if (b.connected && x.audioKnown && b.deviceAddr !in x.audio) {
            AudioWarning(if (b.deviceName.isNotEmpty()) b.deviceName else stringResource(R.string.your_earbuds))
        }

        Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.hero_buds), "OnePlus Nord Buds 3 in its case", Modifier.width(210.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bluetooth, null, tint = if (b.connected) P.green else P.sub, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Txt(if (b.connected) stringResource(R.string.connected) else b.status, 15, color = if (b.connected) P.green else P.sub, maxLines = 1)
            }
            Spacer(Modifier.height(16.dp))
            if (!b.connected) {
                if (b.autoPaused) {
                    Txt(stringResource(R.string.auto_connect_is_off_because_you_disconnected), 14, color = P.sub, align = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
                    Spacer(Modifier.height(10.dp))
                }
                AccentPill(if (b.autoPaused) stringResource(R.string.connect_auto_on) else stringResource(R.string.connect_earbuds), Icons.Rounded.Bluetooth) {
                    b.resumeAutoConnect()
                    if (!x.perm) x.askPerm() else showList = !showList
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SmallButton(stringResource(R.string.refresh_2), false) { b.refreshAll() }
                    SmallButton(stringResource(R.string.disconnect_2), false) { b.disconnect() }
                }
            }
        }
        if (!b.connected && showList) Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) { ConnectBlock(x) }

        Spacer(Modifier.height(16.dp))
        BatteryRow(b)

        if (b.connected) {
            SectionLabel(stringResource(R.string.noise_control))
            Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.noise_cancel), "Reduce outside noise", Icons.Rounded.Waves, b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { b.setAnc(Buds.ANC_ON) }
                    FeatureTile(stringResource(R.string.hold_off), "Natural listening", Icons.Rounded.Block, b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { b.setAnc(Buds.ANC_OFF) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.hold_transparency), "Hear surroundings", Icons.Rounded.Hearing, b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { b.setAnc(Buds.ANC_TRANSP) }
                    Spacer(Modifier.weight(1f).height(60.dp))
                }
                SaveLine(b.ancSaveState, b.ancSaveMessage)
            }

            SectionLabel(stringResource(R.string.find_my_earbuds))
            Column(Modifier.padding(horizontal = 16.dp)) {
                Txt(stringResource(R.string.plays_a_loud_tone_only_use_it_when_the_earbuds_a), 14, lineHeight = 19)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.left_2), "Locate left bud", Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, Modifier.weight(1f), 21) { b.findEarbuds(1) }
                    FeatureTile(stringResource(R.string.right_2), "Locate right bud", Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, Modifier.weight(1f), 22) { b.findEarbuds(2) }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureTile(stringResource(R.string.both_2), "Locate both", Icons.Rounded.VolumeUp, b.findAlertRequested && b.findAlertSide == 3, Modifier.weight(1f), 23) { b.findEarbuds(3) }
                    Spacer(Modifier.weight(1f).height(60.dp))
                }
                if (b.findAlertRequested || b.findAlertMessage.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.VolumeUp, null, tint = P.accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Txt("${if (b.findAlertRequested) "Alert requested" else "Stop requested"} · ${when (b.findAlertSide) { 1 -> "Left"; 2 -> "Right"; else -> "Both" }}", 13, color = P.sub, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.weight(1f)) { WideButton("Play again", false) { b.findEarbuds(b.findAlertSide) } }
                        Box(Modifier.weight(1f)) { WideButton("Pause / Stop", true) { b.stopFindEarbuds() } }
                    }
                    Spacer(Modifier.height(6.dp))
                    Txt(b.findAlertMessage.ifBlank { "Tone stop acknowledgement is not exposed by the currently verified protocol." }, 12, color = P.sub, lineHeight = 16)
                }
                if (b.wear.any { it >= 0 }) {
                    Spacer(Modifier.height(12.dp))
                    Txt(stringResource(R.string.wear_sides, wearText(b.wear[0]), wearText(b.wear[1])), 14)
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        FullDivider()
        ValueRow(stringResource(R.string.sound_lab), stringResource(R.string.eq_bass_audio)) { x.go(1) }
        ValueRow(stringResource(R.string.smart_controls), stringResource(R.string.anc_gestures), divider = false) { x.go(2) }
        FullDivider()
    }
}

// ================================================================= SOUND

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    Stack {
        if (!b.connected) NeedConnect(x)

        SectionLabel(stringResource(R.string.eq_presets))
        Column(Modifier.padding(horizontal = 16.dp)) {
            val labels = Buds.PRESETS.map { null to stringResource(it.second) }
            val idx = if (b.connected) Buds.PRESETS.indexOfFirst { it.first == b.eqPreset } else -1
            Segmented(labels, idx) { i ->
                if (b.connected) { b.setEq(Buds.PRESETS[i].first); EqStore.setActive(x.prefs, -1) } else x.toast(connectFirstText)
            }
            val cur = Buds.PRESETS.firstOrNull { it.first == b.eqPreset }
            if (b.connected && cur != null) { Spacer(Modifier.height(10.dp)); Txt(stringResource(cur.third), 14) }
        }

        SectionLabel(stringResource(R.string.basswave))
        if (!b.connected) {
            Txt(stringResource(R.string.connect_your_earbuds_to_adjust_the_bass), 14, modifier = Modifier.padding(horizontal = 16.dp))
        } else {
            FullDivider()
            SwitchRow(stringResource(R.string.basswave), stringResource(R.string.adjust_the_low_end), b.bassOn == true, divider = b.bassLevel != null) { b.setBassOn(it) }
            val lv = b.bassLevel
            if (lv != null) {
                var drag by remember { mutableStateOf<Float?>(null) }
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Txt(stringResource(R.string.level), 17, FontWeight.Normal, P.text, Modifier.weight(1f))
                        val shown = (drag ?: lv.toFloat()).roundToInt()
                        Txt(if (shown > 0) "+$shown" else "$shown", 17, FontWeight.SemiBold, P.accent)
                    }
                    Slider(
                        value = drag ?: lv.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null },
                        valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(),
                        steps = (b.bassMax - b.bassMin - 1).coerceAtLeast(0),
                        enabled = b.bassOn == true,
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White, activeTrackColor = P.accent, inactiveTrackColor = P.track,
                            activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                        )
                    )
                }
            }
            FullDivider()
        }

        CustomEqSection(x)
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt(stringResource(R.string.bluetooth_permission_is_needed_to_find_your_pair), 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton(stringResource(R.string.allow_bluetooth)) { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting) { bondedDevices(ctx) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (b.searching || b.connecting) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), color = P.accent, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Txt(if (b.connecting) "Connecting…" else "Scanning for your earbuds…", 16, FontWeight.Medium, P.text)
            }
        }
        Txt(stringResource(R.string.select_a_device_to_connect), 17, FontWeight.SemiBold, P.text)
        Txt(stringResource(R.string.connect_the_earbuds_for_audio_in_bluetooth_setti), 14, lineHeight = 20)
        if (list.isEmpty()) Txt(stringResource(R.string.no_paired_devices_found), 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if ((d.name ?: "").contains("buds", ignoreCase = true))
                    Image(painterResource(R.drawable.hero_buds), null, Modifier.width(54.dp), contentScale = ContentScale.Fit)
                else Icon(Icons.Rounded.Headphones, null, tint = P.accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                val up = d.address in x.audio
                Column(Modifier.weight(1f)) {
                    Txt(d.name ?: d.address, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt(if (up) stringResource(R.string.connected_for_audio) else if (x.audioKnown) stringResource(R.string.not_connected_for_audio) else stringResource(R.string.paired), 13, color = if (up) P.green else P.sub)
                }
                if (x.audioKnown && !up) {
                    SmallButton(stringResource(R.string.bluetooth)) { openBluetooth(ctx) }
                    Spacer(Modifier.width(6.dp))
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.control), false) { if (!b.connecting) b.connect(d) }
                } else {
                    SmallButton(if (b.connecting) "…" else stringResource(R.string.connect)) { if (!b.connecting) b.connect(d) }
                }
            }
            Divider()
        }
        Row(
            Modifier.clip(CircleShape).clickable { openBluetooth(ctx) }.padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt(stringResource(R.string.open_bluetooth_settings), 15, FontWeight.SemiBold, P.accent)
        }
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val labelRes: Int)
private val NONE = Opt(Buds.F_NONE, R.string.fn_none)
private val PLAY = Opt(Buds.F_PLAY, R.string.fn_play)
private val PREV = Opt(Buds.F_PREV, R.string.fn_prev)
private val NEXT = Opt(Buds.F_NEXT, R.string.fn_next)
private val VOICE = Opt(Buds.F_VOICE, R.string.fn_voice)
private val GAME = Opt(Buds.F_GAME, R.string.fn_game)
private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, R.string.fn_vol_up), Opt(Buds.F_VOL_DN, R.string.fn_vol_down))
private fun optsFor(gid: Int) = when (gid) { Buds.G_SINGLE -> SINGLE_OPTS; Buds.G_DOUBLE -> DOUBLE_OPTS; Buds.G_TRIPLE -> TRIPLE_OPTS; else -> LONG_OPTS }

@Composable
private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return stringResource(it.labelRes) }
    return when (fn) {
        0x07 -> stringResource(R.string.fn_volume)
        0x0A -> stringResource(R.string.fn_switch_track)
        Buds.F_ANC -> stringResource(R.string.fn_anc)
        else -> stringResource(R.string.unknown_action, Protocol.hex(fn).uppercase())
    }
}

@Composable
private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add(stringResource(R.string.hold_anc))
        if ((mask and Buds.M_OFF) != 0) add(stringResource(R.string.hold_off))
        if ((mask and Buds.M_TRANSP) != 0) add(stringResource(R.string.hold_transparency))
    }
    return n.joinToString(", ")
}

@Composable
private fun wearText(f: Int): String = when {
    f < 0 -> "—"
    (f and 2) != 0 -> stringResource(R.string.wear_in_ear)
    (f and 1) == 0 -> stringResource(R.string.wear_in_case)
    else -> stringResource(R.string.wear_out_case)
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    val connectFirstText = stringResource(R.string.err_connect_first)
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) stringResource(R.string.left) else stringResource(R.string.right)
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast(connectFirstText) }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null

    Stack {
        if (!live) NeedConnect(x)

        SectionLabel(stringResource(R.string.noise_control))
        Column(Modifier.padding(horizontal = 14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.noise_cancel), "Reduce outside noise", Icons.Rounded.Waves, live && b.ancMode == Buds.ANC_ON, Modifier.weight(1f), 11) { if (live) b.setAnc(Buds.ANC_ON) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.hold_off), "Natural listening", Icons.Rounded.Block, live && b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), 12) { if (live) b.setAnc(Buds.ANC_OFF) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.hold_transparency), "Hear surroundings", Icons.Rounded.Hearing, live && b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), 13) { if (live) b.setAnc(Buds.ANC_TRANSP) else x.toast(connectFirstText) }
            }
            if (live) SaveLine(b.ancSaveState, b.ancSaveMessage)
        }

        Spacer(Modifier.height(20.dp))
        FullDivider()
        SwitchRow(stringResource(R.string.game_mode), stringResource(R.string.lower_audio_latency), b.gameMode == true, live, divider = false) { b.setGame(it) }
        FullDivider()
        SectionLabel(stringResource(R.string.find_my_earbuds))
        Column(Modifier.padding(horizontal = 14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(stringResource(R.string.left_2), "Play left bud tone", Icons.Rounded.ChevronLeft, b.findAlertRequested && b.findAlertSide == 1, Modifier.weight(1f), 21) { if (live) b.findEarbuds(1) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.right_2), "Play right bud tone", Icons.Rounded.ChevronRight, b.findAlertRequested && b.findAlertSide == 2, Modifier.weight(1f), 22) { if (live) b.findEarbuds(2) else x.toast(connectFirstText) }
                FeatureTile(stringResource(R.string.both_2), "Play both tones", Icons.Rounded.VolumeUp, b.findAlertRequested && b.findAlertSide == 3, Modifier.weight(1f), 23) { if (live) b.findEarbuds(3) else x.toast(connectFirstText) }
            }
            if (live && b.findAlertRequested) { Spacer(Modifier.height(8.dp)); SmallButton("Stop alert", false) { b.stopFindEarbuds() } }
        }

        Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BudArt(side == 2, 150.dp, touchSpot = true)
            Spacer(Modifier.height(12.dp))
            Segmented(listOf(null to stringResource(R.string.left_2), null to stringResource(R.string.right_2)), side - 1, Modifier.width(220.dp)) { side = it + 1 }
        }

        SectionLabel(stringResource(R.string.when_not_on_a_call))
        FullDivider()
        Column(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Single tap", fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE)), Icons.Rounded.TouchApp, false, Modifier.weight(1f), 41) { open(Buds.G_SINGLE) }
                FeatureTile("Double tap", fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE)), Icons.Rounded.Fingerprint, false, Modifier.weight(1f), 42) { open(Buds.G_DOUBLE) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Triple tap", fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE)), Icons.Rounded.MoreHoriz, false, Modifier.weight(1f), 43) { open(Buds.G_TRIPLE) }
                FeatureTile("Touch & hold", if (live) holdLabel(b.holdMask) else "—", Icons.Rounded.PanTool, false, Modifier.weight(1f), 44) { open(Buds.G_HOLD) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile("Long hold", fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), Icons.Rounded.PanTool, false, Modifier.weight(1f), 45) { open(Buds.G_LONG) }
                Spacer(Modifier.weight(1f).height(60.dp))
            }
        }
        FullDivider()

        SectionLabel(stringResource(R.string.when_on_a_call))
        FullDivider()
        ValueRow(stringResource(R.string.g_double) + " $sideName " + stringResource(R.string.earbud), stringResource(R.string.answer_end_call), chevron = false)
        ValueRow(stringResource(R.string.long_touch_and_hold), stringResource(R.string.decline_call), chevron = false, divider = false)
        FullDivider()

        SectionLabel(stringResource(R.string.learn_earbud_controls))
        FullDivider()
        ValueRow(stringResource(R.string.view_tutorial), "", divider = false) { tutorial = true }
        FullDivider()
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> stringResource(R.string.g_single); Buds.G_DOUBLE -> stringResource(R.string.g_double); else -> stringResource(R.string.g_triple) }) + " $sideName " + stringResource(R.string.earbud)
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(stringResource(o.labelRes), now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }, footer = { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }) {
            SheetTitle(stringResource(R.string.g_long))
            Txt(stringResource(R.string.long_touch_volume_help), 16, lineHeight = 23)
            Spacer(Modifier.height(14.dp))
            Txt(stringResource(R.string.long_touch_anc_help), 16, lineHeight = 23)
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEachIndexed { i, o ->
                RadioRow(stringResource(o.labelRes), now == o.fn, divider = i < LONG_OPTS.size - 1) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
        }
    }

    if (g == Buds.G_HOLD) {
        LaunchedEffect(Unit) { b.queryHold() }
        var sel by rememberSaveable { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        var holdTouched by remember { mutableStateOf(false) }
        LaunchedEffect(b.holdMask) { if (!holdTouched && b.holdMask > 0) sel = b.holdMask and 7 }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) { sel = v; holdTouched = true } }
        SheetDialog({ dlg = 0 }, footer = {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton(if (b.holdSaveState == Buds.SaveState.SAVING) "Saving…" else stringResource(R.string.confirm), true) { if (b.holdSaveState != Buds.SaveState.SAVING) b.updateHoldMask(sel) } }
            }
        }) {
            SheetTitle(stringResource(R.string.g_hold))
            Txt(if (n == 1) stringResource(R.string.hold_one_option) else stringResource(R.string.hold_many_options, n), 16, lineHeight = 22)
            Spacer(Modifier.height(6.dp))
            CheckRow(stringResource(R.string.hold_anc), stringResource(R.string.hold_anc_sub), (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow(stringResource(R.string.hold_off), stringResource(R.string.hold_off_sub), (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow(stringResource(R.string.hold_transparency), stringResource(R.string.hold_transparency_sub), (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            if (b.holdSaveState != Buds.SaveState.IDLE || b.holdSaveMessage.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                val saveColor = when (b.holdSaveState) {
                    Buds.SaveState.SAVED -> P.green
                    Buds.SaveState.FAILED -> P.amber
                    Buds.SaveState.SAVING -> P.accent
                    else -> P.sub
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (b.holdSaveState == Buds.SaveState.SAVING) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = saveColor)
                    else Icon(if (b.holdSaveState == Buds.SaveState.SAVED) Icons.Rounded.CheckCircle else Icons.Rounded.Info, null, tint = saveColor, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Txt(b.holdSaveMessage, 12, color = saveColor, lineHeight = 17)
                }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle(stringResource(R.string.earbud_controls))
            Txt(stringResource(R.string.single_double_and_triple_tap_tap_the_touch_area_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.touch_and_hold_hold_until_you_hear_a_beep_then_l), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.long_touch_and_hold_keep_holding_until_you_hear_), 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt(stringResource(R.string.during_a_call_double_tap_to_answer_or_end_it_lon), 16, lineHeight = 23)
            Spacer(Modifier.height(18.dp))
            WideButton(stringResource(R.string.got_it), true) { tutorial = false }
        }
    }
}
// ================================================================= SETTINGS

@Composable
fun SettingsScreen(x: Ctx) {
    var diag by remember { mutableStateOf(x.prefs.diag) }
    var batteryNotif by remember { mutableStateOf(Buds.prefs.batteryNotif) }
    var rename by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf(Buds.customName ?: Buds.deviceName) }
    val ctx = LocalContext.current
    Stack {
        FullDivider()
        ValueRow(stringResource(R.string.rename_device), Buds.displayName.ifEmpty { stringResource(R.string.app_name) }) { nameDraft = Buds.customName ?: Buds.deviceName; rename = true }
        SwitchRow(stringResource(R.string.battery_notification), stringResource(R.string.battery_notification_sub), batteryNotif) { enabled ->
            batteryNotif = enabled
            Buds.prefs.batteryNotif = enabled
            if (!enabled) BatteryNotifier.cancel(ctx) else if (!x.notifGranted) x.askNotifPerm() else BatteryNotifier.update(ctx)
        }
        SwitchRow(stringResource(R.string.wear_detection), stringResource(R.string.wear_detection_sub), Buds.wearDetect == true, divider = false) { Buds.setWearDetect(it) }
        FullDivider()
        Txt(stringResource(R.string.experimental).uppercase(), 12, FontWeight.Medium, P.amber, Modifier.padding(start = 16.dp, top = 6.dp))

        SectionLabel(stringResource(R.string.appearance))
        Column(Modifier.padding(horizontal = 16.dp)) {
            Segmented(
                listOf(null to stringResource(R.string.light), null to stringResource(R.string.dark), null to stringResource(R.string.amoled)),
                x.theme
            ) { x.setTheme(it) }
        }

        Spacer(Modifier.height(28.dp))
        FullDivider()
        SwitchRow(stringResource(R.string.diagnostics), stringResource(R.string.show_gesture_table_and_protocol_log), diag, divider = false) { diag = it; x.prefs.diag = it }
        FullDivider()
        if (diag) Diagnostics(x)
    }
    if (rename) AlertDialog(onDismissRequest = { rename = false }, title = { Text(stringResource(R.string.rename_device)) }, text = { TextField(value = nameDraft, onValueChange = { nameDraft = it }, singleLine = true, label = { Text(stringResource(R.string.rename_hint)) }) }, confirmButton = { TextButton(onClick = { Buds.renameDevice(nameDraft); rename = false }) { Text(stringResource(R.string.save)) } }, dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.cancel)) } })
}

@Composable
private fun Diagnostics(x: Ctx) {
    val b = x.b
    val logCopiedText = stringResource(R.string.log_copied)
    val clip = LocalClipboardManager.current
    Column(Modifier.padding(bottom = 22.dp)) {
        ValueRow(stringResource(R.string.name_2), if (b.connected) b.deviceName else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.bluetooth_address_2), if (b.connected) b.deviceAddr else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.status_2), if (b.connected) stringResource(R.string.connected) else b.status, chevron = false)
        ValueRow(stringResource(R.string.firmware_2), if (b.connected) (b.firmware ?: "\u2014") else "\u2014", chevron = false)
        ValueRow(stringResource(R.string.connected_to_buds_2), if (b.connected && b.peers.isNotEmpty()) b.peers.joinToString(", ") else "\u2014", chevron = false, divider = false)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            if (b.connected) WideButton(stringResource(R.string.disconnect_2), false) { b.disconnect() } else ConnectBlock(x)

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.custom_eq_saved_on_the_buds_read_only), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            Txt(b.customEq ?: stringResource(R.string.nothing_read_yet), 13, FontWeight.Normal, P.sub, lineHeight = 18)

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.feature_flags), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.scan_2), false) { b.scanFlags() }
            }
            Spacer(Modifier.height(4.dp))
            Txt(stringResource(R.string.to_find_a_switch_such_as_ear_detection_or_dual_c), 12, lineHeight = 17)
            Spacer(Modifier.height(6.dp))
            if (b.flags.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 13)
            b.flags.toSortedMap().forEach { (id, v) ->
                SwitchRow(title = stringResource(R.string.flag_name_unknown, Protocol.hex(id).uppercase()), sub = "ID 0x${Protocol.hex(id).uppercase()}", on = v == 1) { Buds.setFlag(id, it) }
            }

            Spacer(Modifier.height(20.dp))
            Txt(stringResource(R.string.gesture_table_reported_by_the_buds), 16, FontWeight.Medium, P.text)
            Spacer(Modifier.height(6.dp))
            val keys = b.gest.keys.sorted()
            if (keys.isEmpty()) Txt(stringResource(R.string.nothing_read_yet), 14)
            keys.forEach { k ->
                Txt(stringResource(R.string.gesture_table_entry, if (k / 16 == 1) stringResource(R.string.left) else if (k / 16 == 2) stringResource(R.string.right) else stringResource(R.string.gesture_side, k / 16), k % 16, Protocol.hex(b.gest[k] ?: 0).uppercase()), 13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp))
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt(stringResource(R.string.protocol_log), 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                SmallButton(stringResource(R.string.copy), false) { clip.setText(AnnotatedString(b.logText())); x.toast(logCopiedText) }
            }
            Spacer(Modifier.height(6.dp))
            val ver = b.logVersion
            val lines = remember(ver) { b.logText().lines().takeLast(14) }
            Txt(if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) stringResource(R.string.empty) else lines.joinToString("\n"), 11, FontWeight.Normal, P.sub, lineHeight = 15)
            Spacer(Modifier.height(16.dp))
            Txt(stringResource(R.string.unofficial_disclaimer), 13, lineHeight = 19)
        }
    }
}
