package com.nordbuds.studio

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val GlassInk = Color(0xFFF4F7FF)
private val GlassMuted = Color(0xFFAAB7D0)
private val GlassBlue = Color(0xFF83B9FF)
private val GlassViolet = Color(0xFF9A8CFF)

/**
 * A new dashboard composition for Budsy. Device values and actions are read from
 * the existing Ctx/Buds state; no placeholder hardware values are introduced.
 */
@Composable
fun PremiumHomeScreen(x: Ctx) {
    val b = x.b
    val context = LocalContext.current
    val connected = b.connected
    val pulse = rememberInfiniteTransition(label = "budsyHeroPulse")
    val floatY by pulse.animateFloat(
        initialValue = -3f, targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "heroFloat"
    )
    val heroScale by animateFloatAsState(
        targetValue = if (connected) 1f else .97f,
        animationSpec = spring(dampingRatio = .72f, stiffness = 240f),
        label = "heroScale"
    )

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0A1020), Color(0xFF10162A), Color(0xFF090E1B)))
        ).padding(horizontal = 20.dp).padding(top = 18.dp, bottom = 92.dp)
            .verticalScroll(androidx.compose.foundation.rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("BUDSY", color = GlassMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Spacer(Modifier.height(4.dp))
                Text("Your soundspace.", color = GlassInk, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.7).sp)
            }
            GlassIconButton(
                icon = Icons.Rounded.Headphones,
                description = "Choose earbuds",
                onClick = { x.openDevicePicker() }
            )
        }

        // Hero visual: layered vector lighting and perspective rings, no fake 3D asset claim.
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(34.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF222E4D), Color(0xFF171E35), Color(0xFF252044))))
                .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.34f), Color.White.copy(.05f), GlassBlue.copy(.25f))), RoundedCornerShape(34.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (connected) (b.deviceName.ifBlank { "Budsy earbuds" }) else "Your earbuds", color = GlassInk, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(if (connected) Color(0xFF75E3BB) else Color(0xFFFFC779)))
                        Spacer(Modifier.width(7.dp))
                        Text(if (connected) "CONNECTED" else if (b.connecting || b.searching) "CONNECTING" else "NOT CONNECTED",
                            color = if (connected) Color(0xFF8DE8C5) else GlassMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    }
                }
                Text("LIVE", color = GlassBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
                    modifier = Modifier.clip(CircleShape).background(Color.White.copy(.07f)).padding(horizontal = 11.dp, vertical = 7.dp))
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().scale(heroScale)) {
                    val cx = size.width / 2
                    val cy = size.height / 2 + floatY.dp.toPx()
                    val maxR = size.minDimension * .43f
                    drawCircle(Brush.radialGradient(listOf(GlassBlue.copy(.28f), GlassViolet.copy(.10f), Color.Transparent), center = androidx.compose.ui.geometry.Offset(cx, cy), radius = maxR), radius = maxR, center = androidx.compose.ui.geometry.Offset(cx, cy))
                    drawCircle(Color.White.copy(.10f), radius = maxR * .77f, center = androidx.compose.ui.geometry.Offset(cx, cy), style = Stroke(width = 1.dp.toPx()))
                    drawCircle(GlassBlue.copy(.18f), radius = maxR * .61f, center = androidx.compose.ui.geometry.Offset(cx, cy), style = Stroke(width = 1.dp.toPx()))
                    // Stylized charging case silhouette, built from layered vector shapes.
                    val caseW = size.width * .48f
                    val caseH = size.height * .30f
                    val caseTop = cy + maxR * .10f
                    drawRoundRect(Brush.linearGradient(listOf(Color(0xFFEAF1FF), Color(0xFF9BAED1), Color(0xFFF9FBFF)), start = androidx.compose.ui.geometry.Offset(cx-caseW/2, caseTop), end = androidx.compose.ui.geometry.Offset(cx+caseW/2, caseTop+caseH)), topLeft = androidx.compose.ui.geometry.Offset(cx-caseW/2, caseTop), size = androidx.compose.ui.geometry.Size(caseW, caseH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(caseH*.32f))
                    drawRoundRect(Color.White.copy(.8f), topLeft = androidx.compose.ui.geometry.Offset(cx-caseW*.46f, caseTop+caseH*.10f), size = androidx.compose.ui.geometry.Size(caseW*.92f, caseH*.12f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(caseH*.08f))
                    drawCircle(Color(0xFF6C86B4), radius = 2.5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(cx, caseTop+caseH*.73f))
                    // Floating earbud silhouettes.
                    listOf(-1f, 1f).forEachIndexed { index, side ->
                        val ex = cx + side * maxR * .54f
                        val ey = cy - maxR * .30f + if (index == 0) -2.dp.toPx() else 3.dp.toPx()
                        drawOval(Brush.linearGradient(listOf(Color.White, Color(0xFFB7C7E5), Color(0xFF7889AC))), topLeft = androidx.compose.ui.geometry.Offset(ex-10.dp.toPx(), ey-17.dp.toPx()), size = androidx.compose.ui.geometry.Size(20.dp.toPx(), 35.dp.toPx()))
                        drawRoundRect(Color(0xFFDCE7FA), topLeft = androidx.compose.ui.geometry.Offset(ex-4.dp.toPx(), ey+7.dp.toPx()), size = androidx.compose.ui.geometry.Size(8.dp.toPx(), 22.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                        drawCircle(Color(0xFF52688F), radius = 2.dp.toPx(), center = androidx.compose.ui.geometry.Offset(ex, ey-10.dp.toPx()))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PremiumBattery("LEFT", b.battery.getOrElse(0) { -1 }, b.charging.getOrElse(0) { false }, Modifier.weight(1f))
                PremiumBattery("RIGHT", b.battery.getOrElse(1) { -1 }, b.charging.getOrElse(1) { false }, Modifier.weight(1f))
                if (connected && b.battery.getOrElse(2) { -1 } >= 0) {
                    PremiumBattery("CASE", b.battery[2], b.charging.getOrElse(2) { false }, Modifier.weight(1f))
                }
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Quick controls", color = GlassInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Your listening, one touch away", color = GlassMuted, fontSize = 12.sp)
            }
            Text("CONTROL CENTER", color = GlassBlue, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickGlassControl("Noise cancel", "Immersive", Icons.Rounded.GraphicEq, b.ancMode == Buds.ANC_ON, Modifier.weight(1f), enabled = connected) { b.setAnc(Buds.ANC_ON) }
                QuickGlassControl("Transparency", "Hear around you", Icons.Rounded.Hearing, b.ancMode == Buds.ANC_TRANSP, Modifier.weight(1f), enabled = connected) { b.setAnc(Buds.ANC_TRANSP) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickGlassControl("Normal mode", "Natural sound", Icons.Rounded.Block, b.ancMode == Buds.ANC_OFF, Modifier.weight(1f), enabled = connected) { b.setAnc(Buds.ANC_OFF) }
                QuickGlassControl("Sound studio", "Equalizer", Icons.Rounded.Tune, false, Modifier.weight(1f), enabled = true) { x.go(1) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickGlassControl("Find My Buds", "Locate with earbud tone", Icons.Rounded.Headphones, false, Modifier.weight(1f), enabled = connected) { x.go(3) }
                QuickGlassControl("Touch gestures", "Customize taps", Icons.Rounded.Tune, false, Modifier.weight(1f), enabled = true) { x.go(3) }
            }
        }
        // Unified connection control at the end of Home.
        GlassActionButton(if (connected) "Disconnect earbuds" else if (b.connecting || b.searching) "Connecting…" else "Connect earbuds",
            if (connected) Icons.Rounded.Block else Icons.Rounded.Bluetooth, Modifier.fillMaxWidth()) {
            if (!x.perm) x.askPerm()
            else if (connected) {
                val address = b.deviceAddr
                if (address.isNotBlank()) AudioProfileDisconnect.request(context, address) { result -> x.toast(result) }
                b.disconnect()
                x.toast("Budsy control link disconnected. Android may keep media audio connected.")
            } else {
                val adapter = try { context.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter } catch (_: Exception) { null }
                val paired = try { adapter?.bondedDevices?.toList().orEmpty() } catch (_: Exception) { emptyList() }
                val last = x.prefs.lastAddr
                val target = paired.firstOrNull { it.address == last }
                    ?: paired.firstOrNull { (it.name ?: "").contains("Nord Buds", true) }
                    ?: paired.firstOrNull { (it.name ?: "").contains("Buds", true) }
                if (target != null) { b.resumeAutoConnect(); b.connect(target) }
                else { b.resumeAutoConnect(); x.openDevicePicker() }
            }
        }

    }
}

@Composable
private fun PremiumBattery(label: String, level: Int, charging: Boolean, modifier: Modifier = Modifier) {
    val safe = level.coerceIn(0, 100)
    val animated by animateFloatAsState(if (level in 0..100) safe / 100f else 0f, animationSpec = tween(650), label = "batteryFill")
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Color.White.copy(.07f))
        .border(1.dp, Color.White.copy(.11f), RoundedCornerShape(18.dp)).padding(12.dp)) {
        Text(label, color = GlassMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        Text(if (level in 0..100) "$level%" else "—", color = GlassInk, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(9.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color.White.copy(.12f))) {
            Box(Modifier.fillMaxWidth(animated).fillMaxHeight().clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFF78E4C0), GlassBlue))))
        }
        if (charging) Text("Charging", color = Color(0xFF8DE8C5), fontSize = 9.sp)
    }
}

@Composable
private fun QuickGlassControl(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1.025f else 1f, animationSpec = spring(dampingRatio = .7f, stiffness = 300f), label = "quickControlScale")
    Row(modifier.scale(scale).clip(RoundedCornerShape(22.dp))
        .background(if (selected) Brush.linearGradient(listOf(Color(0xFF355B91).copy(.85f), Color(0xFF29264D).copy(.92f))) else Brush.linearGradient(listOf(Color.White.copy(.09f), Color.White.copy(.035f))))
        .border(1.dp, if (selected) GlassBlue.copy(.55f) else Color.White.copy(.10f), RoundedCornerShape(22.dp))
        .clickable(enabled = enabled, onClick = onClick).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(GlassBlue.copy(if (selected) .30f else .15f), GlassViolet.copy(.16f)))), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = title, tint = if (enabled) GlassBlue else GlassMuted.copy(.5f), modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) GlassInk else GlassMuted.copy(.55f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (!enabled) "Connect first" else subtitle, color = GlassMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun GlassIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    val pressedScale by animateFloatAsState(1f, animationSpec = spring(), label = "iconButton")
    Box(Modifier.size(46.dp).scale(pressedScale).clip(CircleShape)
        .background(Color.White.copy(.08f)).border(1.dp, Color.White.copy(.16f), CircleShape)
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = description, tint = GlassInk, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun GlassActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF497BC5), Color(0xFF6653BA))))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(9.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
