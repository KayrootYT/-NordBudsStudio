package com.nordbuds.studio

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen(); super.onCreate(savedInstanceState); Buds.attach(this); enableEdgeToEdge()
        setContent { Root() }
    }
}

@Composable
fun Root() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = Buds.prefs
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var themeMode by rememberSaveable { mutableIntStateOf(prefs.themeMode) }
    var accent by rememberSaveable { mutableIntStateOf(prefs.accent) }
    var amoled by rememberSaveable { mutableStateOf(prefs.amoled) }
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) { 1 -> true; 2 -> false; else -> systemDark }
    var perm by remember { mutableStateOf(Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) }
    var notifPerm by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val askBt = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifPerm = it }
    var showPermRationale by remember { mutableStateOf(false) }
    var showWelcome by remember { mutableStateOf(!prefs.welcomed) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Buds.msg) { val m = Buds.msg ?: return@LaunchedEffect; snack.currentSnackbarData?.dismiss(); snack.showSnackbar(Buds.str(m.res, *m.args.toTypedArray()), duration = SnackbarDuration.Short) }
    val toast: (String) -> Unit = { m -> scope.launch { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(m) } }
    val link = remember { AudioLink(ctx.applicationContext) }
    DisposableEffect(Unit) { onDispose { link.stop() } }
    LaunchedEffect(perm) { if (perm) { link.start(); while (isActive) { link.refresh(); delay(3000) } } }
    LaunchedEffect(perm) { if (!perm) showPermRationale = true }
    LaunchedEffect(perm, Buds.autoPaused) {
        if (!perm || Buds.autoPaused) { Buds.searching = false; return@LaunchedEffect }
        var fails = 0
        while (isActive) {
            val btEnabled = try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true } catch (_: Exception) { false }
            Buds.btEnabled = btEnabled
            if (!btEnabled) { Buds.searching = false; fails = 0; delay(2000); continue }
            if (Buds.connected) { Buds.searching = false; fails = 0; delay(2000); continue }
            Buds.searching = true
            if (!Buds.connecting) {
                val audio = link.audioAddrs; val last = prefs.lastAddr; val list = bondedDevices(ctx)
                val d = list.firstOrNull { it.address == last }
                    ?: list.firstOrNull { it.address in audio && (it.name ?: "").contains("buds", true) }
                    ?: list.firstOrNull { (it.name ?: "").contains("nord buds", true) }
                if (d != null) { Buds.connect(d, auto = true); fails++ } else fails = 0
            }
            delay(if (fails > 2) 15000 else 3000)
        }
    }
    NordTheme(dark, accent, amoled) {
        Box(Modifier.fillMaxSize()) {
            AuroraBackground()
            Scaffold(containerColor = androidx.compose.ui.graphics.Color.Transparent, snackbarHost = { SnackbarHost(snack, Modifier.padding(bottom = 96.dp)) }, topBar = { TopBar(dark) }) { pad ->
                val c = Ctx(b = Buds, prefs = prefs, perm = perm, askPerm = { showPermRationale = true }, toast = toast, go = { tab = it }, dark = dark, accentIdx = accent,
                    setDark = { v -> themeMode = if (v) 1 else 2; prefs.themeMode = themeMode }, setAccent = { accent = it; prefs.accent = it }, audio = link.audioAddrs, audioKnown = link.ready,
                    amoled = amoled, setAmoled = { amoled = it; prefs.amoled = it }, askNotifPerm = { if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }, notifGranted = notifPerm)
                Box(Modifier.padding(pad).fillMaxSize()) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 14 }) togetherWith
                                (fadeOut(tween(180)) + slideOutHorizontally(tween(180)) { -it / 18 })
                        },
                        label = "premiumTabTransition"
                    ) { page ->
                        when (page) {
                            0 -> OverviewScreen(c)
                            1 -> SoundScreen(c)
                            2 -> ControlsScreen(c)
                            else -> SettingsScreen(c)
                        }
                    }
                    val items = listOf(
                        Triple(0, Icons.Rounded.Headphones, stringResource(R.string.tab_device)),
                        Triple(1, Icons.Rounded.GraphicEq, stringResource(R.string.tab_sound)),
                        Triple(2, Icons.Rounded.Tune, stringResource(R.string.tab_controls)),
                        Triple(3, Icons.Rounded.Settings, stringResource(R.string.tab_settings))
                    )
                    Box(Modifier.align(Alignment.BottomCenter)) { BottomNav(items, tab) { tab = it } }
                }
            }
        }
    }
    if (showWelcome) AlertDialog(onDismissRequest = { showWelcome = false; prefs.welcomed = true }, confirmButton = { TextButton(onClick = { showWelcome = false; prefs.welcomed = true }) { Text(stringResource(R.string.got_it)) } }, title = { Text(stringResource(R.string.welcome_title)) }, text = { Column { Text(stringResource(R.string.welcome_body)); Spacer(Modifier.height(10.dp)); Text(stringResource(R.string.welcome_b1)); Text(stringResource(R.string.welcome_b2)); Text(stringResource(R.string.welcome_b3)) } })
    if (showPermRationale && !perm) AlertDialog(onDismissRequest = { showPermRationale = false }, confirmButton = { TextButton(onClick = { showPermRationale = false; if (Build.VERSION.SDK_INT >= 31) askBt.launch(Manifest.permission.BLUETOOTH_CONNECT) }) { Text(stringResource(R.string.perm_grant)) } }, dismissButton = { TextButton(onClick = { showPermRationale = false }) { Text(stringResource(R.string.not_now)) } }, title = { Text(stringResource(R.string.perm_title)) }, text = { Text(stringResource(R.string.perm_body)) })
}

@Composable
private fun TopBar(dark: Boolean) {
    val name = Buds.displayName.ifEmpty { stringResource(R.string.app_name) }
    val ok = Buds.connected
    val dotColor = if (ok) P.green else P.sub.copy(alpha = 0.6f)
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Txt("BUDSY", 11, FontWeight.Medium, P.accent, spacing = 2.4f, maxLines = 1)
            Txt(name.removePrefix("OnePlus ").trim(), 24, FontWeight.SemiBold, P.text, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        Row(
            Modifier.clip(CircleShape).background((if (ok) P.green else P.sub).copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Canvas(Modifier.size(8.dp)) { drawCircle(dotColor) }
            Spacer(Modifier.width(7.dp))
            Txt(if (ok) stringResource(R.string.connected) else Buds.status, 13, FontWeight.Medium, if (ok) P.green else P.sub, Modifier.widthIn(max = 150.dp), maxLines = 1)
        }
    }
}
