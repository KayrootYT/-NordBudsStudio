package com.nordbuds.studio

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val buds = Buds()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { Root(buds) }
    }
}

@Composable
fun Root(b: Buds) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx).also { b.autoPaused = it.autoOff } }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var perm by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val snack = remember { SnackbarHostState() }

    // messages coming from the buds layer (errors, confirmations)
    LaunchedEffect(b.msg) {
        val m = b.msg
        if (m != null) { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(m.second, duration = SnackbarDuration.Short) }
    }
    val toast: (String) -> Unit = { m -> b.say(m) }

    // ask for the Bluetooth permission on first launch
    LaunchedEffect(Unit) { if (!perm) ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    // watch the phone's real audio link to the buds (separate from Budsy's control channel)
    val link = remember { AudioLink(ctx.applicationContext) }
    DisposableEffect(Unit) { onDispose { link.stop() } }
    LaunchedEffect(perm) {
        if (perm) {
            link.start()
            while (true) { link.refresh(); delay(3000) }
        }
    }
    LaunchedEffect(b.autoPaused) { prefs.autoOff = b.autoPaused }
    // Keep looking for the last earbuds and open the control channel whenever they are reachable.
    // Never runs after the user pressed Disconnect (autoPaused) until they connect again by hand.
    LaunchedEffect(perm, b.autoPaused) {
        if (!perm || b.autoPaused) { b.searching = false; return@LaunchedEffect }
        var fails = 0
        var nextTry = 0L
        var lastAudio: Set<String> = emptySet()
        try {
            while (true) {
                if (b.connected) { b.searching = false; fails = 0; nextTry = 0L; delay(2000); continue }
                b.searching = true
                val audio = link.audioAddrs
                if (audio != lastAudio) { lastAudio = audio; fails = 0; nextTry = 0L }
                val now = System.currentTimeMillis()
                if (!b.connecting && now >= nextTry) {
                    val last = prefs.lastAddr
                    val list = bondedDevices(ctx)
                    val d = list.firstOrNull { it.address == last }
                        ?: list.firstOrNull { it.address in audio && (it.name ?: "").contains("buds", ignoreCase = true) }
                        ?: list.firstOrNull { (it.name ?: "").contains("nord buds", ignoreCase = true) }
                    if (d != null) {
                        val up = !link.ready || d.address in audio
                        b.connect(d, auto = true)
                        fails++
                        // quick retries while the phone's audio link is up, a slow scan otherwise
                        nextTry = now + if (up && fails < 6) 4000L else 20000L
                    } else nextTry = now + 20000L
                }
                delay(1000)
            }
        } finally { b.searching = false }
    }
    LaunchedEffect(b.connected) { if (b.connected && b.deviceAddr.isNotEmpty()) prefs.lastAddr = b.deviceAddr }

    var dark by remember { mutableStateOf(prefs.dark) }
    var accentIdx by remember { mutableIntStateOf(prefs.accent) }
    var amoled by remember { mutableStateOf(prefs.amoled) }
    val x = Ctx(
        b, prefs, perm, { ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }, toast, { tab = it },
        dark, accentIdx, { v -> dark = v; prefs.dark = v }, { v -> accentIdx = v; prefs.accent = v },
        link.audioAddrs, link.ready,
        amoled, { v -> amoled = v; prefs.amoled = v }
    )

    NordTheme(dark, accentIdx, amoled) {
        val view = LocalView.current
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
        Box(Modifier.fillMaxSize().background(P.bg)) {
            AuroraBackground()
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopBar(tab, b.connected)
                AnimatedContent(
                    targetState = tab, modifier = Modifier.weight(1f),
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                    label = "page"
                ) { t ->
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 20.dp)
                    ) {
                        when (t) {
                            0 -> OverviewScreen(x)
                            1 -> SoundScreen(x)
                            2 -> ControlsScreen(x)
                            else -> SettingsScreen(x)
                        }
                    }
                }
                NavBar(tab) { tab = it }
            }
            SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 110.dp))
        }
    }
}

@Composable
fun TopBar(tab: Int, connected: Boolean) {
    val title = when (tab) { 0 -> "Budsy"; 1 -> "Sound"; 2 -> "Controls"; else -> "Settings" }
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(P.accent), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Headphones, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            CapsLabel("Nord Buds Studio")
            Txt(title, 24, FontWeight.SemiBold, P.text, maxLines = 1)
        }
        val dot by animateColorAsState(if (connected) P.green else P.amber, label = "dot")
        Row(
            Modifier.clip(CircleShape).background(P.tile).padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(7.dp))
            Txt(if (connected) "Connected" else "Offline", 12, FontWeight.Medium, P.text, maxLines = 1)
        }
    }
}

/** Floating glass tab bar. */
@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val items: List<Pair<ImageVector, String>> = listOf(
        Icons.Rounded.Home to "Overview", Icons.Rounded.GraphicEq to "Sound",
        Icons.Rounded.Tune to "Controls", Icons.Rounded.Settings to "Settings"
    )
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 10.dp, top = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(shape).background(P.card)
                .border(1.dp, Brush.linearGradient(listOf(P.edgeA, P.edgeB)), shape).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEachIndexed { i, item ->
                val sel = tab == i
                val tint by animateColorAsState(if (sel) P.accent else P.sub, label = "nt")
                val bgc by animateColorAsState(if (sel) P.soft else Color.Transparent, label = "nb")
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(bgc)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onTab(i) }
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(item.first, null, tint = tint, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(2.dp))
                    Txt(item.second, 12, if (sel) FontWeight.Medium else FontWeight.Normal, tint, maxLines = 1)
                }
            }
        }
    }
}
