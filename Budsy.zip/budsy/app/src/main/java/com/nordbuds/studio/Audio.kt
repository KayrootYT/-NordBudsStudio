package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

/**
 * Watches the phone's own audio connection (A2DP media + headset calls).
 * The control channel Budsy opens is separate: it can be up while the phone still plays through its speaker.
 */
@SuppressLint("MissingPermission")
class AudioLink(private val ctx: Context) {
    /** Addresses currently connected for media or call audio. */
    var audioAddrs by mutableStateOf<Set<String>>(emptySet())
        private set
    /** True once the system answered, so an empty set really means "no audio connection". */
    var ready by mutableStateOf(false)
        private set

    private val adapter: BluetoothAdapter? =
        try { ctx.getSystemService(BluetoothManager::class.java)?.adapter } catch (e: Exception) { null }
    private var a2dp: BluetoothProfile? = null
    private var hfp: BluetoothProfile? = null
    private var started = false
    private var registered = false

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile == BluetoothProfile.A2DP) a2dp = proxy
            else if (profile == BluetoothProfile.HEADSET) hfp = proxy
            refresh()
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.A2DP) a2dp = null
            else if (profile == BluetoothProfile.HEADSET) hfp = null
            refresh()
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { refresh() }
    }

    fun start() {
        if (started) return
        started = true
        try {
            adapter?.getProfileProxy(ctx, listener, BluetoothProfile.A2DP)
            adapter?.getProfileProxy(ctx, listener, BluetoothProfile.HEADSET)
            val f = IntentFilter()
            f.addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
            f.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
            f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            ContextCompat.registerReceiver(ctx, rx, f, ContextCompat.RECEIVER_EXPORTED)
            registered = true
        } catch (e: Exception) { }
    }

    fun refresh() {
        val s = HashSet<String>()
        var any = false
        try { a2dp?.let { any = true; it.connectedDevices.forEach { d -> s.add(d.address) } } } catch (e: Exception) { }
        try { hfp?.let { any = true; it.connectedDevices.forEach { d -> s.add(d.address) } } } catch (e: Exception) { }
        if (s != audioAddrs) audioAddrs = s
        if (any != ready) ready = any
    }

    fun stop() {
        try { if (registered) ctx.unregisterReceiver(rx) } catch (e: Exception) { }
        registered = false
        try { a2dp?.let { adapter?.closeProfileProxy(BluetoothProfile.A2DP, it) } } catch (e: Exception) { }
        try { hfp?.let { adapter?.closeProfileProxy(BluetoothProfile.HEADSET, it) } } catch (e: Exception) { }
        a2dp = null; hfp = null; started = false
    }
}

/** Best-effort request to disconnect Android's system audio profiles.
 * A2DP/Headset disconnect(BluetoothDevice) is hidden on many Android releases;
 * reflection may be blocked by non-SDK restrictions or OEM policy. We never report
 * success here—the caller must verify ACTION_CONNECTION_STATE_CHANGED afterwards.
 */
@SuppressLint("MissingPermission")
object AudioProfileDisconnect {
    fun request(ctx: Context, address: String, onResult: (String) -> Unit = {}) {
        val adapter = try { ctx.getSystemService(BluetoothManager::class.java)?.adapter } catch (_: Exception) { null }
        if (adapter == null || address.isBlank()) { onResult("Bluetooth adapter/device unavailable"); return }
        val device = try { adapter.getRemoteDevice(address) } catch (_: Exception) { onResult("Invalid Bluetooth device address"); return }
        val pending = java.util.concurrent.atomic.AtomicInteger(2)
        val attempted = java.util.concurrent.atomic.AtomicInteger(0)
        val failed = java.util.concurrent.atomic.AtomicInteger(0)
        fun finishOne() {
            if (pending.decrementAndGet() == 0) {
                onResult(if (attempted.get() > 0 && failed.get() == 0) "Disconnect request sent; waiting for Bluetooth state confirmation" else "Android blocked profile disconnect; control link only was disconnected")
            }
        }
        val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                try {
                    val method = proxy.javaClass.methods.firstOrNull { it.name == "disconnect" && it.parameterTypes.size == 1 && it.parameterTypes[0] == BluetoothDevice::class.java }
                    if (method == null) { failed.incrementAndGet() }
                    else {
                        attempted.incrementAndGet()
                        val result = method.invoke(proxy, device)
                        if (result is Boolean && !result) failed.incrementAndGet()
                    }
                } catch (_: Throwable) { failed.incrementAndGet() }
                finally {
                    try { adapter.closeProfileProxy(profile, proxy) } catch (_: Exception) { }
                    finishOne()
                }
            }
            override fun onServiceDisconnected(profile: Int) { finishOne() }
        }
        try { adapter.getProfileProxy(ctx.applicationContext, listener, BluetoothProfile.A2DP) } catch (_: Exception) { failed.incrementAndGet(); finishOne() }
        try { adapter.getProfileProxy(ctx.applicationContext, listener, BluetoothProfile.HEADSET) } catch (_: Exception) { failed.incrementAndGet(); finishOne() }
    }
}
