package com.nordbuds.studio

import com.nordbuds.studio.buds.Link
import java.util.UUID
import org.junit.Assert.assertEquals
import org.junit.Test

class LinkTest {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")
    private val vendor = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5")
    private val pnp = UUID.fromString("00001200-0000-1000-8000-00805f9b34fb")
    private val a2dp = UUID.fromString("0000110b-0000-1000-8000-00805f9b34fb")

    @Test fun vendorRecordIsTriedFirstThenSpp() {
        assertEquals(listOf(vendor, spp, pnp), Link.orderCandidates(listOf(a2dp, pnp, vendor)))
    }
    @Test fun sppIsAlwaysAFallback() {
        assertEquals(listOf(spp), Link.orderCandidates(listOf(a2dp)))
        assertEquals(listOf(spp), Link.orderCandidates(emptyList()))
    }
    @Test fun duplicatesAreRemoved() {
        assertEquals(listOf(vendor, spp), Link.orderCandidates(listOf(vendor, spp, vendor)))
    }
}
