package com.nordbuds.studio

import com.nordbuds.studio.buds.Link
import com.nordbuds.studio.protocol.Protocol
import java.util.UUID
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class LinkTest {
    @Test fun controlGattUuidsMatchReverseEngineeredReference() {
        assertEquals(UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5"), Link.SERVICE_UUID)
        assertEquals(UUID.fromString("0100079a-d102-11e1-9b23-00025b00a5a5"), Link.WRITE_UUID)
        assertEquals(UUID.fromString("0200079a-d102-11e1-9b23-00025b00a5a5"), Link.NOTIFY_UUID)
        assertEquals(UUID.fromString("0000fe2c-0000-1000-8000-00805f9b34fb"), Link.FE2C_SERVICE_UUID)
    }

    @Test fun customEqSetPayloadUsesHeyMelodyFieldOrderAndLittleEndianFrequency() {
        val profile = Protocol.CustomEqProfile("Bass", true, listOf(60 to -3, 1000 to 4), 7)
        val actual = Protocol.buildCustomEqSetPayload(profile, -10, 10, 0).map { it.toByte() }.toByteArray()
        val expected = byteArrayOf(0, -10, 10, 7, 4, 'B'.code.toByte(), 'a'.code.toByte(), 's'.code.toByte(), 's'.code.toByte(), 2, 60, 0, -3, -24, 3, 4)
        assertArrayEquals(expected, actual)
    }
}
