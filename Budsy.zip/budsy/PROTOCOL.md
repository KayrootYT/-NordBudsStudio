# Protocol notes

```kotlin
/**
 * Reverse-engineered OPPO/OnePlus earbud control protocol.
 *
 * Frame: AA | length16 LE (= 7 + payload length) | reserved | command-low |
 * command-group | sequence | payload-length16 LE | payload bytes.
 * Group 0x01 is query, 0x02 is unsolicited push, and 0x04 is set. Replies
 * set bit 7 of the group byte (for example 0x0106 -> group 0x81).
 *
 * Commands observed in this implementation: 0x0105 firmware, 0x0106 battery,
 * 0x0108 gesture table, 0x0109 wear state, 0x010C noise/hold modes,
 * 0x010D feature flags, 0x010F EQ preset, 0x0112 peers, 0x0122 custom EQ,
 * 0x0124 BassWave; writes 0x0401 gesture, 0x0403 flag, 0x0404 ANC/hold,
 * 0x0406 preset, 0x041B BassWave, 0x0422 custom EQ.
 *
 * Gesture entry: [side, 0x01, gestureId, functionId], side 1=left, 2=right.
 * This protocol is reverse engineered and has not been verified on every firmware.
 */
```

## Hold and Find-device verification status

- Hold write uses `0x0404` with payload `[2, 1, mask]`; app must query `0x010C` submode `2` and compare the returned mask before showing Saved. This path is implemented with timeout/failure UI, but still requires a real Nord Buds 3 firmware capture to confirm the exact payload.
- Find-device start uses command id `0x0000`, SET group, and payload `[count, side IDs...]` as in the existing app. Stop currently sends a zero target count (`[0]`), which is a cautious candidate inferred from the list encoding and is explicitly unverified on Nord Buds 3 firmware `110.110.100`.
- The app's BLE GATT control connection and Android A2DP/HFP audio route are independent. A connected control channel does not prove media audio is routed to the earbuds; the Overview warning reflects that distinction.


## BLE GATT transport

- Control service: `0000079A-D102-11E1-9B23-00025B00A5A5`
- Write characteristic: `0100079A-D102-11E1-9B23-00025B00A5A5` (write without response)
- Telemetry service: `0000FE2C-0000-1000-8000-00805F9B34FB`
- HELLO: `AA 07 00 00 00 01 23 00 00 12`; REGISTER: `AA 0C 00 00 00 85 41 05 00 00 B5 50 A0 69`.
- The Android implementation now uses GATT rather than RFCOMM. BLE service/characteristic UUIDs and handshake bytes are from the reverse-engineered reference; end-to-end packet framing, notification delivery, and command behavior still require hardware verification on E511A.


## BLE GATT transport update (2026-10-20)

The app's control link uses BLE GATT (not RFCOMM): service `0000079A-D102-11E1-9B23-00025B00A5A5`, write characteristic `0100079A-D102-11E1-9B23-00025B00A5A5`, and notify characteristic `0200079A-D102-11E1-9B23-00025B00A5A5`. The implementation subscribes to notify/indicate characteristics on this service and the FE2C service. Known HELLO/REGISTER raw packets and their delays are based on the supplied reverse-engineering reference.

Custom EQ set command `0x0418` uses the supplied inner payload format. The first payload byte (`p3`) is currently set to provisional zero; the caller's actual value and complete outer framing/checksum are not confirmed. Do not treat custom EQ as device-verified until a live read-back succeeds.
