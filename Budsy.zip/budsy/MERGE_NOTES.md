# Budsy merge notes

Target: Vivo T4x phone + OnePlus Nord Buds 3 (non-Pro).

This archive combines the modular Compose UI from the uploaded `Budsy (1).zip` with the newer BLE/GATT transport and parser reset support. GATT command writes are queued to avoid issuing overlapping writes. Existing feature command mappings are retained from the supplied protocol implementation.

Important: this is a complete source project, not a verified working APK. The Gradle build could not be run because the Gradle distribution was not cached and network DNS to services.gradle.org failed. Actual device connection, notification framing, battery, ANC, EQ, touch controls, and Find My Buds must be verified on the target hardware. Do not assume firmware update support; no verified firmware-update protocol has been established.
