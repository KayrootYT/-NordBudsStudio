package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.media.AudioManager
import android.media.AudioDeviceInfo
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.os.Build
import android.content.pm.PackageManager
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<BluetoothDevice> =
    try { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.bondedDevices?.toList() ?: emptyList() }
    catch (e: Exception) { emptyList() }

// ================================================================= DEVICE

@Composable
fun DeviceScreen(x: Ctx) {
    val b = x.b
    Stack {
        // Brand masthead
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(P.soft), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.GraphicEq, null, tint = P.accent, modifier = Modifier.size(29.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Txt("budsy", 25, FontWeight.Bold, P.text)
                Txt("A U D I O   C O M P A N I O N", 10, FontWeight.SemiBold, P.sub)
            }
            Box(Modifier.clip(CircleShape).background(P.card).border(1.dp, P.line, CircleShape).padding(horizontal = 12.dp, vertical = 9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (b.connected) P.green else P.amber))
                    Txt(if (b.connected) "CONNECTED" else "READY TO PAIR", 10, FontWeight.Bold, P.sub, spacing = 1f)
                }
            }
        }
        // Large listening setup hero
        Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(28.dp))) {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(P.card, P.soft.copy(alpha = .65f), P.card)))) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Txt("YOUR LISTENING SETUP", 11, FontWeight.Bold, P.sub, spacing = 2f)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Txt(if (b.connected) b.deviceName else "OnePlus Nord Buds 3", 24, FontWeight.Bold, P.text, lineHeight = 28)
                            Spacer(Modifier.height(5.dp))
                            Txt(if (b.connected) "Bluetooth control connected" else "Your sound. Your space.", 13, color = P.sub)
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(if (b.connected) P.green else P.amber))
                                Txt(if (b.connected) "Connected to earbuds" else "Not connected yet", 13, FontWeight.SemiBold, if (b.connected) P.green else P.sub)
                            }
                        }
                        Box(Modifier.size(94.dp).clip(CircleShape).background(P.soft.copy(alpha = .7f)), contentAlignment = Alignment.Center) {
                            BudArt(false, 72.dp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    if (b.connected) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SmallButton("↻  Refresh", false) { b.refreshAll(); x.refreshDevices() }
                            SmallButton("Disconnect", false) { b.disconnect() }
                        }
                    } else {
                        WideButton("Find & connect earbuds") { x.go(3); x.refreshDevices() }
                    }
                }
            }
        }
        if (b.connected) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                BatteryTile(b.battery[0], b.charging[0], "Left", Modifier.weight(1f))
                BatteryTile(b.battery[1], b.charging[1], "Right", Modifier.weight(1f))
                BatteryTile(b.battery[2], b.charging[2], "Case", Modifier.weight(1f))
            }
            Txt("BATTERY STATUS", 12, FontWeight.Bold, P.sub, Modifier.padding(start = 3.dp), spacing = 1.8f)
            Txt("Battery values are shown only when reported by the device.", 12, color = P.sub, modifier = Modifier.padding(start = 3.dp))
            Txt("NOISE CONTROL", 12, FontWeight.Bold, P.sub, Modifier.padding(start = 3.dp), spacing = 1.8f)
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                Column(Modifier.padding(13.dp)) {
                    val items = listOf(Icons.Rounded.Waves to "ANC", Icons.Rounded.Block to "Off", Icons.Rounded.Hearing to "Transparency")
                    val ids = listOf(Buds.ANC_ON, Buds.ANC_OFF, Buds.ANC_TRANSP)
                    Segmented(items, ids.indexOf(b.ancMode)) { i -> b.setAnc(ids[i]) }
                    Spacer(Modifier.height(9.dp))
                    Txt("Modes depend on the controls exposed by your earbud firmware.", 12, color = P.sub, lineHeight = 17)
                }
            }
            Txt("SOUND & PERFORMANCE", 12, FontWeight.Bold, P.sub, Modifier.padding(start = 3.dp), spacing = 1.8f)
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                ValueRow("Sound studio", "EQ presets · BassWave", chevron = true) { x.go(1) }
                ValueRow("Touch controls", "Customize gestures", chevron = true, divider = false) { x.go(2) }
            }
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                SwitchRow("Game mode", "Lower audio latency when supported", b.gameMode == true, divider = false) { b.setGame(it) }
            }
            Txt("FIND NEARBY", 12, FontWeight.Bold, P.sub, Modifier.padding(start = 3.dp), spacing = 1.8f)
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                Row(Modifier.fillMaxWidth().clickable { x.go(3) }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(P.soft), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.LocationSearching, null, tint = P.accent, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt("Find my earbuds", 16, FontWeight.SemiBold, P.text)
                        Txt("Scan nearby Bluetooth devices", 12, color = P.sub)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = P.sub)
                }
            }
        } else {
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                Column(Modifier.padding(16.dp)) {
                    Txt("CONNECT YOUR EARBUDS", 12, FontWeight.Bold, P.sub, spacing = 1.5f)
                    Spacer(Modifier.height(8.dp))
                    ConnectBlock(x)
                }
            }
            AudioRouteCard()
            Panel(Modifier.border(1.dp, P.line, RoundedCornerShape(25.dp))) {
                Row(Modifier.fillMaxWidth().clickable { x.go(3) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.BluetoothSearching, null, tint = P.accent, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt("Find nearby", 16, FontWeight.SemiBold, P.text)
                        Txt("Discover available Bluetooth devices", 12, color = P.sub)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = P.sub)
                }
            }
        }
        Txt("BUILT FOR YOUR EVERYDAY LISTENING", 10, FontWeight.SemiBold, P.sub, Modifier.fillMaxWidth().padding(vertical = 8.dp), align = TextAlign.Center, spacing = 1.4f)
    }
}

@Composable
fun SoundScreen(x: Ctx) {
    val b = x.b
    Stack {
        Column(Modifier.padding(top = 4.dp)) {
            Txt("AUDIO & SOUND", 12, FontWeight.SemiBold, P.accent)
            Txt("Sound studio", 27, FontWeight.SemiBold, P.text)
            Txt("Shape your sound with EQ presets and BassWave. Real changes depend on the connected earbud firmware.", 14, lineHeight = 20)
        }
        SectionLabel("EQ presets")
        Panel {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Buds.PRESETS.forEachIndexed { i, p ->
                    ValueRow(p.second, p.third, chevron = false, divider = i < Buds.PRESETS.lastIndex) { if (b.connected) b.setEq(p.first) else x.toast("Connect your earbuds first") }
                }
            }
        }
        SectionLabel("BassWave 2.0")
        Panel {
            SwitchRow("Bass adjustment", "Adjust low-frequency response", b.bassOn == true, divider = false) { b.setBassOn(it) }
            val lv = b.bassLevel
            if (lv != null) {
                var drag by remember { mutableStateOf<Float?>(null) }
                Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Txt("Bass level", 15, color = P.text, modifier = Modifier.weight(1f))
                        Txt("${(drag ?: lv.toFloat()).roundToInt()}", 15, FontWeight.SemiBold, P.accent)
                    }
                    Slider(value = drag ?: lv.toFloat(), onValueChange = { drag = it }, onValueChangeFinished = { drag?.let { b.setBassLevel(it.roundToInt()) }; drag = null }, valueRange = b.bassMin.toFloat()..b.bassMax.toFloat(), enabled = b.connected && b.bassOn == true, colors = SliderDefaults.colors(thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.soft))
                }
            } else Txt("Connect to check whether this firmware exposes BassWave control.", 13, color = P.sub, modifier = Modifier.padding(16.dp))
        }
        SectionLabel("Gaming")
        Panel { SwitchRow("Game mode", "Lower audio latency when supported", b.gameMode == true, divider = false) { b.setGame(it) } }
        SectionLabel("Hardware specifications")
        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ValueRow("Model", "OnePlus Nord Buds 3", chevron = false)
                ValueRow("Driver", "12.4 mm dynamic driver", chevron = false)
                ValueRow("Bluetooth audio", "AAC / SBC (phone and firmware dependent)", chevron = false, divider = false)
                Txt("EQ, BassWave and game mode require compatible earbud firmware. A screen toggle alone does not guarantee hardware support.", 12, color = P.sub, lineHeight = 17)
            }
        }
    }
}

@Composable
fun SettingsScreen(x: Ctx) {
    val ctx = LocalContext.current
    Stack {
        Column(Modifier.padding(top = 4.dp)) {
            Txt("CONNECTIVITY & DEVICE", 12, FontWeight.SemiBold, P.accent)
            Txt("Settings", 27, FontWeight.SemiBold, P.text)
            Txt("Bluetooth connection, Find My Buds and device diagnostics.", 14, lineHeight = 20)
        }
        SectionLabel("Connections & device")
        Panel {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt(if (x.b.connected) "Connected: ${x.b.deviceName}" else "Not connected", 16, FontWeight.SemiBold, P.text)
                Txt(if (x.b.connected) x.b.deviceAddr else "Pair OnePlus Nord Buds 3 in Android Bluetooth settings first.", 13, color = P.sub)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("Connect / refresh") {
                        x.refreshDevices()
                        if (!x.b.connected) x.go(0) else x.b.refreshAll()
                    }
                    SmallButton("Bluetooth settings", false) { try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
                }
            }
        }
        FindBudsCard()
        AboutScreen(x)
    }
}

@Composable
fun ConnectBlock(x: Ctx) {
    val ctx = LocalContext.current
    val b = x.b
    if (!x.perm) {
        Txt("Bluetooth permission is needed to find your paired earbuds.", 15, lineHeight = 21)
        Spacer(Modifier.height(14.dp))
        WideButton("Allow Bluetooth") { x.askPerm() }
        return
    }
    val list = remember(b.connected, x.perm, b.connecting, x.deviceRefresh) { bondedDevices(ctx) }
    val adapter = remember { ctx.getSystemService(BluetoothManager::class.java)?.adapter }
    val nearby = remember { mutableStateListOf<BluetoothDevice>() }
    var scanning by remember { mutableStateOf(false) }
    var scanMessage by remember { mutableStateOf("Scan to discover nearby earbuds. Unpaired devices must be paired in Android settings first.") }
    var activeScanner by remember { mutableStateOf<android.bluetooth.le.BluetoothLeScanner?>(null) }
    var activeCallback by remember { mutableStateOf<ScanCallback?>(null) }
    val scanPermissions = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    fun stopNearbyScan() {
        try { if (activeScanner != null && activeCallback != null) activeCallback?.let { activeScanner?.stopScan(it) } } catch (_: Exception) { }
        activeScanner = null; activeCallback = null; scanning = false
    }
    fun startNearbyScan() {
        if (adapter == null || !adapter.isEnabled) { scanMessage = "Turn on Bluetooth before scanning."; return }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) { scanMessage = "BLE scanning is unavailable on this phone."; return }
        nearby.clear()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                val name = try { d.name ?: result.scanRecord?.deviceName } catch (_: Exception) { null }
                if (name.isNullOrBlank()) return
                if (name.contains("Nord", true) || name.contains("OnePlus", true) || name.contains("OPPO", true) || name.contains("HeyMelody", true)) {
                    if (nearby.none { it.address == d.address }) nearby.add(d)
                }
            }
            override fun onScanFailed(errorCode: Int) { scanning = false; scanMessage = "Scan failed (code $errorCode). Check Bluetooth permissions and retry." }
        }
        try {
            scanner.startScan(cb)
            activeScanner = scanner; activeCallback = cb; scanning = true
            scanMessage = "Scanning nearby Bluetooth devices…"
        } catch (_: SecurityException) { scanMessage = "Allow Nearby devices permission to scan." }
        catch (e: Exception) { scanMessage = "Could not start scan (${e.javaClass.simpleName})." }
    }
    val scanPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) startNearbyScan() else scanMessage = "Bluetooth scan permission was denied."
    }
    LaunchedEffect(scanning) {
        if (scanning) { delay(12_000); if (scanning) { stopNearbyScan(); scanMessage = "Scan finished. Put the earbuds outside the case and try again if not listed." } }
    }
    DisposableEffect(Unit) { onDispose { stopNearbyScan() } }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Txt("Scan nearby earbuds or connect to a device already paired with Android. Close HeyMelody before connecting.", 14, lineHeight = 20)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            SmallButton(if (scanning) "Stop scan" else "Scan nearby", filled = true) {
                if (scanning) stopNearbyScan() else {
                    if (scanPermissions.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startNearbyScan()
                    else scanPermissionLauncher.launch(scanPermissions)
                }
            }
            SmallButton("Refresh paired", filled = false) { x.refreshDevices() }
        }
        Txt(scanMessage, 12, color = P.sub, lineHeight = 17)
        if (nearby.isNotEmpty()) {
            Txt("Nearby devices", 15, FontWeight.SemiBold, P.text)
            nearby.take(8).forEach { d ->
                val isPaired = list.any { it.address == d.address }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.tile).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.BluetoothSearching, null, tint = P.accent, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Txt(try { d.name ?: "Bluetooth device" } catch (_: Exception) { "Bluetooth device" }, 14, FontWeight.Medium, P.text, maxLines = 1)
                        Txt(if (isPaired) "Paired · ready to connect" else "Nearby · pairing required", 12, color = P.sub)
                    }
                    SmallButton(if (isPaired) "Connect" else "Pair") {
                        stopNearbyScan()
                        if (isPaired) { if (!b.connecting && !b.connected) b.connect(d) }
                        else try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { scanMessage = "Open Android Bluetooth settings to pair this device." }
                    }
                }
            }
        }
        if (list.isEmpty()) Txt("No paired devices found yet.", 14, FontWeight.Medium, P.text)
        list.forEach { d ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(P.tile).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Headphones, null, tint = P.accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Txt(try { d.name ?: d.address } catch (_: Exception) { d.address }, 16, FontWeight.Medium, P.text, maxLines = 1)
                    Txt("Paired with this phone", 13, color = P.sub)
                }
                SmallButton(if (b.connecting) "Connecting…" else "Connect") { if (!b.connecting && !b.connected) b.connect(d) }
            }
        }
        Row(Modifier.clip(CircleShape).clickable {
            try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
            Txt("Open Bluetooth settings", 14, FontWeight.SemiBold, P.accent)
        }
    }
}



@Composable
private fun AudioRouteCard() {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var route by remember { mutableStateOf(readAudioRoute(audio)) }
    SectionLabel("Music output")
    Panel {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, null, tint = P.accent, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Txt(route.first, 17, FontWeight.SemiBold, P.text)
                    Txt(route.second, 13, color = P.sub, lineHeight = 17)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("Check output") { route = readAudioRoute(audio) }
                SmallButton("Audio settings", false) {
                    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                }
            }
        }
    }
}

private fun readAudioRoute(audio: AudioManager): Pair<String, String> {
    val outputs = try { audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList() } catch (_: Exception) { emptyList() }
    val bt = outputs.filter { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET) }
    return if (bt.isNotEmpty()) {
        val name = bt.firstNotNullOfOrNull { it.productName?.toString()?.takeIf(String::isNotBlank) } ?: "Bluetooth headset"
        name to "Android lists a Bluetooth audio device. This does not guarantee media is routed to it; verify the output in Quick Settings."
    } else "Phone speaker / no Bluetooth audio route" to "The app control connection does not route music. Open Bluetooth settings and select Nord Buds 3 as the media output, then check again."
}

@SuppressLint("MissingPermission")
@Composable
private fun FindBudsCard() {
    val ctx = LocalContext.current
    val adapter = remember { ctx.getSystemService(BluetoothManager::class.java)?.adapter }
    var scanning by remember { mutableStateOf(false) }
    var resultName by remember { mutableStateOf<String?>(null) }
    var rssi by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("Scan nearby Bluetooth advertisements to help locate your buds.") }
    var scanner by remember { mutableStateOf<android.bluetooth.le.BluetoothLeScanner?>(null) }
    var callback by remember { mutableStateOf<ScanCallback?>(null) }
    val scanPerms = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) startFindScan(
            adapter,
            { sc, cb -> scanner = sc; callback = cb },
            { name, strength -> resultName = name; rssi = strength; message = "Signal found. Move slowly and watch the signal strength." },
            { active, detail -> scanning = active; if (detail != null) message = detail }
        )
        else message = "Bluetooth scan permission is required to search nearby."
    }
    LaunchedEffect(scanning) {
        if (scanning) {
            delay(15_000)
            if (scanning) {
                try { if (scanner != null && callback != null) callback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
                scanning = false
                message = "Scan timed out. Keep the buds out of the case and nearby, then try again."
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose { try { if (scanner != null && callback != null) callback?.let { scanner?.stopScan(it) } } catch (_: Exception) {} }
    }
    SectionLabel("Find My Buds")
    Panel {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.LocationSearching, null, tint = P.accent, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Txt("Find nearby earbuds", 18, FontWeight.SemiBold, P.text)
                    Txt(resultName ?: "OnePlus Nord Buds 3", 14, color = P.sub)
                }
                if (scanning) Txt("Scanning", 13, FontWeight.SemiBold, P.accent)
            }
            if (resultName != null) {
                Txt("Signal strength: $rssi dBm", 16, FontWeight.SemiBold, P.text)
                val level = ((rssi + 100).coerceIn(0, 60) / 60f)
                Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(P.soft)) {
                    Box(Modifier.fillMaxWidth(level).height(7.dp).clip(CircleShape).background(P.accent))
                }
            }
            Txt(message, 13, color = P.sub, lineHeight = 18)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton(if (scanning) "Stop scan" else "Find nearby") {
                    if (scanning) {
                        try { if (scanner != null && callback != null) callback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
                        scanning = false; message = "Scan stopped."
                    } else {
                        resultName = null
                        rssi = 0
                        val granted = scanPerms.all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
                        if (granted) startFindScan(
                            adapter,
                            { sc, cb -> scanner = sc; callback = cb },
                            { name, strength -> resultName = name; rssi = strength; message = "Signal found. Move slowly and watch the signal strength." },
                            { active, detail -> scanning = active; if (detail != null) message = detail }
                        )
                        else permissionLauncher.launch(scanPerms)
                    }
                }
                SmallButton("Earbud settings", false) {
                    try { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { message = "Open phone Bluetooth settings to find the earbud options." }
                }
            }
            Txt("Important: this scans nearby Bluetooth signals; it cannot make the earbuds beep unless the firmware exposes a supported command. Use the official OnePlus/HeyMelody Find My Earbuds option for sound playback when available.", 12, color = P.sub, lineHeight = 17)
        }
    }
}

@SuppressLint("MissingPermission")
private fun startFindScan(
    adapter: android.bluetooth.BluetoothAdapter?,
    save: (android.bluetooth.le.BluetoothLeScanner, ScanCallback) -> Unit,
    found: (String, Int) -> Unit,
    state: (Boolean, String?) -> Unit
) {
    if (adapter == null || !adapter.isEnabled) {
        state(false, "Turn on Bluetooth to scan for nearby earbuds.")
        return
    }
    val sc = adapter.bluetoothLeScanner
    if (sc == null) {
        state(false, "Bluetooth LE scanning is unavailable on this device.")
        return
    }
    val cb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = try { result.device.name ?: result.scanRecord?.deviceName } catch (_: Exception) { null }
            if (name?.contains("Nord Buds 3", ignoreCase = true) == true || name?.contains("OnePlus Buds", ignoreCase = true) == true) found(name, result.rssi)
        }
        override fun onScanFailed(errorCode: Int) {
            state(false, "Bluetooth scan failed (code $errorCode). Check Bluetooth and scan permission, then try again.")
        }
    }
    try {
        sc.startScan(cb)
        save(sc, cb)
        state(true, "Scanning nearby Bluetooth advertisements…")
    } catch (e: SecurityException) {
        state(false, "Bluetooth scan permission was denied. Allow Nearby devices and try again.")
    } catch (e: Exception) {
        state(false, "Could not start Bluetooth scan (${e.javaClass.simpleName}).")
    }
}

// ================================================================= EARBUD CONTROLS

private class Opt(val fn: Int, val label: String)

private val NONE = Opt(Buds.F_NONE, "None")
private val PLAY = Opt(Buds.F_PLAY, "Play/Pause")
private val PREV = Opt(Buds.F_PREV, "Previous")
private val NEXT = Opt(Buds.F_NEXT, "Next track")
private val VOICE = Opt(Buds.F_VOICE, "Voice Assistant")
private val GAME = Opt(Buds.F_GAME, "Game mode")

private val SINGLE_OPTS = listOf(NONE, PLAY)
private val DOUBLE_OPTS = listOf(NONE, PLAY, PREV, NEXT, VOICE, GAME)
private val TRIPLE_OPTS = listOf(NONE, PREV, NEXT, VOICE, GAME)
private val LONG_OPTS = listOf(NONE, Opt(Buds.F_VOL_UP, "Volume up"), Opt(Buds.F_VOL_DN, "Volume down"))

private fun optsFor(gid: Int) = when (gid) {
    Buds.G_SINGLE -> SINGLE_OPTS
    Buds.G_DOUBLE -> DOUBLE_OPTS
    Buds.G_TRIPLE -> TRIPLE_OPTS
    else -> LONG_OPTS
}

private fun fnLabel(gid: Int, fn: Int?): String {
    if (fn == null) return "—"
    optsFor(gid).firstOrNull { it.fn == fn }?.let { return it.label }
    return when (fn) {
        0x07 -> "Volume"
        0x0A -> "Switch track"
        Buds.F_ANC -> "Noise control"
        else -> "Action 0x%02X".format(fn)
    }
}

private fun holdLabel(mask: Int): String {
    if (mask <= 0) return "—"
    val n = buildList {
        if ((mask and Buds.M_ANC) != 0) add("Noise cancellation")
        if ((mask and Buds.M_OFF) != 0) add("Off")
        if ((mask and Buds.M_TRANSP) != 0) add("Transparency")
    }
    return n.joinToString(", ")
}

@Composable
fun ControlsScreen(x: Ctx) {
    val b = x.b
    var side by rememberSaveable { mutableIntStateOf(1) }          // 1 left, 2 right
    var dlg by rememberSaveable { mutableIntStateOf(0) }           // gesture id of the open dialog, 0 = none
    var tutorial by remember { mutableStateOf(false) }
    val sideName = if (side == 1) "left" else "right"
    val live = b.connected

    fun open(g: Int) { if (live) dlg = g else x.toast("Connect your earbuds first") }
    fun cur(g: Int): Int? = if (live) b.gest[side * 16 + g] else null

    Stack {
        if (!live) {
            Panel {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Bluetooth, null, tint = P.accent, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Txt("Earbuds not connected", 16, FontWeight.Medium, P.text)
                        Txt("Connect on the Device tab to change controls.", 14)
                    }
                    SmallButton("Device") { x.go(0) }
                }
            }
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            BudArt(side == 2, 190.dp, touchSpot = true)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Chip("Left", side == 1) { side = 1 }
                Chip("Right", side == 2) { side = 2 }
            }
        }

        SectionLabel("When not on a call")
        Panel {
            ValueRow("Single-tap $sideName earbud", fnLabel(Buds.G_SINGLE, cur(Buds.G_SINGLE))) { open(Buds.G_SINGLE) }
            ValueRow("Double-tap $sideName earbud", fnLabel(Buds.G_DOUBLE, cur(Buds.G_DOUBLE))) { open(Buds.G_DOUBLE) }
            ValueRow("Triple-tap $sideName earbud", fnLabel(Buds.G_TRIPLE, cur(Buds.G_TRIPLE))) { open(Buds.G_TRIPLE) }
            ValueRow("Touch and hold", if (live) holdLabel(b.holdMask) else "—") { open(Buds.G_HOLD) }
            ValueRow("Long touch and hold", fnLabel(Buds.G_LONG, cur(Buds.G_LONG)), divider = false) { open(Buds.G_LONG) }
        }

        SectionLabel("When on a call")
        Panel {
            ValueRow("Double-tap $sideName earbud", "Answer/End call", chevron = false)
            ValueRow("Long touch and hold", "Decline call", chevron = false, divider = false)
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P.tile)
                .clickable { tutorial = true }.padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Txt("Learn earbud controls", 15)
            Spacer(Modifier.height(14.dp))
            Txt("View tutorial", 18, FontWeight.Normal, P.text)
        }
    }

    // ---- dialogs
    val g = dlg
    if (g == Buds.G_SINGLE || g == Buds.G_DOUBLE || g == Buds.G_TRIPLE) {
        val title = (when (g) { Buds.G_SINGLE -> "Single-tap"; Buds.G_DOUBLE -> "Double-tap"; else -> "Triple-tap" }) + " $sideName earbud"
        val opts = optsFor(g)
        val now = cur(g)
        SheetDialog({ dlg = 0 }) {
            SheetTitle(title)
            opts.forEach { o ->
                RadioRow(o.label, now == o.fn) { b.setGesture(side, g, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton("Cancel", false) { dlg = 0 }
        }
    }

    if (g == Buds.G_LONG) {
        val now = cur(Buds.G_LONG)
        SheetDialog({ dlg = 0 }) {
            SheetTitle("Long touch and hold")
            Txt(
                "Raise or lower the volume: Press and hold the earbud until you hear 3 beeps. Lift your finger to stop adjusting the volume.",
                16, lineHeight = 23
            )
            Spacer(Modifier.height(14.dp))
            Txt(
                "Switch between Noise control modes: Press and hold the earbud and lift your finger when you hear a beep.",
                16, lineHeight = 23
            )
            Spacer(Modifier.height(8.dp))
            LONG_OPTS.forEachIndexed { i, o ->
                RadioRow(o.label, now == o.fn, divider = i < LONG_OPTS.size - 1) { b.setGesture(side, Buds.G_LONG, o.fn); dlg = 0 }
            }
            Spacer(Modifier.height(10.dp))
            WideButton("Cancel", false) { dlg = 0 }
        }
    }

    if (g == Buds.G_HOLD) {
        var sel by remember { mutableIntStateOf(if (b.holdMask > 0) b.holdMask and 7 else Buds.M_OFF) }
        val n = Integer.bitCount(sel)
        fun flip(bit: Int) { val v = sel xor bit; if (v != 0) sel = v }
        SheetDialog({ dlg = 0 }) {
            SheetTitle("Touch and hold")
            Txt(
                if (n == 1) "1 option selected. Touching and holding will not switch modes."
                else "$n options selected. Touching and holding will switch between these modes.",
                16, lineHeight = 22
            )
            Spacer(Modifier.height(6.dp))
            CheckRow("Noise cancellation", "Significantly reduce external noise.", (sel and Buds.M_ANC) != 0) { flip(Buds.M_ANC) }
            CheckRow("Off", "No noise cancellation effect", (sel and Buds.M_OFF) != 0) { flip(Buds.M_OFF) }
            CheckRow("Transparency", "External noise can be heard.", (sel and Buds.M_TRANSP) != 0) { flip(Buds.M_TRANSP) }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton("Cancel", false) { dlg = 0 } }
                Box(Modifier.weight(1f)) { WideButton("Confirm", true) { b.setHoldMask(sel); dlg = 0 } }
            }
        }
    }

    if (tutorial) {
        SheetDialog({ tutorial = false }) {
            SheetTitle("Earbud controls")
            Txt("Single, double and triple tap: tap the touch area on the stem of the earbud quickly.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("Touch and hold: hold until you hear a beep, then let go to switch noise control mode.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("Long touch and hold: keep holding until you hear 3 beeps, then adjust the volume.", 16, lineHeight = 23)
            Spacer(Modifier.height(10.dp))
            Txt("During a call: double-tap to answer or end it, long hold to decline.", 16, lineHeight = 23)
            Spacer(Modifier.height(18.dp))
            WideButton("Got it", true) { tutorial = false }
        }
    }
}

// ================================================================= ABOUT

@Composable
fun AboutScreen(x: Ctx) {
    val b = x.b
    val clip = LocalClipboardManager.current
    Stack {
        SectionLabel("Earbuds")
        Panel {
            ValueRow("Name", if (b.connected) b.deviceName else "—", chevron = false)
            ValueRow("Bluetooth address", if (b.connected) b.deviceAddr else "—", chevron = false)
            ValueRow("Status", if (b.connected) "Connected" else b.status, chevron = false, divider = false)
        }
        if (b.connected) {
            WideButton("Disconnect", false) { b.disconnect() }
        } else {
            Panel { Column(Modifier.padding(20.dp)) { ConnectBlock(x) } }
        }

        SectionLabel("Diagnostics")
        Panel {
            Column(Modifier.padding(20.dp)) {
                Txt("Gesture table reported by the buds", 16, FontWeight.Medium, P.text)
                Spacer(Modifier.height(6.dp))
                val keys = b.gest.keys.sorted()
                if (keys.isEmpty()) Txt("Nothing read yet.", 14)
                keys.forEach { k ->
                    Txt(
                        "${if (k / 16 == 1) "Left" else if (k / 16 == 2) "Right" else "Side ${k / 16}"} · gesture ${k % 16} → 0x%02X".format(b.gest[k] ?: 0),
                        13, FontWeight.Normal, P.sub, Modifier.padding(vertical = 1.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Txt("Protocol log", 16, FontWeight.Medium, P.text, Modifier.weight(1f))
                    SmallButton("Copy", false) { clip.setText(AnnotatedString(b.logText())); x.toast("Log copied") }
                }
                Spacer(Modifier.height(6.dp))
                val ver = b.logVersion
                val lines = remember(ver) { b.logText().lines().takeLast(14) }
                Txt(
                    if (lines.isEmpty() || (lines.size == 1 && lines[0].isEmpty())) "Empty." else lines.joinToString("\n"),
                    11, FontWeight.Normal, P.sub, lineHeight = 15
                )
            }
        }

        Txt(
            "Nord Buds Studio is an unofficial controller for OnePlus Nord Buds 3. It talks to the earbuds over Bluetooth using the same control channel as HeyMelody, " +
                "so close HeyMelody before connecting.",
            13, lineHeight = 19, modifier = Modifier.padding(horizontal = 12.dp)
        )
    }
}
