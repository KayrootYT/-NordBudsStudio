package com.nordbuds.studio.buds

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import com.nordbuds.studio.protocol.Protocol
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/** HeyMelody-style BLE/GATT transport. UUID roles are reverse-engineered candidates and still need device validation. */
@SuppressLint("MissingPermission")
class Link(
    @Suppress("unused") private val scope: CoroutineScope,
    private val onFrame: (Protocol.Frame) -> Unit,
    private val onDropped: (String) -> Unit
) {
    @Volatile private var context: Context? = null
    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var writeChar: BluetoothGattCharacteristic? = null
    @Volatile private var active = false
    @Volatile private var expectedClose = false
    @Volatile private var generation = 0
    private var seq = 0
    private val lock = Any()
    private val writer: ExecutorService = Executors.newSingleThreadExecutor()
    private val parser = Protocol.Parser()
    private var connectResult: CompletableDeferred<BluetoothDevice?>? = null

    fun setContext(ctx: Context) { context = ctx.applicationContext }
    private fun adapter(): BluetoothAdapter? = try { context?.getSystemService(BluetoothManager::class.java)?.adapter } catch (_: Exception) { null }

    suspend fun connect(device: BluetoothDevice): BluetoothDevice? = withContext(Dispatchers.IO) {
        close(expected = true)
        val token = synchronized(lock) { generation++; expectedClose = false; active = false; seq = 0; parser.reset(); generation }
        val result = CompletableDeferred<BluetoothDevice?>()
        synchronized(lock) { connectResult = result }
        try {
            val ctx = context ?: return@withContext null
            val callback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                    if (token != generation) { try { g.close() } catch (_: Exception) {}; return }
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        result.complete(null)
                        dropGatt(g, "GATT connection failed ($status)")
                    } else if (newState == BluetoothProfile.STATE_CONNECTED) {
                        if (!g.discoverServices()) { result.complete(null); dropGatt(g, "Could not discover earbud services") }
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        result.complete(null)
                        val notify = synchronized(lock) { val was = active; active = false; writeChar = null; was && !expectedClose }
                        try { g.close() } catch (_: Exception) {}
                        if (gatt === g) gatt = null
                        if (notify) onDropped("Earbuds disconnected")
                    }
                }

                override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                    if (token != generation) return
                    if (status != BluetoothGatt.GATT_SUCCESS) { result.complete(null); dropGatt(g, "GATT service discovery failed ($status)"); return }
                    val service = g.getService(SERVICE_UUID)
                    val write = service?.getCharacteristic(WRITE_UUID)
                    val notify = service?.getCharacteristic(NOTIFY_UUID)
                    if (service == null || write == null || notify == null) {
                        result.complete(null); dropGatt(g, "HeyMelody control service/characteristics not found"); return
                    }
                    synchronized(lock) { gatt = g; writeChar = write }
                    if (!g.setCharacteristicNotification(notify, true)) {
                        result.complete(null); dropGatt(g, "Could not enable earbud notifications"); return
                    }
                    val cccd = notify.getDescriptor(CCCD_UUID)
                    if (cccd == null) { result.complete(null); dropGatt(g, "Notification descriptor missing"); return }
                    val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    val started = if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(cccd, value) == BluetoothGatt.GATT_SUCCESS else {
                        @Suppress("DEPRECATION") cccd.value = value
                        @Suppress("DEPRECATION") g.writeDescriptor(cccd)
                    }
                    if (!started) { result.complete(null); dropGatt(g, "Could not subscribe to earbud notifications") }
                }

                override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
                    if (token != generation || descriptor.uuid != CCCD_UUID) return
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        synchronized(lock) { active = true }
                        result.complete(device)
                    } else { result.complete(null); dropGatt(g, "Notification subscription failed ($status)") }
                }

                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    if (token == generation && characteristic.uuid == NOTIFY_UUID) {
                        // Frame envelope still needs confirmation against a captured GATT byte dump.
                        parser.feed(value, value.size).forEach { if (token == generation) onFrame(it) }
                    }
                }
                @Suppress("DEPRECATION")
                override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    if (Build.VERSION.SDK_INT < 33) characteristic.value?.let { onCharacteristicChanged(g, characteristic, it) }
                }
            }
            val opened = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE) else device.connectGatt(ctx, false, callback)
            synchronized(lock) { if (token == generation) gatt = opened else try { opened.close() } catch (_: Exception) {} }
            try { withTimeout(CONNECT_TIMEOUT_MS) { result.await() } } catch (_: TimeoutCancellationException) { dropGatt(opened, "Timed out connecting to earbuds"); null }
        } catch (_: Exception) { null }
    }

    private fun dropGatt(g: BluetoothGatt, reason: String) {
        val shouldNotify = synchronized(lock) { val was = active; active = false; if (gatt === g) { gatt = null; writeChar = null }; was && !expectedClose }
        try { g.disconnect() } catch (_: Exception) {}
        try { g.close() } catch (_: Exception) {}
        if (shouldNotify) onDropped(reason)
    }

    fun write(cmd: Int, group: Int, payload: IntArray) {
        val packet = synchronized(lock) {
            if (!active) return
            val bytes = Protocol.buildFrame(cmd, group, seq, payload)
            seq = (seq + 1) and 0xff
            bytes
        }
        val token = generation
        try {
            writer.execute {
                val g = gatt ?: return@execute
                val ch = writeChar ?: return@execute
                if (token != generation || !active) return@execute
                try {
                    val started = if (Build.VERSION.SDK_INT >= 33) {
                        g.writeCharacteristic(ch, packet, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
                    } else {
                        @Suppress("DEPRECATION") ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                        @Suppress("DEPRECATION") ch.value = packet
                        @Suppress("DEPRECATION") g.writeCharacteristic(ch)
                    }
                    if (!started) onDropped("GATT write was rejected")
                } catch (_: Exception) { onDropped("Could not send command to earbuds") }
            }
        } catch (_: Exception) { }
    }

    fun close(expected: Boolean = true) {
        val old: BluetoothGatt?
        synchronized(lock) {
            expectedClose = expected; active = false; generation++; old = gatt; gatt = null; writeChar = null
            connectResult?.complete(null); connectResult = null
        }
        try { old?.disconnect() } catch (_: Exception) {}
        try { old?.close() } catch (_: Exception) {}
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 12000L
        val SERVICE_UUID: UUID = UUID.fromString("0000079a-d102-11e1-9b23-00025b00a5a5")
        val WRITE_UUID: UUID = UUID.fromString("0100079a-d102-11e1-9b23-00025b00a5a5")
        val NOTIFY_UUID: UUID = UUID.fromString("0200079a-d102-11e1-9b23-00025b00a5a5")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
