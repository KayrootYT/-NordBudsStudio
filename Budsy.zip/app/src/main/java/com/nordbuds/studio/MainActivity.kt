package com.nordbuds.studio

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

class MainActivity : ComponentActivity() {
    private lateinit var buds: Buds
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buds = lastCustomNonConfigurationInstance as? Buds ?: Buds()
        enableEdgeToEdge()
        setContent { Root(buds) }
    }

    override fun onRetainCustomNonConfigurationInstance(): Any = buds

    override fun onDestroy() {
        if (isFinishing && !isChangingConfigurations) buds.close()
        super.onDestroy()
    }
}

@Composable
fun Root(b: Buds) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var deviceRefresh by remember { mutableIntStateOf(0) }
    var perm by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 31 || ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                deviceRefresh++
                perm = Build.VERSION.SDK_INT < 31 ||
                    ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perm = it }
    val snack = remember { SnackbarHostState() }

    // messages coming from the buds layer (errors, confirmations)
    LaunchedEffect(b.msg) {
        val m = b.msg
        if (m != null) { snack.currentSnackbarData?.dismiss(); snack.showSnackbar(m.second, duration = SnackbarDuration.Short) }
    }
    val toast: (String) -> Unit = { m -> b.say(m) }

    // ask for the Bluetooth permission on first launch
    LaunchedEffect(Unit) { if (!perm) ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    // reconnect to the last earbuds automatically
    LaunchedEffect(perm) {
        if (perm && !b.connected) {
            val last = prefs.lastAddr
            val d = if (last == null) null else bondedDevices(ctx).firstOrNull { it.address == last }
            if (d != null) b.connect(d)
        }
    }
    LaunchedEffect(b.connected) { if (b.connected && b.deviceAddr.isNotEmpty()) prefs.lastAddr = b.deviceAddr }

    val x = Ctx(
        b, prefs, perm, { ask.launch(Manifest.permission.BLUETOOTH_CONNECT) }, toast,
        { tab = it }, deviceRefresh, { deviceRefresh++ }
    )
    val dark = isSystemInDarkTheme()

    NordTheme(dark) {
        val view = LocalView.current
        SideEffect {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
        Box(Modifier.fillMaxSize().background(P.bg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopBar(tab, b.connected) { tab = 0 }
                AnimatedContent(
                    targetState = tab, modifier = Modifier.weight(1f),
                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(100)) },
                    label = "page"
                ) { t ->
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 24.dp)
                    ) {
                        when (t) {
                            0 -> DeviceScreen(x)
                            1 -> SoundScreen(x)
                            2 -> ControlsScreen(x)
                            else -> SettingsScreen(x)
                        }
                    }
                }
                BottomBar(tab) { tab = it }
            }
            SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 90.dp))
        }
    }
}

@Composable
fun TopBar(tab: Int, connected: Boolean, onBack: () -> Unit) {
    val title = when (tab) { 0 -> "Your audio"; 1 -> "Sound studio"; 2 -> "Controls"; else -> "Find nearby" }
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (tab == 2) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onBack), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = P.text, modifier = Modifier.size(26.dp))
            }
        } else Spacer(Modifier.width(8.dp))
        Txt(title, 26, FontWeight.Medium, P.text, Modifier.weight(1f), maxLines = 1)
        Box(Modifier.size(11.dp).clip(CircleShape).background(if (connected) P.green else P.amber))
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val items: List<Pair<ImageVector, String>> = listOf(
        Icons.Rounded.Headphones to "Device", Icons.Rounded.Tune to "Sound", Icons.Rounded.TouchApp to "Controls", Icons.Rounded.LocationOn to "Find"
    )
    Column(Modifier.fillMaxWidth().background(P.card).navigationBarsPadding()) {
        HorizontalLine()
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            items.forEachIndexed { i, item ->
                val sel = tab == i
                val tint by animateColorAsState(if (sel) P.accent else P.sub, label = "nt")
                val label by animateColorAsState(if (sel) P.text else P.sub, label = "nl")
                Column(
                    Modifier.weight(1f)
                        .selectable(
                            selected = sel, role = Role.Tab,
                            indication = null, interactionSource = remember { MutableInteractionSource() }
                        ) { onTab(i) }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(item.first, null, tint = tint, modifier = Modifier.size(28.dp))
                    Txt(item.second, 13, if (sel) FontWeight.Medium else FontWeight.Normal, label, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun HorizontalLine() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(P.line))
}
