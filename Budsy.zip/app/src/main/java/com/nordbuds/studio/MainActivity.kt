package com.nordbuds.studio

import android.os.Bundle
import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        Buds.attach(applicationContext)
        setContent { BudsyApp() }
    }
}

private val Blue = Color(0xFF83B8FF)
private val Mint = Color(0xFF7CE7D0)
private val DarkBg = Color(0xFF080D18)
private val DarkPanel = Color(0xFF111A2A)
private val LightBg = Color(0xFFF2F5FB)
private val LightPanel = Color(0xFFFFFFFF)

@Composable
private fun BudsyApp() {
    var dark by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var showDevicePicker by remember { mutableStateOf(false) }
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    val context = LocalContext.current
    fun loadPairedDevices() {
        try {
            val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter ?: BluetoothAdapter.getDefaultAdapter()
            pairedDevices = adapter?.bondedDevices?.filter { d ->
                val n = try { d.name.orEmpty() } catch (_: SecurityException) { "" }
                n.contains("Nord Buds", true) || n.contains("OnePlus", true) || d.address == Buds.prefs.lastAddr
            }?.sortedBy { try { it.name ?: it.address } catch (_: SecurityException) { it.address } } ?: emptyList()
            showDevicePicker = true
        } catch (_: SecurityException) { pairedDevices = emptyList(); showDevicePicker = true }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.all { granted -> granted }) loadPairedDevices()
    }
    fun startConnectFlow() {
        if (Build.VERSION.SDK_INT >= 31) {
            val required = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
            val missing = required.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) { permissionLauncher.launch(missing.toTypedArray()); return }
        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)); return
        }
        loadPairedDevices()
    }
    val bg = if (dark) DarkBg else LightBg
    val panel = if (dark) DarkPanel else LightPanel
    val fg = if (dark) Color(0xFFF4F7FF) else Color(0xFF111827)
    val muted = if (dark) Color(0xFF9BAAC3) else Color(0xFF667085)
    val outline = if (dark) Color(0xFF26354C) else Color(0xFFE0E6F0)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=Blue, background=bg, surface=panel, onSurface=fg) else lightColorScheme(primary=Color(0xFF246BCE), background=bg, surface=panel, onSurface=fg)) {
        Surface(Modifier.fillMaxSize(), color=bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal=18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=12.dp,bottom=18.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Color(0xFF4C8DFF),Color(0xFF8D7BFF)))), contentAlignment=Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint=Color.White, modifier=Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("budsy", fontSize=25.sp, fontWeight=FontWeight.ExtraBold, color=fg, letterSpacing=(-1).sp)
                        Text("YOUR AUDIO, IN SYNC", fontSize=9.sp, fontWeight=FontWeight.Bold, color=muted, letterSpacing=1.5.sp)
                    }
                    Surface(shape=CircleShape, color=panel, border=BorderStroke(1.dp,outline)) {
                        IconButton(onClick={dark=!dark}) { Icon(if(dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle appearance", tint=fg) }
                    }
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).border(1.dp,outline,RoundedCornerShape(18.dp)).padding(4.dp)) {
                    listOf("Home","Equalizer","Touch").forEachIndexed { i, label ->
                        val selected=tab==i
                        Surface(onClick={tab=i}, modifier=Modifier.weight(1f), shape=RoundedCornerShape(14.dp), color=if(selected) (if(dark) Color(0xFF263A58) else Color(0xFFE4EEFF)) else Color.Transparent) {
                            Row(Modifier.padding(vertical=11.dp), horizontalArrangement=Arrangement.Center, verticalAlignment=Alignment.CenterVertically) {
                                Icon(when(i){0->Icons.Default.Headphones;1->Icons.Default.GraphicEq;else->Icons.Default.TouchApp},null,Modifier.size(16.dp), tint=if(selected) Blue else muted)
                                Spacer(Modifier.width(6.dp))
                                Text(label,fontSize=12.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Medium,color=if(selected) fg else muted)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                AnimatedContent(targetState=tab, label="main-tab") { page ->
                    when(page) {
                        0 -> HomePage(dark,panel,fg,muted,outline, onConnect = { if (Buds.connected) Buds.disconnect() else startConnectFlow() })
                        1 -> EqualizerPage(panel,fg,muted,outline,dark)
                        else -> TouchPage(panel,fg,muted,outline,dark)
                    }
                }
            }
        }
        if (showDevicePicker) {
            AlertDialog(
                onDismissRequest = { showDevicePicker = false },
                title = { Text("Paired earbuds") },
                text = {
                    if (pairedDevices.isEmpty()) {
                        Text("No paired OnePlus/Nord Buds were found. Pair your earbuds in Android Bluetooth settings first, then return here.")
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            pairedDevices.forEach { device ->
                                val deviceLabel = try { device.name ?: device.address } catch (_: SecurityException) { device.address }
                                TextButton(onClick = {
                                    showDevicePicker = false
                                    try { Buds.connect(device) } catch (_: SecurityException) { }
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.Headphones, null)
                                    Spacer(Modifier.width(10.dp))
                                    Text(deviceLabel, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showDevicePicker = false }) { Text("Close") } },
                dismissButton = { TextButton(onClick = { startConnectFlow() }) { Text("Refresh") } }
            )
        }
    }
}

@Composable
private fun HomePage(dark:Boolean,panel:Color,fg:Color,muted:Color,outline:Color,onConnect:()->Unit) {
    val connected=Buds.connected
    val scanning=Buds.searching || Buds.connecting
    LazyColumn(verticalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(bottom=22.dp)) {
        item {
            Surface(shape=RoundedCornerShape(26.dp), color=panel, border=BorderStroke(1.dp,outline), modifier=Modifier.fillMaxWidth()) {
                Box {
                    Box(Modifier.align(Alignment.TopEnd).size(160.dp).offset(x=30.dp,y=(-35).dp).background(Brush.radialGradient(listOf(Color(0x554F8CFF),Color.Transparent)),CircleShape))
                    Column(Modifier.padding(19.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Surface(shape=RoundedCornerShape(20.dp),color=if(connected) Color(0x2227C99A) else Color(0x223F8BFF)) {
                                Row(Modifier.padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Box(Modifier.size(6.dp).clip(CircleShape).background(if(connected) Mint else Blue))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if(connected) "CONNECTED" else if(scanning) "CONNECTING" else "READY TO CONNECT",fontSize=9.sp,fontWeight=FontWeight.Bold,color=if(connected) Mint else Blue,letterSpacing=1.sp)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Icon(Icons.Default.Bluetooth, null, tint=muted)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if(Buds.displayName.isBlank()) "OnePlus Nord Buds 3" else Buds.displayName, fontSize=20.sp,fontWeight=FontWeight.Bold,color=fg,maxLines=2,overflow=TextOverflow.Ellipsis)
                                Spacer(Modifier.height(5.dp))
                                Text(if(connected) "Your sound is ready." else "Connect to unlock your controls.",fontSize=12.sp,color=muted)
                            }
                            Box(Modifier.size(74.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF243D60),Color(0xFF101B30)))),contentAlignment=Alignment.Center) {
                                Icon(Icons.Default.Headphones,null,tint=Blue,modifier=Modifier.size(42.dp))
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Button(onClick=onConnect, modifier=Modifier.fillMaxWidth().height(48.dp), shape=RoundedCornerShape(15.dp), colors=ButtonDefaults.buttonColors(containerColor=if(connected) Color(0xFF26354C) else Color(0xFF4C86F5),contentColor=Color.White)) {
                            Icon(if(connected) Icons.Default.LinkOff else Icons.Default.BluetoothSearching,null,Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if(connected) "Disconnect" else if(scanning) "Searching for earbuds…" else "Connect earbuds",fontWeight=FontWeight.Bold)
                        }
                        if (Buds.status.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(Buds.status,fontSize=11.sp,color=muted) }
                    }
                }
            }
        }
        item { SectionTitle("Battery level","Live device readings",fg,muted) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                BatteryTile("Left",Buds.battery.getOrElse(0){-1},Buds.charging.getOrElse(0){false},panel,fg,muted,outline,Modifier.weight(1f))
                BatteryTile("Right",Buds.battery.getOrElse(1){-1},Buds.charging.getOrElse(1){false},panel,fg,muted,outline,Modifier.weight(1f))
                BatteryTile("Case",Buds.battery.getOrElse(2){-1},Buds.charging.getOrElse(2){false},panel,fg,muted,outline,Modifier.weight(1f))
            }
        }
        item { SectionTitle("Noise control","Choose your listening mode",fg,muted) }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=panel,border=BorderStroke(1.dp,outline),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if(dark) Color(0xFF0B1220) else Color(0xFFF0F3F8)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        listOf("ANC","Transparency","Off").forEachIndexed { i,s ->
                            val selected=Buds.ancMode==i
                            Surface(onClick={Buds.setAnc(when(i){0 -> Buds.ANC_ON; 1 -> Buds.ANC_TRANSP; else -> Buds.ANC_OFF})},modifier=Modifier.weight(1f),shape=RoundedCornerShape(11.dp),color=if(selected) Color(0xFF386BC2) else Color.Transparent) {
                                Text(s,Modifier.padding(vertical=12.dp),textAlign=androidx.compose.ui.text.style.TextAlign.Center,fontSize=11.sp,fontWeight=FontWeight.SemiBold,color=if(selected) Color.White else muted)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Info,null,tint=muted,modifier=Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if(Buds.connected) "Changes are sent to your earbuds." else "Connect your earbuds to change noise control.",fontSize=10.sp,color=muted)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                QuickAction("Find my buds",Icons.Default.LocationSearching, panel,fg,muted,outline,Modifier.weight(1f)) { Buds.toggleFindBuds() }
                QuickAction("Game mode",Icons.Default.SportsEsports,panel,fg,muted,outline,Modifier.weight(1f)) { Buds.setGame(!(Buds.gameMode ?: false)) }
            }
        }
    }
}

@Composable
private fun BatteryTile(label:String,value:Int,charging:Boolean,panel:Color,fg:Color,muted:Color,outline:Color,modifier:Modifier=Modifier) {
    Surface(modifier=modifier,shape=RoundedCornerShape(20.dp),color=panel,border=BorderStroke(1.dp,outline)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.BatteryChargingFull,null,tint=if(value>=50) Mint else Blue,modifier=Modifier.size(17.dp))
                Spacer(Modifier.width(5.dp))
                Text(label,fontSize=11.sp,fontWeight=FontWeight.SemiBold,color=muted)
            }
            Text(if(value in 0..100) "$value%" else "—",fontSize=21.sp,fontWeight=FontWeight.Bold,color=fg)
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(if(value>=0) Color(0x332C86FF) else if(outline==Color.Transparent) outline else Color(0xFF26354C))) {
                if(value in 0..100) Box(Modifier.fillMaxWidth(value/100f).fillMaxHeight().clip(CircleShape).background(if(value<20) Color(0xFFFF8D80) else Mint))
            }
            Text(if(value !in 0..100) "Not available" else if(charging) "Charging" else "Battery",fontSize=9.sp,color=muted,maxLines=1)
        }
    }
}

@Composable
private fun SectionTitle(title:String,subtitle:String,fg:Color,muted:Color) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title,fontSize=16.sp,fontWeight=FontWeight.Bold,color=fg)
            Text(subtitle,fontSize=11.sp,color=muted)
        }
        Icon(Icons.Default.ChevronRight,null,tint=muted)
    }
}

@Composable
private fun QuickAction(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,panel:Color,fg:Color,muted:Color,outline:Color,modifier:Modifier=Modifier,onClick:()->Unit) {
    Surface(onClick=onClick,modifier=modifier,border=BorderStroke(1.dp,outline),shape=RoundedCornerShape(18.dp),color=panel) {
        Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
            Icon(icon,null,tint=Blue,modifier=Modifier.size(21.dp))
            Spacer(Modifier.width(8.dp))
            Text(title,fontSize=11.sp,fontWeight=FontWeight.SemiBold,color=fg,maxLines=1)
        }
    }
}

@Composable
private fun EqualizerPage(panel:Color,fg:Color,muted:Color,outline:Color,dark:Boolean) {
    var selected by remember { mutableIntStateOf(Buds.eqPreset.coerceAtLeast(0)) }
    val bands=listOf("62 Hz","250 Hz","1 kHz","4 kHz","8 kHz","16 kHz")
    val freqs=listOf(62,250,1000,4000,8000,16000)
    val vals= remember { mutableStateListOf(0f,0f,0f,0f,0f,0f) }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { Column { Text("Shape your sound",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=fg); Text("Find your signature sound.",fontSize=13.sp,color=muted) } }
        item {
            Surface(shape=RoundedCornerShape(25.dp),color=panel,border=BorderStroke(1.dp,outline),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Manual EQ",fontSize=18.sp,fontWeight=FontWeight.Bold,color=fg); Text("5-band sound shaping",fontSize=11.sp,color=muted) }; Icon(Icons.Default.GraphicEq,null,tint=Blue,modifier=Modifier.size(28.dp)) }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        listOf("Balanced","Vocals","Bass").forEachIndexed { i,name ->
                            FilterChip(selected=selected==i,onClick={selected=i;Buds.setEq(listOf(3,4,5)[i])},label={Text(name,fontSize=10.sp)},modifier=Modifier.weight(1f),leadingIcon=if(selected==i) {{Icon(Icons.Default.Check,null,Modifier.size(14.dp))}} else null)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth().height(170.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                        vals.forEachIndexed { i,v ->
                            Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
                                Text(if(v>0) "+${v.toInt()}" else v.toInt().toString(),fontSize=10.sp,color=muted)
                                Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
                                    Box(Modifier.width(2.dp).fillMaxHeight().background(outline))
                                    Slider(value=v, onValueChange={vals[i]=it},valueRange=-6f..6f,modifier=Modifier.fillMaxHeight().width(42.dp).graphicsLayer { rotationZ=0f })
                                }
                                Text(bands[i],fontSize=8.sp,color=muted,maxLines=1)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick={Buds.writeCustomEq("Manual 1", freqs.mapIndexed { i,hz -> hz to vals[i].toInt() })},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Save,null,Modifier.size(16.dp)); Spacer(Modifier.width(7.dp)); Text(if(Buds.connected) "Save to earbuds" else "Save EQ profile")
                    }
                    Text(if(Buds.connected) (Buds.eqSaveMessage.ifBlank { "Ready to apply to your connected device." }) else "Adjust freely; connect earbuds to sync settings.",fontSize=10.sp,color=muted)
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(20.dp),color=panel,border=BorderStroke(1.dp,outline),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Enhancements",fontSize=15.sp,fontWeight=FontWeight.Bold,color=fg)
                    FeatureToggle("Bass boost","Add more low-end impact",Buds.bassOn ?: false,{Buds.setBassOn(it)},fg,muted)
                    FeatureToggle("Low latency","Reduce delay while gaming",Buds.gameMode ?: false,{Buds.setGame(it)},fg,muted)
                }
            }
        }
    }
}

@Composable
private fun FeatureToggle(title:String,sub:String,checked:Boolean,onChange:(Boolean)->Unit,fg:Color,muted:Color) {
    Row(Modifier.fillMaxWidth().padding(top=12.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title,fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=fg); Text(sub,fontSize=10.sp,color=muted) }
        Switch(checked=checked,onCheckedChange=onChange)
    }
}

@Composable
private fun TouchPage(panel:Color,fg:Color,muted:Color,outline:Color,dark:Boolean) {
    val gestures=listOf("Single tap","Double tap","Triple tap","Long press")
    val actions=listOf("Play / Pause","Next track","Previous track","Noise control","Voice assistant","None")
    var left by remember { mutableStateOf(mutableMapOf(0 to "Noise control",1 to "Next track",2 to "Previous track",3 to "Noise control")) }
    var right by remember { mutableStateOf(mutableMapOf(0 to "Play / Pause",1 to "Next track",2 to "Previous track",3 to "Voice assistant")) }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(bottom=24.dp)) {
        item { Column { Text("Touch controls",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=fg); Text("Make every gesture feel natural.",fontSize=13.sp,color=muted) } }
        item {
            Surface(shape=RoundedCornerShape(24.dp),color=panel,border=BorderStroke(1.dp,outline),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Headphones,null,tint=Blue); Spacer(Modifier.width(8.dp)); Text("Left earbud",fontSize=17.sp,fontWeight=FontWeight.Bold,color=fg) }
                    Spacer(Modifier.height(8.dp))
                    gestures.forEachIndexed { i,g -> GestureRow(g,left[i] ?: actions[0],actions,fg,muted,outline) { next -> left=left.toMutableMap().also{it[i]=next}; if(Buds.connected) Buds.setGesture(1,i+1,nextActionCode(next)) } }
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(24.dp),color=panel,border=BorderStroke(1.dp,outline),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Headphones,null,tint=Mint); Spacer(Modifier.width(8.dp)); Text("Right earbud",fontSize=17.sp,fontWeight=FontWeight.Bold,color=fg) }
                    Spacer(Modifier.height(8.dp))
                    gestures.forEachIndexed { i,g -> GestureRow(g,right[i] ?: actions[0],actions,fg,muted,outline) { next -> right=right.toMutableMap().also{it[i]=next}; if(Buds.connected) Buds.setGesture(2,i+1,nextActionCode(next)) } }
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(18.dp),color=if(dark) Color(0xFF13213A) else Color(0xFFE5EEFF),modifier=Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp),verticalAlignment=Alignment.Top) { Icon(Icons.Default.Info,null,tint=Blue); Spacer(Modifier.width(9.dp)); Text(if(Buds.connected) "Gesture changes are sent to the connected earbuds where supported." else "Connect your earbuds before syncing gesture changes.",fontSize=11.sp,color=fg) }
            }
        }
    }
}

private fun nextActionCode(action:String):Int = when(action) {
    "Play / Pause" -> Buds.F_PLAY
    "Next track" -> Buds.F_NEXT
    "Previous track" -> Buds.F_PREV
    "Noise control" -> Buds.F_ANC
    "Voice assistant" -> Buds.F_VOICE
    else -> Buds.F_NONE
}

@Composable
private fun GestureRow(label:String,value:String,options:List<String>,fg:Color,muted:Color,outline:Color,onSelect:(String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label,fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=fg); Text("Gesture assignment",fontSize=9.sp,color=muted) }
        Box {
            Surface(onClick={expanded=true},shape=RoundedCornerShape(12.dp),color=if(outline==Color.Transparent) Color.Transparent else Color(0x181D82FF),border=BorderStroke(1.dp,outline)) {
                Row(Modifier.widthIn(min=130.dp).padding(horizontal=10.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(value,fontSize=10.sp,color=fg,maxLines=1,modifier=Modifier.weight(1f),overflow=TextOverflow.Ellipsis)
                    Icon(Icons.Default.ExpandMore,null,tint=muted,modifier=Modifier.size(17.dp))
                }
            }
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                options.forEach { opt -> DropdownMenuItem(text={Text(opt,fontSize=12.sp)},onClick={onSelect(opt);expanded=false}) }
            }
        }
    }
}
