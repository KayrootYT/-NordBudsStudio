package com.nordbuds.studio

/**
 * Framing helpers for the experimental HeyMelody control channel.
 *
 * These checks validate packet boundaries only; they do not prove that a
 * command or decoded value is supported by a particular earbud firmware.
 */
internal object FrameCodec {
    private const val HEADER_SIZE = 9
    private const val MIN_BODY_LENGTH = 7
    private const val MAX_BODY_LENGTH = 4096

    data class Decoded(val frames: List<ByteArray>, val remainder: ByteArray)

    fun encode(cmd: Int, group: Int, sequence: Int, payload: IntArray): ByteArray {
        val bodyLength = MIN_BODY_LENGTH + payload.size
        require(bodyLength <= MAX_BODY_LENGTH) { "Bluetooth frame is too large" }
        val frame = ByteArray(HEADER_SIZE + payload.size)
        frame[0] = 0xAA.toByte()
        frame[1] = bodyLength.toByte()
        frame[2] = (bodyLength shr 8).toByte()
        frame[3] = 0
        frame[4] = cmd.toByte()
        frame[5] = group.toByte()
        frame[6] = sequence.toByte()
        frame[7] = payload.size.toByte()
        frame[8] = (payload.size shr 8).toByte()
        payload.forEachIndexed { index, value -> frame[HEADER_SIZE + index] = value.toByte() }
        return frame
    }

    fun split(input: ByteArray): Decoded {
        val frames = ArrayList<ByteArray>()
        var pending = input
        while (true) {
            val start = pending.indexOfFirst { it == 0xAA.toByte() }
            if (start < 0) return Decoded(frames, byteArrayOf())
            if (start > 0) pending = pending.copyOfRange(start, pending.size)
            if (pending.size < 3) return Decoded(frames, pending)

            val bodyLength = u8(pending[1]) or (u8(pending[2]) shl 8)
            if (bodyLength !in MIN_BODY_LENGTH..MAX_BODY_LENGTH) {
                pending = pending.copyOfRange(1, pending.size)
                continue
            }
            val frameSize = bodyLength + 2
            if (pending.size < frameSize) return Decoded(frames, pending)

            val candidate = pending.copyOfRange(0, frameSize)
            val payloadLength = u8(candidate[7]) or (u8(candidate[8]) shl 8)
            if (payloadLength + MIN_BODY_LENGTH != bodyLength) {
                pending = pending.copyOfRange(1, pending.size)
                continue
            }
            frames += candidate
            pending = pending.copyOfRange(frameSize, pending.size)
        }
    }

    fun isValid(frame: ByteArray): Boolean {
        if (frame.size < HEADER_SIZE || frame[0] != 0xAA.toByte()) return false
        val bodyLength = u8(frame[1]) or (u8(frame[2]) shl 8)
        val payloadLength = u8(frame[7]) or (u8(frame[8]) shl 8)
        return bodyLength in MIN_BODY_LENGTH..MAX_BODY_LENGTH &&
            bodyLength + 2 == frame.size &&
            payloadLength + HEADER_SIZE == frame.size &&
            payloadLength + MIN_BODY_LENGTH == bodyLength
    }

    private fun u8(value: Byte) = value.toInt() and 0xFF
}
