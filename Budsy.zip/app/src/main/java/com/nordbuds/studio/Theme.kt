package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Five selectable Budsy visual identities. Values are persisted in Prefs. */
object ThemeMode {
    const val LIQUID = 0
    const val NOTHING = 1
    const val AURORA = 2
    const val SONY = 3
    const val SPATIAL = 4
    const val LIGHT = LIQUID
    const val DARK = AURORA
    const val AMOLED = NOTHING
}

@Immutable
class Pal(
    val dark: Boolean,
    val amoled: Boolean,
    val bg: Color,      // page
    val tile: Color,    // segmented track, secondary buttons, input fields
    val thumb: Color,   // selected segment
    val text: Color,
    val sub: Color,
    val line: Color,    // hairline separators
    val track: Color,   // switch off / slider inactive
    val accent: Color,
    val green: Color,
    val amber: Color,
    val red: Color,
    val sheet: Color,
    val accent2: Color   // second gradient stop (violet) used for glow borders and active tiles
)

fun makePal(mode: Int): Pal = when (mode) {
    ThemeMode.NOTHING -> Pal(
        true, true, bg = Color(0xFF050505), tile = Color(0xFF171717), thumb = Color(0xFF252525),
        text = Color(0xFFF6F6F2), sub = Color(0xFF9C9C95), line = Color(0xFF303030), track = Color(0xFF424242),
        accent = Color(0xFFD8FF54), green = Color(0xFFD8FF54), amber = Color(0xFFFFC857), red = Color(0xFFFF655B),
        sheet = Color(0xF20D0D0D), accent2 = Color(0xFF9CC72D)
    )
    ThemeMode.AURORA -> Pal(
        true, false, bg = Color(0xFF0B0B0D), tile = Color(0xFF1B1A1D), thumb = Color(0xFF292427),
        text = Color(0xFFFAF9F7), sub = Color(0xFFA4A1A5), line = Color(0xFF353236), track = Color(0xFF474348),
        accent = Color(0xFFE84135), green = Color(0xFF5ED6A0), amber = Color(0xFFFFB454), red = Color(0xFFFF6258),
        sheet = Color(0xF2131315), accent2 = Color(0xFFFF786D)
    )
    ThemeMode.SONY -> Pal(
        true, false, bg = Color(0xFF09111A), tile = Color(0xFF142131), thumb = Color(0xFF21354A),
        text = Color(0xFFF2F7FD), sub = Color(0xFF96A9BC), line = Color(0xFF2B4054), track = Color(0xFF38516B),
        accent = Color(0xFF84B8FF), green = Color(0xFF66D9B0), amber = Color(0xFFFFC16C), red = Color(0xFFFF716C),
        sheet = Color(0xF2111D2B), accent2 = Color(0xFF5FE0E8)
    )
    ThemeMode.SPATIAL -> Pal(
        true, false, bg = Color(0xFF090B1B), tile = Color(0xFF171B32), thumb = Color(0xFF292B4B),
        text = Color(0xFFF5F3FF), sub = Color(0xFFA4A5C8), line = Color(0xFF343655), track = Color(0xFF43466D),
        accent = Color(0xFFB5A1FF), green = Color(0xFF75E5C2), amber = Color(0xFFFFC37B), red = Color(0xFFFF7893),
        sheet = Color(0xF2101328), accent2 = Color(0xFF6DDCFF)
    )
    else -> Pal(
        true, false, bg = Color(0xFF0A101B), tile = Color(0xFF172235), thumb = Color(0xFF293A55),
        text = Color(0xFFF5F8FF), sub = Color(0xFF9BA9BF), line = Color(0xFF2B3A51), track = Color(0xFF354760),
        accent = Color(0xFF7DE3FF), green = Color(0xFF30D158), amber = Color(0xFFFF9F0A), red = Color(0xFFFF453A),
        sheet = Color(0xE61A2639), accent2 = Color(0xFF8C7CFF)
    )
}

val LocalPal = staticCompositionLocalOf { makePal(ThemeMode.LIGHT) }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun BudsyTheme(mode: Int, content: @Composable () -> Unit) {
    val p = makePal(mode)
    val cs = if (p.dark) darkColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    ) else lightColorScheme(
        primary = p.accent, background = p.bg, surface = p.sheet, onSurface = p.text,
        onSurfaceVariant = p.sub, surfaceContainerHigh = p.sheet
    )
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
