package com.nordbuds.studio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class Pal(
    val dark: Boolean, val bg: Color, val card: Color, val tile: Color, val text: Color, val sub: Color,
    val line: Color, val track: Color, val accent: Color, val soft: Color, val green: Color, val amber: Color
)

val LightPal = Pal(
    false, Color(0xFFF1F5F0), Color(0xFFFFFFFF), Color(0xFFE9F0E8), Color(0xFF17211C), Color(0xFF718078),
    Color(0xFFDCE5DD), Color(0xFFB9C8BD), Color(0xFF789B55), Color(0xFFE4EEDB), Color(0xFF9FCB70), Color(0xFFE0A100)
)
val DarkPal = Pal(
    true, Color(0xFF0A1514), Color(0xFF142321), Color(0xFF1C302D), Color(0xFFF1F5EA), Color(0xFF91A59D),
    Color(0xFF2B403C), Color(0xFF435953), Color(0xFFB9DF83), Color(0xFF263A2D), Color(0xFFC8E99A), Color(0xFFF0B429)
)

val LocalPal = staticCompositionLocalOf { LightPal }
val P: Pal @Composable @ReadOnlyComposable get() = LocalPal.current

@Composable
fun NordTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) darkColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    else lightColorScheme(primary = p.accent, background = p.bg, surface = p.card, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
