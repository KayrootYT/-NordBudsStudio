package com.nordbuds.studio.buds

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("budsy", Context.MODE_PRIVATE)
    var autoPaused: Boolean get() = p.getBoolean("auto_paused", false); set(v) { p.edit().putBoolean("auto_paused", v).apply() }
    var customName: String? get() = p.getString("custom_name", null); set(v) { p.edit().putString("custom_name", v).apply() }
    var lastAddr: String? get() = p.getString("last_addr", null); set(v) { p.edit().putString("last_addr", v).apply() }
    /** 0 Light, 1 Dark, 2 AMOLED. -1 = never chosen, follow the phone until the user picks one. */
    var theme: Int get() = p.getInt("theme_v2", -1); set(v) { p.edit().putInt("theme_v2", v).apply() }
    var welcomed: Boolean get() = p.getBoolean("welcomed", false); set(v) { p.edit().putBoolean("welcomed", v).apply() }
    var diag: Boolean get() = p.getBoolean("diag", false); set(v) { p.edit().putBoolean("diag", v).apply() }
    var batteryNotif: Boolean get() = p.getBoolean("battery_notif", false); set(v) { p.edit().putBoolean("battery_notif", v).apply() }
    /** The three custom EQ profiles, as JSON (see EqSlots). */
    var eqSlots: String? get() = p.getString("eq_slots", null); set(v) { p.edit().putString("eq_slots", v).apply() }
    /** Which custom slot is currently applied to the buds, -1 for none. */
    var eqActive: Int get() = p.getInt("eq_active", -1); set(v) { p.edit().putInt("eq_active", v).apply() }
    /** Tap sounds and haptic feedback on tiles and buttons. */
    var tapSound: Boolean get() = p.getBoolean("tap_sound", true); set(v) { p.edit().putBoolean("tap_sound", v).apply() }
    var haptics: Boolean get() = p.getBoolean("haptics", true); set(v) { p.edit().putBoolean("haptics", v).apply() }
}
