package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import androidx.compose.runtime.*
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.Executors

/**
 * OPPO / OnePlus "HeyMelody" earbud protocol over classic Bluetooth RFCOMM.
 *
 * Frame:  AA | len16 LE (= 7 + payload) | 00 | cmdLow | cmdHigh | seq | payloadLen16 LE | payload
 * cmdHigh = group: 01 query, 02 push, 04 set.  Replies come back with 0x80 set in cmdHigh
 * (0x0108 -> 0x8108) and the payload starts with a status byte (00 = OK).
 *
 * Command table used here
 *   0x0106 battery            0x0108 read gesture table      0x0401 write gesture table
 *   0x010C read noise mode    0x0404 set noise mode / set hold-switch mask
 *   0x010D read feature flags 0x0403 set feature flag        0x010F / 0x0406 read / set EQ preset
 *   0x0124 read BassWave lvl  0x041B set BassWave level
 *
 * Gesture entry = [side, 01, gestureId, functionId]   side 1 = left, 2 = right.
 */
@SuppressLint("MissingPermission")
class Buds {
    companion object {
        // noise modes (UI side)
        const val ANC_OFF = 0
        const val ANC_ON = 1
        const val ANC_TRANSP = 2

        // gesture ids
        const val G_SINGLE = 1
        const val G_DOUBLE = 2
        const val G_TRIPLE = 3
        const val G_HOLD = 4
        const val G_LONG = 6

        // function ids
        const val F_NONE = 0x00
        const val F_PLAY = 0x01
        const val F_VOICE = 0x03
        const val F_PREV = 0x05
        const val F_NEXT = 0x06
        const val F_ANC = 0x08
        const val F_VOL_UP = 0x0B
        const val F_VOL_DN = 0x0C
        const val F_GAME = 0x11

        // bits of the "touch and hold" mode list
        const val M_OFF = 1
        const val M_ANC = 2
        const val M_TRANSP = 4

        // EQ preset ids as captured from HeyMelody
        val PRESETS = listOf(Triple(3, "Balanced", "Natural, even tuning"), Triple(4, "Serenade", "Warm, vocal-forward"), Triple(5, "Bass", "Punchy low end"))

        fun hex(v: Int) = (v and 255).toString(16).padStart(2, '0')
    }

    // ---------------------------------------------------------------- state shown in the UI
    var status by mutableStateOf("Not connected")
    var connected by mutableStateOf(false)
    var connecting by mutableStateOf(false)
    var deviceName by mutableStateOf("")
    var deviceAddr by mutableStateOf("")
    val battery = mutableStateListOf(-1, -1, -1)            // left, right, case
    val charging = mutableStateListOf(false, false, false)
    var ancMode by mutableIntStateOf(-1)                     // ANC_OFF / ANC_ON / ANC_TRANSP
    @set:JvmName("setHoldMaskState")
    var holdMask by mutableIntStateOf(-1)                    // modes cycled by "touch and hold"
    var eqPreset by mutableIntStateOf(-1)
    var gameMode by mutableStateOf<Boolean?>(null)
    var bassOn by mutableStateOf<Boolean?>(null)
    var bassLevel by mutableStateOf<Int?>(null)
    var bassMin by mutableIntStateOf(-10)
    var bassMax by mutableIntStateOf(10)
    val gest = mutableStateMapOf<Int, Int>()                 // side*16+gestureId -> functionId
    var msg by mutableStateOf<Pair<Int, String>?>(null)      // (counter, text) for a snackbar
    var logVersion by mutableIntStateOf(0)

    // ---------------------------------------------------------------- internals
    private val io = Executors.newSingleThreadExecutor()
    private var sock: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var seq = 0x20
    private var gen = 0
    private var msgSeq = 0
    private var pendingAnc = -1
    private var ancSwapped = false
    private val ancCode = intArrayOf(1, 2, 4)                // index = ANC_OFF / ANC_ON / ANC_TRANSP
    private val pendingGest = HashMap<Int, Int>()
    private var verifyGest = false
    private var bassRawMin = 0xF6
    private var bassRawMax = 0x0A
    private val logBuf = java.util.ArrayDeque<String>()
    private val featReq = intArrayOf(6, 5, 0x0b, 0x11, 6, 0x1b, 0x1d)

    fun say(t: String) { msg = Pair(++msgSeq, t) }

    fun logText(): String = synchronized(logBuf) { logBuf.joinToString("\n") }

    private fun note(dir: String, lo: Int, hi: Int, p: IntArray) {
        val s = dir + " " + hex(hi) + hex(lo) + " " + p.joinToString(" ") { hex(it) }
        synchronized(logBuf) { logBuf.addLast(s); while (logBuf.size > 150) logBuf.removeFirst() }
        logVersion++
    }

    @Synchronized
    private fun raw(cmd: Int, grp: Int, pl: IntArray) {
        val o = out ?: return
        val n = 7 + pl.size
        val f = ByteArray(9 + pl.size)
        f[0] = 0xAA.toByte(); f[1] = n.toByte(); f[2] = (n shr 8).toByte(); f[3] = 0
        f[4] = cmd.toByte(); f[5] = grp.toByte(); f[6] = (seq++ and 255).toByte()
        f[7] = pl.size.toByte(); f[8] = (pl.size shr 8).toByte()
        pl.forEachIndexed { i, v -> f[9 + i] = v.toByte() }
        note("TX", cmd, grp, pl)
        try { o.write(f); o.flush() } catch (e: Exception) { drop("Connection lost") }
    }

    private fun send(cmd: Int, grp: Int, vararg pl: Int) { io.execute { raw(cmd, grp, pl) } }

    /** Ask for a value a moment later (gives the buds time to apply a change first). */
    private fun query(cmd: Int, vararg pl: Int) {
        io.execute { try { Thread.sleep(200) } catch (e: Exception) { }; raw(cmd, 1, pl) }
    }

    // ---------------------------------------------------------------- connection
    fun connect(d: BluetoothDevice) {
        if (connecting) return
        connecting = true; status = "Connecting…"
        val g = ++gen
        Thread {
            try {
                try { sock?.close() } catch (e: Exception) { }
                try { d.fetchUuidsWithSdp(); Thread.sleep(1500) } catch (e: Exception) { }
                val sig = "-0000-1000-8000-00805f9b34fb"
                val all = (d.uuids ?: emptyArray()).map { it.uuid }
                // audio profiles belong to the phone's own stack; never open them from here
                val audio = setOf(0x1108, 0x1112, 0x111E, 0x111F, 0x110A, 0x110B, 0x110C, 0x110D, 0x110E, 0x110F, 0x112F, 0x1132)
                fun isAudio(u: java.util.UUID): Boolean =
                    u.toString().endsWith(sig) && audio.contains(((u.mostSignificantBits ushr 32) and 0xFFFFL).toInt())
                val usable = all.filter { !isAudio(it) }
                val order = usable.filter { !it.toString().endsWith(sig) } + usable.filter { it.toString().endsWith(sig) }
                for (u in order) {
                    try {
                        val s = d.createRfcommSocketToServiceRecord(u)
                        s.connect()
                        sock = s; out = s.outputStream
                        val inp = java.io.PushbackInputStream(s.inputStream)
                        raw(0, 1, intArrayOf())
                        if (!awaitData(inp)) { s.close(); out = null; continue }
                        deviceName = d.name ?: d.address; deviceAddr = d.address
                        connected = true; status = "Connected to $deviceName"
                        Thread { reader(inp, g) }.start()
                        initialRead()
                        heartbeat(g)
                        return@Thread
                    } catch (e: Exception) { /* try next UUID */ }
                }
                status = "Control channel not found. Close HeyMelody and try again."
            } finally {
                connecting = false
            }
        }.start()
    }

    // Accept the channel only if the first byte is the 0xAA frame marker (skips HFP/A2DP channels)
    private fun awaitData(i: java.io.PushbackInputStream): Boolean {
        repeat(30) {
            if (i.available() > 0) { val b = i.read(); if (b >= 0) i.unread(b); return b == 0xAA }
            Thread.sleep(100)
        }
        return false
    }

    private fun initialRead() {
        io.execute {
            val q = listOf(
                Pair(6, intArrayOf()),                // battery
                Pair(0x0c, intArrayOf(1, 1)),         // current noise mode
                Pair(0x0c, intArrayOf(2, 1)),         // modes cycled by touch-and-hold
                Pair(8, intArrayOf(2, 3, 1)),         // gesture table
                Pair(0x0d, featReq),                  // feature flags (game mode, BassWave ...)
                Pair(0x0f, intArrayOf()),             // EQ preset
                Pair(0x24, intArrayOf())              // BassWave level
            )
            for (c in q) { raw(c.first, 1, c.second); try { Thread.sleep(90) } catch (e: Exception) { } }
        }
    }

    fun refreshAll() { if (connected) initialRead() }

    private fun heartbeat(g: Int) {
        Thread {
            while (connected && g == gen) {
                try { Thread.sleep(10000) } catch (e: Exception) { }
                if (!connected || g != gen) break
                io.execute { raw(6, 1, intArrayOf()); raw(0x0c, 1, intArrayOf(1, 1)) }
            }
        }.start()
    }

    private fun reader(i: InputStream, g: Int) {
        val tmp = ByteArray(512)
        var acc = ByteArray(0)
        try {
            while (true) {
                val n = i.read(tmp); if (n < 0) break
                acc += tmp.copyOf(n)
                while (true) {
                    val s = acc.indexOfFirst { it == 0xAA.toByte() }
                    if (s < 0) { acc = ByteArray(0); break }
                    if (s > 0) acc = acc.copyOfRange(s, acc.size)
                    if (acc.size < 3) break
                    val len = (acc[1].toInt() and 255) or ((acc[2].toInt() and 255) shl 8)
                    if (acc.size < len + 2) break
                    val f = acc.copyOfRange(0, len + 2)
                    acc = acc.copyOfRange(len + 2, acc.size)
                    try { handle(f) } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) { }
        if (g == gen) drop("Disconnected")
    }

    // ---------------------------------------------------------------- incoming frames
    private fun handle(f: ByteArray) {
        if (f.size < 9) return
        val lo = f[4].toInt() and 255
        val hi = f[5].toInt() and 255
        val p = IntArray(f.size - 9) { f[9 + it].toInt() and 255 }
        note("RX", lo, hi, p)

        if ((hi and 0x80) == 0) {                         // unsolicited push from the buds
            if (hi == 0x02 && lo == 0x04 && p.size >= 5 && p[0] == 3) onAncValue(p[3] or (p[4] shl 8))
            return
        }
        if (p.isEmpty()) return
        val cmd = ((hi and 0x7f) shl 8) or lo
        val st = p[0]
        when (cmd) {
            0x0106 -> if (st == 0 && p.size >= 2) for (k in 0 until p[1]) {
                val j = 2 + k * 2
                if (j + 1 < p.size && p[j] in 1..3) {
                    val v = p[j + 1]
                    val pct = v and 0x7f
                    battery[p[j] - 1] = if (pct in 0..100) pct else -1
                    charging[p[j] - 1] = (v and 0x80) != 0
                }
            }

            0x0108 -> if (st == 0 && p.size >= 2) onGestureTable(p)

            0x010C -> if (st == 0 && p.size >= 5) {
                val mask = p[3] or (p[4] shl 8)
                if (p[1] == 1) onAncValue(mask) else if (p[1] == 2) holdMask = mask and 7
            }

            0x010D -> if (st == 0 && p.size >= 2) for (k in 0 until p[1]) {
                val j = 2 + k * 2
                if (j + 1 < p.size) when (p[j]) {
                    0x06 -> gameMode = p[j + 1] == 1
                    0x1d -> bassOn = p[j + 1] == 1
                }
            }

            0x010F -> if (st == 0 && p.size >= 2) eqPreset = p[1]

            0x0124 -> if (st == 0 && p.size >= 4) {
                bassRawMin = p[1]; bassRawMax = p[2]
                val mn = p[1].toByte().toInt(); val mx = p[2].toByte().toInt()
                if (mn < mx) { bassMin = mn; bassMax = mx }
                bassLevel = p[3].toByte().toInt().coerceIn(bassMin, bassMax)
            }

            // ---- acknowledgements of our writes
            0x0401 -> {
                if (st != 0) say("The buds refused that gesture (code 0x${hex(st)})")
                verifyGest = st == 0
                query(8, 2, 3, 1)
            }
            0x0403 -> {
                if (st != 0) say("The buds refused that setting (code 0x${hex(st)})")
                query(0x0d, *featReq)
            }
            0x0404 -> {
                if (st != 0) {
                    pendingAnc = -1
                    say(if (st == 0x0e) "Put both earbuds in your ears to change noise control" else "Noise control change failed (code 0x${hex(st)})")
                }
                query(0x0c, 1, 1); query(0x0c, 2, 1)
            }
            0x0406 -> {
                if (st != 0) say("The buds refused that sound preset (code 0x${hex(st)})")
                query(0x0f)
            }
            0x041B -> {
                if (st != 0) say("The buds refused that BassWave level (code 0x${hex(st)})")
                query(0x24)
            }
        }
    }

    private fun decodeAnc(m: Int): Int = when {
        (m and 0x0300) != 0 -> ANC_TRANSP
        (m and 0x0008) != 0 -> ANC_OFF
        (m and 0x08F2) != 0 -> ANC_ON
        else -> -1
    }

    /** Called with the mode the buds report (read-back or push). Fixes the Off/ANC code order if it was guessed wrong. */
    private fun onAncValue(mask: Int) {
        val m = decodeAnc(mask)
        if (m < 0) return
        val want = pendingAnc
        pendingAnc = -1
        if (want >= 0 && m != want && !ancSwapped &&
            (m == ANC_OFF || m == ANC_ON) && (want == ANC_OFF || want == ANC_ON)
        ) {
            ancSwapped = true
            val t = ancCode[ANC_OFF]; ancCode[ANC_OFF] = ancCode[ANC_ON]; ancCode[ANC_ON] = t
            pendingAnc = want
            send(4, 4, 1, 1, ancCode[want])
            return
        }
        ancMode = m
    }

    private fun onGestureTable(p: IntArray) {
        val pend = synchronized(pendingGest) { HashMap(pendingGest) }
        val verify = verifyGest
        for (k in 0 until p[1]) {
            val j = 2 + k * 4
            if (j + 3 >= p.size) break
            if (p[j + 1] != 1) continue
            val key = p[j] * 16 + p[j + 2]
            if (pend.containsKey(key) && !verify) continue   // keep what the user just picked until the buds confirm it
            gest[key] = p[j + 3]
        }
        if (verify) {
            verifyGest = false
            var bad = false
            for (e in pend) if (gest[e.key] != e.value) bad = true
            synchronized(pendingGest) { pendingGest.clear() }
            if (bad) say("The buds did not keep that gesture. Check Settings → About for the raw table.")
        }
    }

    private fun drop(m: String) {
        connected = false; status = m; out = null
        try { sock?.close() } catch (e: Exception) { }
        sock = null
        for (i in 0..2) { battery[i] = -1; charging[i] = false }
    }

    fun disconnect() { gen++; drop("Not connected") }

    // ---------------------------------------------------------------- commands
    private fun need(): Boolean {
        if (!connected) { say("Connect your earbuds first"); return false }
        return true
    }

    fun setAnc(mode: Int) {
        if (!need()) return
        ancMode = mode; pendingAnc = mode
        send(4, 4, 1, 1, ancCode[mode])
    }

    /** Which noise modes "touch and hold" cycles through (M_OFF | M_ANC | M_TRANSP). One mode = no switching. */
    fun setHoldMask(mask: Int) {
        if (!need()) return
        val m = mask and 7
        if (m == 0) return
        holdMask = m
        send(4, 4, 2, 1, m, 0)
    }

    fun setGesture(side: Int, gid: Int, fn: Int) {
        if (!need()) return
        val k = side * 16 + gid
        gest[k] = fn
        synchronized(pendingGest) { pendingGest[k] = fn }
        send(1, 4, 1, side, 1, gid, fn)
    }

    fun setEq(id: Int) { if (!need()) return; eqPreset = id; send(6, 4, id) }

    fun setGame(on: Boolean) { if (!need()) return; gameMode = on; send(3, 4, 0x06, if (on) 1 else 0) }

    fun setBassOn(on: Boolean) { if (!need()) return; bassOn = on; send(3, 4, 0x1d, if (on) 1 else 0) }

    fun setBassLevel(level: Int) {
        if (!need()) return
        val l = level.coerceIn(bassMin, bassMax)
        bassLevel = l
        send(0x1b, 4, bassRawMin, bassRawMax, l and 255)
    }
}
