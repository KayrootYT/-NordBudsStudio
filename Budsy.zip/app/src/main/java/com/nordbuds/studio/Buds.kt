package com.nordbuds.studio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import androidx.compose.runtime.*
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.Executors
import java.util.concurrent.Future

/**
 * OPPO / OnePlus "HeyMelody" earbud protocol over classic Bluetooth RFCOMM.
 *
 * Frame:  AA | len16 LE (= 7 + payload) | 00 | cmdLow | cmdHigh | seq | payloadLen16 LE | payload
 * cmdHigh = group: 01 query, 02 push, 04 set.  Replies come back with 0x80 set in cmdHigh
 * (0x0108 -> 0x8108) and the payload starts with a status byte (00 = OK).
 *
 * Command table used here
 *   0x0106 battery            0x0108 read gesture table      0x0401 write gesture table
 *   0x010C read noise mode    0x0404 set noise mode / set hold-switch mask
 *   0x010D read feature flags 0x0403 set feature flag        0x010F / 0x0406 read / set EQ preset
 *   0x0124 read BassWave lvl  0x041B set BassWave level
 *
 * Gesture entry = [side, 01, gestureId, functionId]   side 1 = left, 2 = right.
 */
@SuppressLint("MissingPermission")
class Buds {
    companion object {
        // noise modes (UI side)
        const val ANC_OFF = 0
        const val ANC_ON = 1
        const val ANC_TRANSP = 2

        // gesture ids
        const val G_SINGLE = 1
        const val G_DOUBLE = 2
        const val G_TRIPLE = 3
        const val G_HOLD = 4
        const val G_LONG = 6

        // function ids
        const val F_NONE = 0x00
        const val F_PLAY = 0x01
        const val F_VOICE = 0x03
        const val F_PREV = 0x05
        const val F_NEXT = 0x06
        const val F_ANC = 0x08
        const val F_VOL_UP = 0x0B
        const val F_VOL_DN = 0x0C
        const val F_GAME = 0x11

        // bits of the "touch and hold" mode list
        const val M_OFF = 1
        const val M_ANC = 2
        const val M_TRANSP = 4

        // EQ preset ids as captured from HeyMelody
        val PRESETS = listOf(Triple(3, "Balanced", "Natural, even tuning"), Triple(4, "Serenade", "Warm, vocal-forward"), Triple(5, "Bass", "Punchy low end"))

        fun hex(v: Int) = (v and 255).toString(16).padStart(2, '0')
    }

    // ---------------------------------------------------------------- state shown in the UI
    var status by mutableStateOf("Not connected")
    var connected by mutableStateOf(false)
    var connecting by mutableStateOf(false)
    var deviceName by mutableStateOf("")
    var deviceAddr by mutableStateOf("")
    val battery = mutableStateListOf(-1, -1, -1)            // left, right, case
    val charging = mutableStateListOf(false, false, false)
    var ancMode by mutableIntStateOf(-1)                     // ANC_OFF / ANC_ON / ANC_TRANSP
    @set:JvmName("setHoldMaskState")
    var holdMask by mutableIntStateOf(-1)                    // modes cycled by "touch and hold"
    var eqPreset by mutableIntStateOf(-1)
    var gameMode by mutableStateOf<Boolean?>(null)
    var bassOn by mutableStateOf<Boolean?>(null)
    var bassLevel by mutableStateOf<Int?>(null)
    var bassMin by mutableIntStateOf(-10)
    var bassMax by mutableIntStateOf(10)
    val gest = mutableStateMapOf<Int, Int>()                 // side*16+gestureId -> functionId
    var msg by mutableStateOf<Pair<Int, String>?>(null)      // (counter, text) for a snackbar
    var logVersion by mutableIntStateOf(0)

    // ---------------------------------------------------------------- internals
    private val io = Executors.newSingleThreadExecutor { task ->
        Thread(task, "budsy-bluetooth-io").apply { isDaemon = true }
    }
    private val connector = Executors.newSingleThreadExecutor { task ->
        Thread(task, "budsy-bluetooth-connect").apply { isDaemon = true }
    }
    @Volatile private var sock: BluetoothSocket? = null
    @Volatile private var candidateSock: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var connectTask: Future<*>? = null
    @Volatile private var closed = false
    private var seq = 0x20
    @Volatile private var gen = 0
    private var msgSeq = 0
    private var pendingAnc = -1
    private var ancSwapped = false
    private val ancCode = intArrayOf(1, 2, 4)                // index = ANC_OFF / ANC_ON / ANC_TRANSP
    private val pendingGest = HashMap<Int, Int>()
    private var verifyGest = false
    private var bassRawMin = 0xF6
    private var bassRawMax = 0x0A
    private val logBuf = java.util.ArrayDeque<String>()
    private val featReq = intArrayOf(6, 5, 0x0b, 0x11, 6, 0x1b, 0x1d)

    fun say(t: String) { msg = Pair(++msgSeq, t) }

    fun logText(): String = synchronized(logBuf) { logBuf.joinToString("\n") }

    private fun note(dir: String, lo: Int, hi: Int, p: IntArray) {
        val s = dir + " " + hex(hi) + hex(lo) + " " + p.joinToString(" ") { hex(it) }
        synchronized(logBuf) { logBuf.addLast(s); while (logBuf.size > 150) logBuf.removeFirst() }
        logVersion++
    }

    @Synchronized
    private fun raw(cmd: Int, grp: Int, pl: IntArray) {
        val o = out ?: return
        val f = try { FrameCodec.encode(cmd, grp, seq++ and 255, pl) }
        catch (e: IllegalArgumentException) { say("Command was too large to send"); return }
        note("TX", cmd, grp, pl)
        try { o.write(f); o.flush() } catch (e: Exception) { drop("Connection lost") }
    }

    private fun send(cmd: Int, grp: Int, vararg pl: Int) { io.execute { raw(cmd, grp, pl) } }

    /** Ask for a value a moment later (gives the buds time to apply a change first). */
    private fun query(cmd: Int, vararg pl: Int) {
        io.execute { try { Thread.sleep(200) } catch (e: Exception) { }; raw(cmd, 1, pl) }
    }

    // ---------------------------------------------------------------- connection
    @Synchronized
    fun connect(d: BluetoothDevice) {
        if (connecting || connected || closed) return
        connecting = true
        status = "Connecting…"
        val g = ++gen
        connectTask = connector.submit {
            var lastFailure: Exception? = null
            try {
                try {
                    d.fetchUuidsWithSdp()
                    for (attempt in 0 until 20) {
                        if (!d.uuids.isNullOrEmpty()) break
                        Thread.sleep(200)
                    }
                } catch (e: Exception) {
                    lastFailure = e
                }
                if (!isCurrent(g)) return@submit

                val sig = "-0000-1000-8000-00805f9b34fb"
                val all = (d.uuids ?: emptyArray()).map { it.uuid }
                val order = all.filter { !it.toString().endsWith(sig) } + all.filter { it.toString().endsWith(sig) }
                if (order.isEmpty()) {
                    if (isCurrent(g)) status = "No Bluetooth control service was found. Re-pair the earbuds, close HeyMelody, and retry."
                    return@submit
                }

                for (u in order) {
                    if (!isCurrent(g)) break
                    var attempt: BluetoothSocket? = null
                    try {
                        attempt = d.createRfcommSocketToServiceRecord(u)
                        candidateSock = attempt
                        attempt.connect()
                        if (!isCurrent(g)) {
                            closeAttempt(attempt)
                            return@submit
                        }
                        sock = attempt
                        out = attempt.outputStream
                        val inp = java.io.PushbackInputStream(attempt.inputStream)
                        raw(0, 1, intArrayOf())
                        if (!awaitData(inp, g)) {
                            closeAttempt(attempt)
                            clearAttempt(attempt)
                            lastFailure = java.io.IOException("No protocol greeting received")
                            continue
                        }
                        if (!isCurrent(g)) {
                            closeAttempt(attempt)
                            clearAttempt(attempt)
                            return@submit
                        }
                        deviceName = d.name ?: d.address
                        deviceAddr = d.address
                        connected = true
                        status = "Connected to $deviceName"
                        Thread({ reader(inp, g) }, "budsy-bluetooth-reader")
                            .apply { isDaemon = true; start() }
                        initialRead()
                        heartbeat(g)
                        return@submit
                    } catch (e: Exception) {
                        lastFailure = e
                        if (attempt != null) {
                            closeAttempt(attempt)
                            clearAttempt(attempt)
                        }
                    } finally {
                        if (candidateSock === attempt) candidateSock = null
                    }
                }
                if (isCurrent(g)) {
                    val reason = lastFailure?.javaClass?.simpleName
                    status = if (reason == "SecurityException") {
                        "Bluetooth permission was denied. Allow Nearby devices and try again."
                    } else {
                        "Could not open the earbud control channel. Confirm the earbuds are paired, Bluetooth is on, and HeyMelody is closed${reason?.let { " (last error: $it)" } ?: ""}."
                    }
                    note("ERR", 0, 0, intArrayOf())
                }
            } finally {
                if (g == gen) connecting = false
            }
        }
    }

    // Accept the channel only if the first byte is the 0xAA frame marker (skips HFP/A2DP channels)
    private fun awaitData(i: java.io.PushbackInputStream, g: Int): Boolean {
        repeat(30) {
            if (!isCurrent(g)) return false
            if (i.available() > 0) { val b = i.read(); if (b >= 0) i.unread(b); return b == 0xAA }
            Thread.sleep(100)
        }
        return false
    }

    private fun isCurrent(g: Int) = g == gen && !closed

    private fun closeAttempt(s: BluetoothSocket) {
        try { s.close() } catch (_: Exception) { }
    }

    @Synchronized
    private fun clearAttempt(s: BluetoothSocket) {
        if (sock === s) {
            sock = null
            out = null
        }
        if (candidateSock === s) candidateSock = null
    }

    private fun initialRead() {
        io.execute {
            val q = listOf(
                Pair(6, intArrayOf()),                // battery
                Pair(0x0c, intArrayOf(1, 1)),         // current noise mode
                Pair(0x0c, intArrayOf(2, 1)),         // modes cycled by touch-and-hold
                Pair(8, intArrayOf(2, 3, 1)),         // gesture table
                Pair(0x0d, featReq),                  // feature flags (game mode, BassWave ...)
                Pair(0x0f, intArrayOf()),             // EQ preset
                Pair(0x24, intArrayOf())              // BassWave level
            )
            for (c in q) { raw(c.first, 1, c.second); try { Thread.sleep(90) } catch (e: Exception) { } }
        }
    }

    fun refreshAll() { if (connected) initialRead() }

    private fun heartbeat(g: Int) {
        Thread({
            while (connected && isCurrent(g)) {
                try { Thread.sleep(10000) } catch (_: InterruptedException) { break }
                if (!connected || !isCurrent(g)) break
                io.execute { raw(6, 1, intArrayOf()); raw(0x0c, 1, intArrayOf(1, 1)) }
            }
        }, "budsy-bluetooth-heartbeat").apply { isDaemon = true; start() }
    }

    private fun reader(i: InputStream, g: Int) {
        val tmp = ByteArray(512)
        var acc = ByteArray(0)
        try {
            while (isCurrent(g)) {
                val n = i.read(tmp)
                if (n < 0) break
                if (n == 0) continue
                val decoded = FrameCodec.split(acc + tmp.copyOf(n))
                acc = decoded.remainder
                decoded.frames.forEach { frame ->
                    if (isCurrent(g)) {
                        try { handle(frame) } catch (_: Exception) { note("ERR", 0, 0, intArrayOf()) }
                    }
                }
            }
        } catch (_: Exception) { }
        if (isCurrent(g)) drop("Disconnected")
    }

    // ---------------------------------------------------------------- incoming frames
    private fun handle(f: ByteArray) {
        if (!FrameCodec.isValid(f)) return
        val lo = f[4].toInt() and 255
        val hi = f[5].toInt() and 255
        val p = IntArray(f.size - 9) { f[9 + it].toInt() and 255 }
        note("RX", lo, hi, p)

        if ((hi and 0x80) == 0) {                         // unsolicited push from the buds
            if (hi == 0x02 && lo == 0x04 && p.size >= 5 && p[0] == 3) onAncValue(p[3] or (p[4] shl 8))
            return
        }
        if (p.isEmpty()) return
        val cmd = ((hi and 0x7f) shl 8) or lo
        val st = p[0]
        when (cmd) {
            0x0106 -> if (st == 0 && p.size >= 2) for (k in 0 until p[1]) {
                val j = 2 + k * 2
                if (j + 1 < p.size && p[j] in 1..3) {
                    val v = p[j + 1]
                    val pct = v and 0x7f
                    battery[p[j] - 1] = if (pct in 0..100) pct else -1
                    charging[p[j] - 1] = (v and 0x80) != 0
                }
            }

            0x0108 -> if (st == 0 && p.size >= 2) onGestureTable(p)

            0x010C -> if (st == 0 && p.size >= 5) {
                val mask = p[3] or (p[4] shl 8)
                if (p[1] == 1) onAncValue(mask) else if (p[1] == 2) holdMask = mask and 7
            }

            0x010D -> if (st == 0 && p.size >= 2) for (k in 0 until p[1]) {
                val j = 2 + k * 2
                if (j + 1 < p.size) when (p[j]) {
                    0x06 -> gameMode = p[j + 1] == 1
                    0x1d -> bassOn = p[j + 1] == 1
                }
            }

            0x010F -> if (st == 0 && p.size >= 2) eqPreset = p[1]

            0x0124 -> if (st == 0 && p.size >= 4) {
                bassRawMin = p[1]; bassRawMax = p[2]
                val mn = p[1].toByte().toInt(); val mx = p[2].toByte().toInt()
                if (mn < mx) { bassMin = mn; bassMax = mx }
                bassLevel = p[3].toByte().toInt().coerceIn(bassMin, bassMax)
            }

            // ---- acknowledgements of our writes
            0x0401 -> {
                if (st != 0) {
                    say("The buds refused that gesture (code 0x${hex(st)})")
                    synchronized(pendingGest) { pendingGest.clear() }
                }
                verifyGest = st == 0
                query(8, 2, 3, 1)
            }
            0x0403 -> {
                if (st != 0) say("The buds refused that setting (code 0x${hex(st)})")
                query(0x0d, *featReq)
            }
            0x0404 -> {
                if (st != 0) {
                    pendingAnc = -1
                    say(if (st == 0x0e) "Put both earbuds in your ears to change noise control" else "Noise control change failed (code 0x${hex(st)})")
                }
                query(0x0c, 1, 1); query(0x0c, 2, 1)
            }
            0x0406 -> {
                if (st != 0) say("The buds refused that sound preset (code 0x${hex(st)})")
                query(0x0f)
            }
            0x041B -> {
                if (st != 0) say("The buds refused that BassWave level (code 0x${hex(st)})")
                query(0x24)
            }
        }
    }

    private fun decodeAnc(m: Int): Int = when {
        (m and 0x0300) != 0 -> ANC_TRANSP
        (m and 0x0008) != 0 -> ANC_OFF
        (m and 0x08F2) != 0 -> ANC_ON
        else -> -1
    }

    /** Called with the mode the buds report (read-back or push). Fixes the Off/ANC code order if it was guessed wrong. */
    private fun onAncValue(mask: Int) {
        val m = decodeAnc(mask)
        if (m < 0) return
        val want = pendingAnc
        pendingAnc = -1
        if (want >= 0 && m != want && !ancSwapped &&
            (m == ANC_OFF || m == ANC_ON) && (want == ANC_OFF || want == ANC_ON)
        ) {
            ancSwapped = true
            val t = ancCode[ANC_OFF]; ancCode[ANC_OFF] = ancCode[ANC_ON]; ancCode[ANC_ON] = t
            pendingAnc = want
            send(4, 4, 1, 1, ancCode[want])
            return
        }
        ancMode = m
    }

    private fun onGestureTable(p: IntArray) {
        val pend = synchronized(pendingGest) { HashMap(pendingGest) }
        val verify = verifyGest
        for (k in 0 until p[1]) {
            val j = 2 + k * 4
            if (j + 3 >= p.size) break
            if (p[j + 1] != 1) continue
            val key = p[j] * 16 + p[j + 2]
            if (pend.containsKey(key) && !verify) continue   // keep what the user just picked until the buds confirm it
            gest[key] = p[j + 3]
        }
        if (verify) {
            verifyGest = false
            var bad = false
            for (e in pend) if (gest[e.key] != e.value) bad = true
            synchronized(pendingGest) { pendingGest.clear() }
            if (bad) say("The buds did not keep that gesture. Check Settings → About for the raw table.")
        }
    }

    @Synchronized
    private fun drop(m: String) {
        connected = false; status = m; out = null
        val active = sock
        val candidate = candidateSock
        sock = null
        candidateSock = null
        try { active?.close() } catch (_: Exception) { }
        if (candidate !== active) try { candidate?.close() } catch (_: Exception) { }
        for (i in 0..2) { battery[i] = -1; charging[i] = false }
        ancMode = -1
        holdMask = -1
        eqPreset = -1
        gameMode = null
        bassOn = null
        bassLevel = null
        gest.clear()
        pendingAnc = -1
        verifyGest = false
        synchronized(pendingGest) { pendingGest.clear() }
    }

    @Synchronized
    fun disconnect() {
        if (closed) return
        gen++
        connecting = false
        connectTask?.cancel(true)
        connectTask = null
        drop("Not connected")
    }

    @Synchronized
    fun close() {
        if (closed) return
        closed = true
        gen++
        connecting = false
        connectTask?.cancel(true)
        connectTask = null
        drop("Not connected")
        connector.shutdownNow()
        io.shutdownNow()
    }

    // ---------------------------------------------------------------- commands
    private fun need(): Boolean {
        if (closed) { say("Close and reopen the app to reconnect"); return false }
        if (!connected) { say("Connect your earbuds first"); return false }
        return true
    }

    fun setAnc(mode: Int) {
        if (!need()) return
        if (mode !in ANC_OFF..ANC_TRANSP) return
        pendingAnc = mode
        send(4, 4, 1, 1, ancCode[mode])
    }

    /** Which noise modes "touch and hold" cycles through (M_OFF | M_ANC | M_TRANSP). One mode = no switching. */
    fun setHoldMask(mask: Int) {
        if (!need()) return
        val m = mask and 7
        if (m == 0) return
        send(4, 4, 2, 1, m, 0)
    }

    fun setGesture(side: Int, gid: Int, fn: Int) {
        if (!need()) return
        val k = side * 16 + gid
        synchronized(pendingGest) { pendingGest[k] = fn }
        send(1, 4, 1, side, 1, gid, fn)
    }

    fun setEq(id: Int) { if (!need()) return; send(6, 4, id) }

    fun setGame(on: Boolean) { if (!need()) return; send(3, 4, 0x06, if (on) 1 else 0) }

    fun setBassOn(on: Boolean) { if (!need()) return; send(3, 4, 0x1d, if (on) 1 else 0) }

    fun setBassLevel(level: Int) {
        if (!need()) return
        val l = level.coerceIn(bassMin, bassMax)
        send(0x1b, 4, bassRawMin, bassRawMax, l and 255)
    }
}
