package com.nordbuds.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private val SliderH = 230.dp
private val ThumbR = 14.dp
private val ValueH = 26.dp
private val FreqH = 28.dp

/** One vertical EQ band: a thin track and a ring-and-dot thumb. Tap or drag; snaps to whole dB. */
@Composable
private fun BandSlider(value: Int, enabled: Boolean, modifier: Modifier = Modifier, onChange: (Int) -> Unit) {
    val range = EqSlots.RANGE
    val haptic = LocalHapticFeedback.current
    val cur by rememberUpdatedState(value)
    val push by rememberUpdatedState(onChange)
    val accent = P.accent
    val rail = P.sub.copy(alpha = 0.45f)
    val face = P.bg

    fun valueAt(y: Float, h: Float, r: Float): Int {
        val f = ((y - r) / (h - 2 * r)).coerceIn(0f, 1f)
        return (range - f * 2 * range).roundToInt().coerceIn(-range, range)
    }

    Canvas(
        modifier.width(44.dp).height(SliderH)
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { o ->
                    val v = valueAt(o.y, size.height.toFloat(), ThumbR.toPx())
                    if (v != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); push(v) }
                }
            }
            .pointerInput(enabled) {
                if (enabled) detectVerticalDragGestures { change, _ ->
                    change.consume()
                    val v = valueAt(change.position.y, size.height.toFloat(), ThumbR.toPx())
                    if (v != cur) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); push(v) }
                }
            }
    ) {
        val r = ThumbR.toPx()
        val cx = size.width / 2
        val top = r
        val bottom = size.height - r
        drawLine(rail, Offset(cx, 0f), Offset(cx, size.height), 3.dp.toPx(), StrokeCap.Round)
        val y = top + (bottom - top) * (range - value) / (2f * range)
        val zeroY = top + (bottom - top) / 2f
        val tint = if (enabled) accent else accent.copy(alpha = 0.5f)
        if (value != 0) {
            drawLine(tint, Offset(cx, zeroY), Offset(cx, y), 4.dp.toPx(), StrokeCap.Round)
            drawCircle(tint.copy(alpha = 0.22f), r + 7.dp.toPx(), Offset(cx, y))
        }
        drawCircle(face, r, Offset(cx, y))
        drawCircle(tint, r - 1.5.dp.toPx(), Offset(cx, y), style = Stroke(3.dp.toPx()))
        drawCircle(tint, 4.5.dp.toPx(), Offset(cx, y))
    }
}

private fun dbText(v: Int) = if (v > 0) "+$v" else "$v"

/** The band chart: dB scale on the left, one column per band with value on top and frequency below. */
@Composable
private fun EqChart(hz: List<Int>, gains: List<Int>, enabled: Boolean, onGain: (Int, Int) -> Unit) {
    val zero = P.line
    Row(Modifier.fillMaxWidth()) {
        Column(Modifier.width(30.dp)) {
            Box(Modifier.height(ValueH), contentAlignment = Alignment.CenterStart) { Txt("dB", 12, FontWeight.Medium, P.sub) }
            Box(Modifier.height(SliderH).fillMaxWidth()) {
                Txt("+${EqSlots.RANGE}", 12, FontWeight.Normal, P.sub, Modifier.align(Alignment.TopStart).offset(y = ThumbR - 8.dp))
                Txt("0", 12, FontWeight.Normal, P.sub, Modifier.align(Alignment.CenterStart))
                Txt("−${EqSlots.RANGE}", 12, FontWeight.Normal, P.sub, Modifier.align(Alignment.BottomStart).offset(y = -(ThumbR - 8.dp)))
            }
        }
        Row(
            Modifier.weight(1f).drawBehind {
                val y = (ValueH + SliderH / 2).toPx()
                drawLine(zero, Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
            }
        ) {
            hz.forEachIndexed { i, f ->
                val g = gains.getOrElse(i) { 0 }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.height(ValueH), contentAlignment = Alignment.Center) {
                        Txt(dbText(g), 14, FontWeight.SemiBold, if (g == 0) P.sub else P.accent, maxLines = 1)
                    }
                    BandSlider(g, enabled) { v -> onGain(i, v) }
                    Box(Modifier.height(FreqH), contentAlignment = Alignment.Center) {
                        Txt(EqSlots.label(f), 13, FontWeight.Normal, P.sub, maxLines = 1)
                    }
                }
            }
        }
    }
}

/**
 * Three custom EQ profiles. Pick one, then Edit / Delete it, or Save your changes.
 * Profiles live on the phone; Save (and "Use this profile") also writes the profile to the earbuds.
 */
@Composable
fun CustomEqSection(x: Ctx) {
    val b = x.b
    val prefs = x.prefs
    LaunchedEffect(Unit) { EqStore.load(prefs) }
    val slots = EqStore.slots
    var sel by rememberSaveable { mutableIntStateOf(EqStore.active.coerceAtLeast(0)) }
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf(listOf<Int>()) }
    var draftName by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }

    // Use the band layout the buds report, else the default six.
    val hz = b.customEqProfiles.firstOrNull()?.bands?.map { it.first }?.takeIf { it.isNotEmpty() } ?: EqSlots.DEFAULT_HZ
    val slot = slots.getOrNull(sel)
    val saved = slot?.gains?.takeIf { it.size == hz.size } ?: List(hz.size) { 0 }
    val shown = if (editing) draft else saved
    val isActive = EqStore.active == sel && slot != null
    val connectFirst = stringResource(R.string.err_connect_first)
    val toastSavedApplied = stringResource(R.string.eq_saved_applied)
    val toastSavedPhone = stringResource(R.string.eq_saved_phone)
    val toastApplied = stringResource(R.string.eq_applied)
    val toastDeleted = stringResource(R.string.eq_deleted)
    val slotName = slot?.name ?: EqSlots.defaultName(sel)

    fun applyToBuds(name: String, gains: List<Int>) {
        b.writeCustomEq(hz.zip(gains), name)
        EqStore.setActive(prefs, sel)
    }

    SectionLabel(stringResource(R.string.custom_eq), Icons.Rounded.Equalizer)
    GlassPanel {
        val slotIcons = listOf(Icons.Rounded.LooksOne, Icons.Rounded.LooksTwo, Icons.Rounded.Looks3)
        Segmented(
            List(EqSlots.COUNT) { i -> slotIcons[i] to (slots.getOrNull(i)?.name ?: EqSlots.defaultName(i)) },
            sel
        ) { if (it != sel) { sel = it; editing = false } }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isActive) { Icon(Icons.Rounded.CheckCircle, null, tint = P.green, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
            Txt(
                when { editing -> stringResource(R.string.edit); slot == null -> stringResource(R.string.eq_empty); isActive -> stringResource(R.string.eq_active_label); else -> stringResource(R.string.eq_saved_label) },
                13, FontWeight.Normal, if (isActive) P.green else P.sub
            )
        }
        Spacer(Modifier.height(12.dp))

        if (editing) {
            TextField(
                value = draftName,
                onValueChange = { draftName = it.take(EqSlots.NAME_MAX) },
                singleLine = true,
                label = { Text(stringResource(R.string.eq_name)) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { WideButton(stringResource(R.string.cancel), false, icon = Icons.Rounded.Close) { editing = false } }
                Box(Modifier.weight(1f)) {
                    WideButton(stringResource(R.string.save), true, icon = Icons.Rounded.Save) {
                        val name = draftName.trim().ifEmpty { EqSlots.defaultName(sel) }
                        EqStore.put(prefs, sel, EqSlot(name, draft))
                        editing = false
                        if (b.connected) { applyToBuds(name, draft); x.toast(toastSavedApplied) } else x.toast(toastSavedPhone)
                    }
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) {
                    WideButton(stringResource(R.string.edit), false, icon = Icons.Rounded.Edit) {
                        draft = saved; draftName = slotName; editing = true
                    }
                }
                Box(Modifier.weight(1f)) {
                    WideButton(stringResource(R.string.eq_delete), false, enabled = slot != null, destructive = true, icon = Icons.Rounded.Delete) { confirmDelete = true }
                }
            }
        }
    }

    GlassPanel(index = 1) {
        EqChart(hz, shown, editing) { i, v -> if (i in draft.indices) draft = draft.toMutableList().also { it[i] = v } }
        if (editing) {
            Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                SmallButton(stringResource(R.string.eq_reset), false, icon = Icons.Rounded.RestartAlt) { draft = List(hz.size) { 0 } }
            }
        } else if (slot != null && !isActive) {
            Spacer(Modifier.height(14.dp))
            WideButton(stringResource(R.string.eq_use), true, icon = Icons.Rounded.CheckCircle) {
                if (b.connected) { applyToBuds(slotName, saved); x.toast(toastApplied) } else x.toast(connectFirst)
            }
        }
    }
    SectionNote(stringResource(R.string.custom_eq_hint))

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.eq_delete_title, slotName)) },
            text = { Text(stringResource(R.string.eq_delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val wasActive = EqStore.active == sel
                    EqStore.put(prefs, sel, null)
                    if (wasActive && b.connected) b.setEq(3)
                    x.toast(toastDeleted)
                }) { Text(stringResource(R.string.eq_delete), color = P.red) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
