package com.nordbuds.studio

import android.content.Context

/** Remembers the last earbuds and the chosen look. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nbs", Context.MODE_PRIVATE)
    var lastAddr: String?
        get() = sp.getString("last", null)
        set(v) { sp.edit().putString("last", v).apply() }
    var dark: Boolean
        get() = sp.getBoolean("dark", true)
        set(v) { sp.edit().putBoolean("dark", v).apply() }
    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }
    var diag: Boolean
        get() = sp.getBoolean("diag", false)
        set(v) { sp.edit().putBoolean("diag", v).apply() }
}

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val prefs: Prefs, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit,
    val dark: Boolean, val accentIdx: Int, val setDark: (Boolean) -> Unit, val setAccent: (Int) -> Unit,
    val audio: Set<String>, val audioKnown: Boolean
)
