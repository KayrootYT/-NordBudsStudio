package com.nordbuds.studio

import android.content.Context

/** Remembers the last earbuds so the app can reconnect by itself. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nbs", Context.MODE_PRIVATE)
    var lastAddr: String?
        get() = sp.getString("last", null)
        set(v) { sp.edit().putString("last", v).apply() }
}

/** Everything a screen needs, passed as one object. */
class Ctx(
    val b: Buds, val prefs: Prefs, val perm: Boolean,
    val askPerm: () -> Unit, val toast: (String) -> Unit, val go: (Int) -> Unit,
    val deviceRefresh: Int, val refreshDevices: () -> Unit
)
