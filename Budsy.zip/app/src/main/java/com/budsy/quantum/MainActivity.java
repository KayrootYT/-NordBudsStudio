package com.budsy.quantum;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_BT_PERMISSIONS = 410;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private boolean scanning = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, ScanResult> discovered = new LinkedHashMap<>();
    private BluetoothDevice selectedDevice;

    private TextView statusPill, deviceSummary, deviceAddress, scanStatus, gattOutput;
    private LinearLayout deviceList;
    private Button scanButton, stopButton, connectButton, ancButton, findButton;

    private final Runnable stopScanRunnable = this::stopScan;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (manager != null) adapter = manager.getAdapter();
        scanButton.setOnClickListener(v -> beginScanWithPermissionCheck());
        stopButton.setOnClickListener(v -> stopScan());
        connectButton.setOnClickListener(v -> connectSelected());
        ancButton.setOnClickListener(v -> showProtocolNotice("ANC / transparency", "No verified Nord Buds 3 proprietary command has been identified in this clean project. The button will not send a fake command."));
        findButton.setOnClickListener(v -> showProtocolNotice("Find My Buds", "A real ring command requires a verified command/service for this exact Nord Buds 3 firmware. No sound has been sent to the earbuds."));
        updateBluetoothState();
    }

    private void bindViews() {
        statusPill = findViewById(R.id.statusPill);
        deviceSummary = findViewById(R.id.deviceSummary);
        deviceAddress = findViewById(R.id.deviceAddress);
        scanStatus = findViewById(R.id.scanStatus);
        deviceList = findViewById(R.id.deviceList);
        gattOutput = findViewById(R.id.gattOutput);
        scanButton = findViewById(R.id.scanButton);
        stopButton = findViewById(R.id.stopButton);
        connectButton = findViewById(R.id.connectButton);
        ancButton = findViewById(R.id.ancButton);
        findButton = findViewById(R.id.findButton);
    }

    private void updateBluetoothState() {
        if (adapter == null) {
            scanStatus.setText("This phone does not report a Bluetooth adapter.");
            scanButton.setEnabled(false);
            connectButton.setEnabled(false);
        } else {
            try {
                if (!adapter.isEnabled()) scanStatus.setText("Bluetooth is off. Turn it on in Android settings, then scan again.");
            } catch (SecurityException ignored) {
                scanStatus.setText("Grant Nearby devices permission, then start a scan.");
            }
        }
    }

    private boolean hasRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void beginScanWithPermissionCheck() {
        if (adapter == null) { toast("Bluetooth is not available on this phone."); return; }
        if (!adapter.isEnabled()) { toast("Turn on Bluetooth in Android settings first."); return; }
        if (!hasRequiredPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_BT_PERMISSIONS);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_BT_PERMISSIONS);
            }
            return;
        }
        startScan();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BT_PERMISSIONS) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted) startScan(); else scanStatus.setText("Bluetooth permission denied. Allow Nearby devices permission to scan/connect.");
        }
    }

    private void startScan() {
        if (scanning) return;
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { scanStatus.setText("BLE scanner unavailable. Check Bluetooth state."); return; }
            discovered.clear();
            deviceList.removeAllViews();
            scanning = true;
            scanStatus.setText("Scanning for BLE advertisements for 12 seconds…");
            scanButton.setEnabled(false);
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null, settings, scanCallback);
            handler.postDelayed(stopScanRunnable, 12000L);
        } catch (SecurityException e) {
            scanning = false;
            scanStatus.setText("Permission required: allow Nearby devices and try again.");
            scanButton.setEnabled(true);
        } catch (IllegalStateException e) {
            scanning = false;
            scanStatus.setText("Bluetooth scanner is not ready. Toggle Bluetooth and retry.");
            scanButton.setEnabled(true);
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) { runOnUiThread(() -> addScanResult(result)); }
        @Override public void onBatchScanResults(List<ScanResult> results) { runOnUiThread(() -> { for (ScanResult r : results) addScanResult(r); }); }
        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> {
                scanning = false;
                scanButton.setEnabled(true);
                scanStatus.setText("BLE scan failed (code " + errorCode + "). Wait a moment and retry.");
            });
        }
    };

    private void addScanResult(ScanResult result) {
        if (result == null || result.getDevice() == null) return;
        String address;
        String name;
        try {
            address = result.getDevice().getAddress();
            name = result.getScanRecord() != null ? result.getScanRecord().getDeviceName() : null;
            if (name == null || name.trim().isEmpty()) name = result.getDevice().getName();
        } catch (SecurityException e) { return; }
        if (address == null) return;
        if (name == null || name.trim().isEmpty()) name = "Unknown BLE device";
        discovered.put(address, result);
        renderDeviceList();
    }

    private void renderDeviceList() {
        deviceList.removeAllViews();
        if (discovered.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No BLE devices found yet. Keep the earbuds out of the case or in pairing mode.");
            empty.setTextColor(0xFF91A596); empty.setTextSize(13); empty.setPadding(14, 16, 14, 16);
            deviceList.addView(empty);
            return;
        }
        scanStatus.setText((scanning ? "Scanning · " : "Found ") + discovered.size() + " BLE device(s). Tap one to select.");
        for (ScanResult result : discovered.values()) {
            BluetoothDevice device = result.getDevice();
            String name = result.getScanRecord() != null ? result.getScanRecord().getDeviceName() : null;
            try { if (name == null || name.trim().isEmpty()) name = device.getName(); } catch (SecurityException ignored) { }
            if (name == null || name.trim().isEmpty()) name = "Unknown BLE device";
            String address;
            try { address = device.getAddress(); } catch (SecurityException e) { address = "Address unavailable"; }
            final String itemName = name;
            final String itemAddress = address;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL); row.setPadding(16, 14, 16, 14); row.setBackgroundResource(R.drawable.card_bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9); row.setLayoutParams(lp);
            TextView title = new TextView(this); title.setText(itemName); title.setTextColor(0xFFF1F5EC); title.setTextSize(15); title.setTypeface(null, 1);
            TextView sub = new TextView(this); sub.setText(itemAddress + "   ·   RSSI " + result.getRssi() + " dBm"); sub.setTextColor(0xFF91A596); sub.setTextSize(11); sub.setPadding(0, dp(5), 0, 0);
            TextView action = new TextView(this); action.setText("TAP TO SELECT  ›"); action.setTextColor(0xFFD2FF88); action.setTextSize(10); action.setPadding(0, dp(8), 0, 0);
            row.addView(title); row.addView(sub); row.addView(action);
            row.setOnClickListener(v -> {
                selectedDevice = device;
                deviceSummary.setText(itemName);
                deviceAddress.setText(itemAddress + " · RSSI " + result.getRssi() + " dBm");
                scanStatus.setText("Selected " + itemName + ". Tap Connect selected device.");
                Toast.makeText(this, "Selected " + itemName, Toast.LENGTH_SHORT).show();
            });
            deviceList.addView(row);
        }
    }

    private void stopScan() {
        handler.removeCallbacks(stopScanRunnable);
        if (!scanning) { scanButton.setEnabled(true); return; }
        try { if (scanner != null && hasRequiredPermissions()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
        scanning = false;
        scanButton.setEnabled(true);
        scanStatus.setText("Scan finished · " + discovered.size() + " BLE device(s) found.");
        if (discovered.isEmpty()) renderDeviceList();
    }

    private void connectSelected() {
        if (selectedDevice == null) { toast("Scan first, then select a device from the list."); return; }
        if (!hasRequiredPermissions()) { beginScanWithPermissionCheck(); return; }
        try {
            if (gatt != null) { gatt.disconnect(); gatt.close(); gatt = null; }
            deviceSummary.setText("Connecting to selected device…");
            gattOutput.setText("Connecting… waiting for GATT callback.");
            gatt = selectedDevice.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            gattOutput.setText("Bluetooth connect permission is missing.");
        } catch (Exception e) {
            gattOutput.setText("Could not start GATT connection: " + e.getClass().getSimpleName() + " — " + e.getMessage());
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt bluetoothGatt, int status, int newState) {
            runOnUiThread(() -> {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    statusPill.setText("CONNECTED");
                    deviceSummary.setText("BLE connected · discovering services…");
                    gattOutput.setText("Connected. Discovering GATT services…");
                    try { boolean started = bluetoothGatt.discoverServices(); if (!started) gattOutput.setText("Connected, but service discovery could not start. Retry connection."); }
                    catch (SecurityException e) { gattOutput.setText("Connected, but Bluetooth permission blocked service discovery."); }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    statusPill.setText("DISCONNECTED");
                    deviceSummary.setText("Disconnected · scan to reconnect");
                    if (status != BluetoothGatt.GATT_SUCCESS) gattOutput.setText("Disconnected with GATT status " + status + ". Check distance, battery and pairing state.");
                    else gattOutput.setText("Disconnected. Select the device and connect again when ready.");
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt bluetoothGatt, int status) {
            runOnUiThread(() -> {
                if (status != BluetoothGatt.GATT_SUCCESS) { gattOutput.setText("Service discovery failed with GATT status " + status + "."); return; }
                StringBuilder out = new StringBuilder();
                for (BluetoothGattService service : bluetoothGatt.getServices()) {
                    out.append("SERVICE  ").append(service.getUuid()).append('\n');
                    for (BluetoothGattCharacteristic c : service.getCharacteristics()) {
                        out.append("  CHAR  ").append(c.getUuid()).append("  [").append(propertyNames(c.getProperties())).append("]\n");
                    }
                    out.append('\n');
                }
                if (out.length() == 0) out.append("Connected, but the device exposed no GATT services.");
                out.append("\nSecurity note: UUID presence alone does not prove a safe/valid command. Proprietary writes are not attempted.");
                gattOutput.setText(out.toString());
                deviceSummary.setText("Connected · GATT services discovered");
            });
        }
    };

    private String propertyNames(int p) {
        ArrayList<String> names = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) names.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) names.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) names.add("WRITE_NO_RESPONSE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) names.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) names.add("INDICATE");
        return names.isEmpty() ? "NO_STANDARD_PROPERTIES" : String.join(",", names);
    }

    private void showProtocolNotice(String title, String message) {
        new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", (d, w) -> d.dismiss()).show();
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override protected void onDestroy() {
        stopScan();
        if (gatt != null) { try { if (hasRequiredPermissions()) gatt.disconnect(); gatt.close(); } catch (Exception ignored) { } gatt = null; }
        super.onDestroy();
    }
}
