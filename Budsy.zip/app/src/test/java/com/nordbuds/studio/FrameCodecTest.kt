package com.nordbuds.studio

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FrameCodecTest {
    @Test
    fun encodeWritesLittleEndianLengthsAndPayload() {
        val frame = FrameCodec.encode(0x06, 0x01, 0x20, intArrayOf(0xAA, 0x01))

        assertEquals(11, frame.size)
        assertEquals(9, frame[1].toInt() and 0xFF) // 7-byte body header + 2-byte payload
        assertEquals(0, frame[2].toInt() and 0xFF)
        assertEquals(2, frame[7].toInt() and 0xFF)
        assertArrayEquals(byteArrayOf(0xAA.toByte(), 0x01), frame.copyOfRange(9, 11))
        assertTrue(FrameCodec.isValid(frame))
    }

    @Test
    fun splitHandlesMultipleFramesAndLeadingNoise() {
        val first = FrameCodec.encode(0x06, 0x01, 0x20, intArrayOf())
        val second = FrameCodec.encode(0x0C, 0x01, 0x21, intArrayOf(1, 1))

        val decoded = FrameCodec.split(byteArrayOf(0x11, 0x22) + first + second)

        assertEquals(2, decoded.frames.size)
        assertArrayEquals(first, decoded.frames[0])
        assertArrayEquals(second, decoded.frames[1])
        assertEquals(0, decoded.remainder.size)
    }

    @Test
    fun splitRetainsPartialFrameUntilNextRead() {
        val frame = FrameCodec.encode(0x06, 0x01, 0x20, intArrayOf(3, 4, 5))
        val firstRead = FrameCodec.split(frame.copyOfRange(0, 5))

        assertEquals(0, firstRead.frames.size)
        assertEquals(5, firstRead.remainder.size)

        val secondRead = FrameCodec.split(firstRead.remainder + frame.copyOfRange(5, frame.size))
        assertEquals(1, secondRead.frames.size)
        assertArrayEquals(frame, secondRead.frames.single())
    }

    @Test
    fun splitSkipsInvalidLengthAndResynchronizes() {
        val valid = FrameCodec.encode(0x06, 0x01, 0x20, intArrayOf())
        val invalid = byteArrayOf(0xAA.toByte(), 0x01, 0x00, 0x33, 0x44)

        val decoded = FrameCodec.split(invalid + valid)

        assertEquals(1, decoded.frames.size)
        assertArrayEquals(valid, decoded.frames.single())
    }
}
