# Budsy — OnePlus Nord Buds 3

Native Android app (Kotlin + Jetpack Compose) with a four-tab interface inspired by the user's screenshots: Overview, Sound, Controls, and Settings. The model name is **OnePlus Nord Buds 3** (not Pro).

## Screens
- **Overview:** device name, available left/right/case battery values, noise-control controls when exposed by the experimental control channel, game mode, audio-route check, and quick access to Find My Buds.
- **Sound:** EQ presets, BassWave level when reported by the device, game mode, and hardware notes.
- **Controls:** per-ear touch gesture settings where the firmware protocol responds.
- **Settings:** Bluetooth connection information, nearby BLE scan/RSSI helper, and diagnostics/protocol log. The Overview connection panel also scans for nearby OnePlus/Nord devices and separates already-paired devices from devices that still need Android pairing.

## Important limitations
- A Bluetooth control-channel connection is not the same as Android media audio routing. If music plays from the phone speaker, open Android Bluetooth/Media output settings and select Nord Buds 3.
- Find My Buds currently scans nearby Bluetooth advertisements and shows signal strength. It does not make earbuds beep; that requires a supported firmware command or the official OnePlus/HeyMelody feature.
- Firmware update, ANC, EQ, battery and gesture commands depend on the actual Nord Buds 3 firmware protocol. Do not treat a UI control as proof that the earbuds accepted a command. Validate on the real device.
- Android's status-bar earbud icon is controlled by Android/OEM system UI and cannot be forced by this app on every phone.
- This project does not include a verified protocol capture from a physical Nord Buds 3. The frame parser has unit tests, but those tests cannot confirm proprietary command IDs or firmware compatibility.
- The workflow builds a debug APK. A distributable release APK needs a separately configured release signing key; do not put that key in the source archive.

## Build APK with GitHub Actions
1. Extract this ZIP and upload its contents to the root of a GitHub repository (`app/`, `build.gradle.kts`, `settings.gradle.kts`, `.github/`).
2. Open **Actions → Build Budsy APK** and run the workflow, or push to `main`.
3. Download the `NordBuds-apk` artifact after a successful run.
4. Use Scan nearby in the Overview connection panel to discover nearby OnePlus/Nord advertisements. Unpaired devices must first be paired in Android Bluetooth settings; scanning alone cannot establish the proprietary control channel. Close HeyMelody/Wireless Earphones before testing the experimental control channel.

The workflow runs the local unit tests before assembling the debug APK. To run them locally, use `gradle testDebugUnitTest`.

A successful build does not mean all proprietary controls have been verified on hardware. Confirm each supported command and read-back on the exact earbud firmware before relying on it.
