# Nord Buds Studio (native Android)
Kotlin + Jetpack Compose controller for OnePlus Nord Buds 3. Talks to the buds over Bluetooth RFCOMM using the HeyMelody protocol.

Tabs (same layout as HeyMelody): **Device**, **Earbud controls**, **About**.

- Device: battery (L / R / case), noise control, sound effect (EQ preset), BassWave switch + level, game mode.
- Earbud controls: single / double / triple tap, touch and hold (noise modes to cycle), long touch and hold (volume), per earbud. Every change is written to the buds and read back to confirm.
- About: device info, raw gesture table and protocol log (use Copy and send it if something does not match HeyMelody).

Also: **Find my earbuds** (Left / Right / Both), in ear / in case status, firmware version, devices connected to the buds, saved custom EQ (read only), and a **feature flag scanner** in Settings -> Diagnostics for locating switches such as ear detection and dual connection.

Every control talks to the buds. There is no demo or preview data. Nothing is shown unless the buds are connected.

## Build
1. Push everything to a GitHub repo (`main`). Keep `.github/workflows/build-apk.yml`.
2. Actions tab -> Build APK -> Run workflow. Download artifact `Budsy-apk`.
3. Pair the buds in phone Bluetooth settings, force-stop HeyMelody, open the app. It reconnects to the last buds by itself.

Protocol notes and command ids are at the top of `Buds.kt`.

## UI update (2026-10-18)
- Noise Control is requested to switch to Off when a new earbud control connection is established.
- Expanded the colour palette to Aurora, Ocean, Cosmic, Sunset, and Emerald.
- Enhanced theme swatches with animated scale/ring transitions and gradient colour chips.
- Increased the number of drifting aurora particles and slightly shortened the background animation cycle.

Note: device-level Noise Control switching depends on the earbud firmware accepting the proprietary command. Verify on the target Nord Buds 3 firmware; a source change alone is not proof of hardware behaviour.


## October 2026 reliability fixes (source updated; hardware/build verification pending)

- Touch & Hold writes now stay in a Saving state until the device-reported mask matches the requested mask; rejected, mismatched, and timed-out writes are surfaced instead of being presented as successful.
- ANC selection now has Saving/Saved/Failed feedback and requests a read-back before claiming confirmation. The connection flow still requests Noise Control Off after initial queries.
- Find My Buds now exposes Play again and Pause / Stop controls. The zero-target stop packet is explicitly marked experimental until verified on Nord Buds 3 firmware 110.110.100.
- RFCOMM reader threads use connection-generation tokens to prevent an old reader from dropping a newly reconnected session. The Overview separately warns when control is connected but A2DP/HFP audio is not routed to the earbuds.
- Hold selection no longer resets on every asynchronous device mask update while the user is editing; the initial confirmed mask is loaded until the user changes a selection.
- Tab changes now use animated fade/slide transitions. The GitHub Actions build runs unit tests before producing the debug APK and checks that the APK exists.
- Hardware command verification and Android APK compilation remain outstanding; do not treat the experimental Find-device stop payload as confirmed.

## UI redesign (2026-10-23): card tiles, glow and bounce
- New design system in `Components.kt`: `GlassPanel` cards, `FeatureTile` icon tiles, `BounceIcon`, `OptionCard`, ring-gauge `BatteryStat`, floating `BottomNav`.
- Every option now has an icon: noise modes, EQ presets, custom EQ slots, gesture tiles, gesture function pickers, hold options, themes, settings rows, diagnostics rows and buttons.
- Touch: icons squash and tilt with a spring bounce while pressed; tiles, buttons and switches bounce back with overshoot; the icon pops when it becomes active.
- Active state: gradient (blue to violet) border plus a pulsing outer glow on the tile, glow behind the icon chip, and a check/dot badge.
- Motion: staggered card entrance, animated tab transitions, drifting aurora background, pulsing rings and floating buds on the hero, pulsing touch spot on the earbud art, animated battery rings.
- Fixes: the tone that played every time an active tile appeared is gone (one tone per tap now); Touch & hold and Long hold no longer share the same icon; gesture tiles show a glow when a function is assigned; Experimental is a badge on the In-ear detection row instead of a stray label.
- New Settings -> Touch feedback: tap sounds and haptics can be switched off.
- Not compiled or run on a device in this environment: build with the GitHub Action and report any compile error.
