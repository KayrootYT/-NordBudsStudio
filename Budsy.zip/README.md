# Budsy Quantum Studio (clean rebuild)

Fresh Android Studio project, Java + XML, package `com.budsy.quantum`.

## What currently works in this project
- Android 12+ runtime permission request for nearby Bluetooth devices; legacy location permission for BLE scanning on Android 6–11.
- Real BLE scan for nearby advertising devices with device name/address and RSSI.
- Select a discovered device and initiate a real BLE GATT connection.
- Discover and display GATT services/characteristics and their standard properties.
- Connection/disconnection status and scan timeout/error feedback.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Important hardware limitation
This is a clean foundation, not a claim that every Nord Buds 3 proprietary feature is already implemented. The app deliberately does **not** send guessed writes to unknown GATT characteristics. ANC, transparency, BassWave/EQ DSP, earbud touch remapping, battery case telemetry and Find My Buds/ring require a verified command protocol for the exact OnePlus Nord Buds 3 (non-Pro) firmware. Generic BLE connection does not imply that these controls are available. The Find/ANC buttons clearly report this limitation rather than falsely pretending to work.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35) or run `gradle assembleDebug`. GitHub Actions builds on push/PR/manual dispatch.

## Test checklist on phone
1. Install the debug APK and grant Nearby devices permission.
2. Turn on Bluetooth and put the earbuds into pairing/discoverable mode.
3. Scan and select the earbuds from the results.
4. Connect and inspect GATT service UUIDs/characteristics.
5. Export the GATT output/logs for protocol analysis before implementing proprietary commands.
