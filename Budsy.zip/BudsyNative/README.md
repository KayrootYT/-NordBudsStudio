# Budsy Native Android

Kotlin + Jetpack Compose native Android project for OnePlus Nord Buds 3 / Nord Buds 3 Pro protocol research.

## Included
- Native device dashboard and navigation
- BLE scan/connect/disconnect and GATT service/characteristic inventory
- Notification subscription and incremental five-byte packet stream decoder
- Sound Master EQ UI, custom preset editor, manual EQ bands, BassWave control UI
- Game Mode, Dual Connection, touch controls, Find My Buds and firmware safety UI
- Source-derived protocol constants and payload helpers

## Important
The UI includes controls that are not yet connected to a fully verified device command. Protocol source findings do not guarantee compatibility with each Nord Buds model or firmware. Do not use the app as a firmware flasher. See `PROTOCOL_STATUS.md` and `PROTOCOL_TEST_VECTORS.md`.

## Build
Open this folder in Android Studio, use JDK 17 and install Android SDK Platform 35. Sync Gradle and run the `app` configuration on a physical Android device. This archive does not claim a successful build or physical-device test.
