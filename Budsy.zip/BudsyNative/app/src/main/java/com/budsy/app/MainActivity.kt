package com.budsy.app

import android.os.Bundle
import android.Manifest
import android.os.Build
import android.bluetooth.BluetoothDevice
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17191E)
private val Canvas = Color(0xFFF2F3F6)
private val Blue = Color(0xFF147CF3)
private val Muted = Color(0xFF777D87)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BudsyTheme { BudsyApp() } }
    }
}

@Composable private fun BudsyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary=Blue, background=Canvas, surface=Color.White, onSurface=Ink), content=content)
}
private enum class Page { DEVICE, CONTROLS, EQ, FIND, ABOUT, TUTORIAL }

@Composable private fun BudsyApp() {
    var page by remember { mutableStateOf(Page.DEVICE) }
    var side by remember { mutableStateOf("Left") }
    var connected by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Off") }
    var leftBattery by remember { mutableStateOf<Int?>(null) }
    var rightBattery by remember { mutableStateOf<Int?>(null) }
    var caseBattery by remember { mutableStateOf<Int?>(null) }
    var callDoubleTap by remember { mutableStateOf("Answer / End call") }
    var callLongHold by remember { mutableStateOf("Decline call") }
    var protocolNotice by remember { mutableStateOf("Bluetooth transport not connected") }
    var scanResults by remember { mutableStateOf(listOf<Triple<BluetoothDevice, String, Int>>()) }
    var gattSummary by remember { mutableStateOf("GATT services not discovered") }
    val context = LocalContext.current
    val bleClient = remember {
        com.budsy.app.ble.BudsyBleClient(
            context = context,
            onStatus = { status -> protocolNotice = status },
            onConnectionState = { isConnected -> connected = isConnected },
            onDevice = { device, name, rssi ->
                val old = scanResults
                scanResults = (old.filterNot { it.first.address == device.address } + Triple(device, name, rssi)).sortedByDescending { it.third }
            },
            onServices = { services ->
                gattSummary = if (services.isEmpty()) "GATT services not discovered" else services.joinToString(separator = "\n") { service ->
                    "${service.uuid} (${service.characteristics.size} characteristics)" +
                        service.characteristics.joinToString(separator = "", prefix = if(service.characteristics.isEmpty()) "" else ": ") {
                            "\n  ${it.uuid} [${propertyLabels(it.properties)}]"
                        }
                }
            }
        )
    }
    DisposableEffect(bleClient) { onDispose { bleClient.close() } }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allGranted = grants.values.all { it }
        if (allGranted) bleClient.startScan() else protocolNotice = "Bluetooth permissions denied; allow them to scan and connect."
    }
    fun scanOrRequestPermissions() {
        val required = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                       else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (bleClient.hasRequiredPermissions()) bleClient.startScan() else permissionLauncher.launch(required)
    }
    var preset by remember { mutableStateOf("Balanced (Default)") }
    var gameMode by remember { mutableStateOf(false) }
    var dualConnection by remember { mutableStateOf(false) }
    var bassWave by remember { mutableStateOf(false) }
    var bassLevel by remember { mutableFloatStateOf(0.45f) }
    var showGesture by remember { mutableStateOf<String?>(null) }
    var selectedGesture by remember { mutableStateOf("Double-tap") }
    var gestureChoices by remember { mutableStateOf(mapOf(
        "Single-tap" to "None", "Double-tap" to "Previous", "Triple-tap" to "Voice Assistant",
        "Touch and hold" to "Off", "Long touch and hold" to "Volume down"
    )) }
    var showPresetEditor by remember { mutableStateOf(false) }
    var newPresetName by remember { mutableStateOf("") }
    var customPresets by remember { mutableStateOf(listOf("My Custom EQ")) }
    var manualBands by remember { mutableStateOf(listOf(
        "60 Hz" to 0f, "150 Hz" to 0f, "400 Hz" to 0f, "1 kHz" to 0f,
        "2.4 kHz" to 0f, "6 kHz" to 0f, "12 kHz" to 0f
    )) }
    var findStatus by remember { mutableStateOf("Ready when a verified device command is available") }
    var firmwareDialog by remember { mutableStateOf(false) }
    val gestures = listOf("Single-tap", "Double-tap", "Triple-tap", "Touch and hold", "Long touch and hold")
    val choices = when(selectedGesture) {
        "Single-tap" -> listOf("None","Play/Pause")
        "Double-tap" -> listOf("None","Play/Pause","Previous","Next track","Voice Assistant","Game mode","Answer/End call")
        "Triple-tap" -> listOf("None","Previous","Next track","Voice Assistant","Game mode")
        "Touch and hold" -> listOf("Off","Noise cancellation","Transparency")
        else -> listOf("None","Volume up","Volume down","Decline call")
    }

    Scaffold(containerColor=Canvas, bottomBar={ NavigationBar(containerColor=Color.White) {
        NavigationBarItem(selected=page==Page.DEVICE,onClick={page=Page.DEVICE},icon={Icon(Icons.Default.Headphones,null)},label={Text("Device")})
        NavigationBarItem(selected=page==Page.CONTROLS,onClick={page=Page.CONTROLS},icon={Icon(Icons.Default.TouchApp,null)},label={Text("Controls")})
        NavigationBarItem(selected=page==Page.EQ,onClick={page=Page.EQ},icon={Icon(Icons.Default.GraphicEq,null)},label={Text("Sound EQ")})
        NavigationBarItem(selected=page==Page.ABOUT || page==Page.TUTORIAL,onClick={page=Page.ABOUT},icon={Icon(Icons.Default.Info,null)},label={Text("About")})
    }}) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp),
            contentPadding=PaddingValues(top=20.dp,bottom=24.dp)) {
            item { Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                Text("Budsy",fontSize=29.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                IconButton(onClick={page=Page.ABOUT}) { Icon(Icons.Default.MoreVert,"More") }
            } }
            when(page) {
                Page.DEVICE -> {
                    item { Column(Modifier.fillMaxWidth().padding(vertical=16.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("OnePlus Nord Buds 3",fontSize=25.sp,fontWeight=FontWeight.SemiBold)
                        Text(if(connected) "Connected · transport pending" else "Not connected",color=Muted)
                        Spacer(Modifier.height(12.dp))
                        Card(colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(20.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement=Arrangement.SpaceEvenly) {
                                BatteryItem("Left", leftBattery)
                                BatteryItem("Right", rightBattery)
                                BatteryItem("Case", caseBattery)
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Icon(Icons.Default.Headphones,null,Modifier.size(112.dp),tint=Color(0xFF464B55))
                        Text("L  —     R  —",fontWeight=FontWeight.Medium)
                    } }
                    item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        listOf("Noise cancellation","Off","Transparency").forEach { m ->
                            Card(Modifier.weight(1f).clickable { mode=m; protocolNotice="$m selected locally; earbuds command not sent" },colors=CardDefaults.cardColors(containerColor=if(mode==m) Blue else Color.White)) {
                                Column(Modifier.fillMaxWidth().padding(vertical=14.dp,horizontal=3.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                    Icon(if(m=="Noise cancellation") Icons.Default.NoiseControlOff else if(m=="Transparency") Icons.Default.Hearing else Icons.Default.DoNotDisturb,null,tint=if(mode==m) Color.White else Ink)
                                    Text(m,fontSize=11.sp,color=if(mode==m) Color.White else Muted)
                                }
                            }
                        }
                    } }
                    item { Section("Device management") {
                        SettingRow("Dual connection",if(dualConnection) "On · device command pending" else "Off",onClick={page=Page.ABOUT},trailing={Switch(dualConnection,{dualConnection=it})})
                        SettingRow("Game mode",if(gameMode) "On · device command pending" else "Off",trailing={Switch(gameMode,{gameMode=it})})
                    } }
                    item { Section("Audio effects") { SettingRow("Sound Master EQ",preset,onClick={page=Page.EQ}) } }
                    item { Section("Other features") {
                        SettingRow("Find my earbuds","Locate / play tone",onClick={page=Page.FIND})
                        SettingRow("Firmware update","Version and safe update workflow",onClick={firmwareDialog=true})
                        SettingRow("Device information & tutorial","Help and protocol status",onClick={page=Page.TUTORIAL})
                    } }
                    item { Button(onClick={
                        if(connected) { bleClient.disconnect() }
                        else scanOrRequestPermissions()
                    },modifier=Modifier.fillMaxWidth()) { Text(if(connected) "Disconnect" else "Scan for earbuds") } }
                    item { Text(protocolNotice,fontSize=12.sp,color=Muted) }
                    if(scanResults.isNotEmpty()) item { Section("Nearby BLE devices · tap to connect") {
                        scanResults.forEach { (device, name, rssi) ->
                            SettingRow(name, "${device.address} · RSSI $rssi dBm", onClick={ bleClient.connect(device) })
                        }
                    } }
                    item { Section("GATT service inventory") {
                        Text(gattSummary, fontSize=11.sp, color=Muted)
                    } }
                    item { Text("Battery readings show — until a verified BLE battery response is implemented.",fontSize=12.sp,color=Muted) }
                }
                Page.CONTROLS -> {
                    item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { listOf("Left","Right").forEach { FilterChip(selected=side==it,onClick={side=it},label={Text(it)}) } } }
                    item { Text("$side earbud",fontSize=22.sp,fontWeight=FontWeight.SemiBold) }
                    item { Section("When not on a call") { gestures.forEach { g ->
                        SettingRow("$g ${side.lowercase()} earbud",gestureChoices[g] ?: "None",onClick={selectedGesture=g;showGesture=g})
                    } } }
                    item { Section("When on a call") {
                        SettingRow("Double-tap $side earbud",callDoubleTap,onClick={selectedGesture="Double-tap";showGesture="Double-tap"})
                        SettingRow("Long touch and hold $side earbud",callLongHold,onClick={selectedGesture="Long touch and hold";showGesture="Long touch and hold"})
                    } }
                    item { Section("Volume and noise-mode actions") {
                        SettingRow("Volume actions","Volume up / Volume down")
                        SettingRow("Noise-mode actions","Noise cancellation / Off / Transparency")
                    } }
                    item { Text("Gesture selections are stored in the UI; writing them to the earbuds requires verified command mapping.",fontSize=12.sp,color=Muted) }
                }
                Page.EQ -> {
                    item { Text("Recommended",color=Muted) }
                    item { Section("Presets") { listOf("Balanced (Default)","Clear Vocals","Bass").forEach { RadioRow(it,preset==it){preset=it} } } }
                    item { Section("BassWave™") {
                        SettingRow("BassWave","Dynamic bass enhancement",trailing={Switch(bassWave,{bassWave=it})})
                        if(bassWave) { Text("Intensity · ${(bassLevel*100).toInt()}%",color=Muted); Slider(value=bassLevel,onValueChange={bassLevel=it}) }
                    } }
                    item { Section("Custom presets") {
                        customPresets.forEach { name -> SettingRow(name,if(preset==name) "Selected" else "Tap to select",onClick={preset=name}) }
                        OutlinedButton(onClick={newPresetName="";showPresetEditor=true},modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add,null); Spacer(Modifier.width(8.dp)); Text("Save current EQ as preset")
                        }
                        if(preset in customPresets) TextButton(onClick={newPresetName=preset;showPresetEditor=true}) { Text("Rename / edit selected preset") }
                    } }
                    item { Section("Manual frequency-band EQ") {
                        Text("Adjust bands from −6 to +6 dB. These illustrative bands are stored locally; hardware application awaits verified EqInfo mapping.",fontSize=13.sp,color=Muted)
                        manualBands.forEachIndexed { index, band ->
                            Column(Modifier.padding(vertical=4.dp)) {
                                Row(verticalAlignment=Alignment.CenterVertically) { Text(band.first,Modifier.weight(1f)); Text("${band.second.toInt()} dB",color=Muted) }
                                Slider(value=band.second,onValueChange={v->manualBands=manualBands.toMutableList().also{it[index]=band.first to v}},valueRange=-6f..6f,steps=11)
                            }
                        }
                        Button(onClick={newPresetName=if(preset in customPresets) preset else "";showPresetEditor=true},modifier=Modifier.fillMaxWidth()) { Text("Save / edit custom preset") }
                    } }
                    item { Text("EQ payload encoder is included in the protocol module, but band frequencies, EqInfo limits and transport framing must be verified before sending.",fontSize=12.sp,color=Muted) }
                }
                Page.FIND -> {
                    item { Card(colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.fillMaxWidth().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(Icons.Default.LocationSearching,null,Modifier.size(64.dp),tint=Blue)
                        Text("Find my earbuds",fontSize=23.sp,fontWeight=FontWeight.SemiBold)
                        Text("Play a tone only if the connected model supports the verified command.",color=Muted)
                        Spacer(Modifier.height(12.dp)); Text(findStatus,fontSize=12.sp,color=Muted)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick={findStatus="Request recorded locally. No sound command was sent because its packet mapping is not verified."},enabled=connected,modifier=Modifier.fillMaxWidth()) { Text("Request play sound") }
                        OutlinedButton(onClick={findStatus="Live location is not supported by the verified source evidence."},modifier=Modifier.fillMaxWidth()) { Text("Check location support") }
                    } } }
                }
                Page.ABOUT -> {
                    item { Section("Device information") {
                        SettingRow("Target model","Nord Buds 3 / Nord Buds 3 Pro")
                        SettingRow("Connection","BLE transport pending")
                        SettingRow("Firmware version","Not read yet")
                        SettingRow("Dual connection",if(dualConnection) "Enabled locally; device write pending" else "Off",trailing={Switch(dualConnection,{dualConnection=it})})
                        SettingRow("Game mode",if(gameMode) "Enabled locally; device write pending" else "Off")
                        SettingRow("Firmware update","Safe workflow only",onClick={firmwareDialog=true})
                        SettingRow("Custom EQ presets",customPresets.size.toString())
                        SettingRow("Controls tutorial","Open guide",onClick={page=Page.TUTORIAL})
                    } }
                    item { Text("Verified from supplied source: scan-filter constants and EQ payload structure. Model IDs, GATT packet framing, ANC, Find mode, dual connection, Game mode and OTA command support remain unverified.",fontSize=13.sp,color=Muted) }
                }
                Page.TUTORIAL -> {
                    item { Text("Earbud controls guide",fontSize=24.sp,fontWeight=FontWeight.SemiBold) }
                    item { Section("1. Pairing") { Text("Pair the earbuds in Android Bluetooth settings, then return to Budsy. Direct BLE scan/connect is not integrated yet.",Modifier.padding(vertical=10.dp),color=Muted) } }
                    item { Section("2. Touch controls") { Text("Choose Left or Right, tap a gesture row and select an action. Current selections are UI state until a verified device command is implemented.",Modifier.padding(vertical=10.dp),color=Muted) } }
                    item { Section("3. Sound Master EQ") { Text("Select a recommended preset, adjust BassWave and the seven manual frequency sliders, then save a named custom preset.",Modifier.padding(vertical=10.dp),color=Muted) } }
                    item { Section("4. Find My Earbuds") { Text("The app can show request status. Actual tone playback requires the exact Find-mode command and response to be verified for your model.",Modifier.padding(vertical=10.dp),color=Muted) } }
                    item { Section("5. Firmware safety") { Text("Do not flash firmware without a confirmed model-specific image, signature/compatibility checks, OTA packet sequence and recovery method.",Modifier.padding(vertical=10.dp),color=Muted) } }
                    item { Button(onClick={page=Page.DEVICE},modifier=Modifier.fillMaxWidth()) { Text("Finish tutorial") } }
                }
            }
        }
    }

    if(showGesture!=null) AlertDialog(
        onDismissRequest={showGesture=null},title={Text("$selectedGesture $side earbud")},
        text={Column { choices.distinct().forEach { c -> Row(Modifier.fillMaxWidth().clickable { gestureChoices=gestureChoices+(selectedGesture to c)
            if(selectedGesture=="Double-tap") callDoubleTap=c
            if(selectedGesture=="Long touch and hold") callLongHold=c
            showGesture=null }.padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(c,Modifier.weight(1f)); RadioButton(selected=(if(selectedGesture=="Double-tap") callDoubleTap else if(selectedGesture=="Long touch and hold") callLongHold else gestureChoices[selectedGesture])==c,onClick={
                gestureChoices=gestureChoices+(selectedGesture to c)
                if(selectedGesture=="Double-tap") callDoubleTap=c
                if(selectedGesture=="Long touch and hold") callLongHold=c
                showGesture=null
            })
        } } }},
        confirmButton={},dismissButton={TextButton(onClick={showGesture=null}) { Text("Cancel") }}
    )
    if(showPresetEditor) AlertDialog(
        onDismissRequest={showPresetEditor=false},title={Text(if(newPresetName in customPresets) "Edit custom preset" else "Save custom preset")},
        text={Column {
            OutlinedTextField(value=newPresetName,onValueChange={newPresetName=it},label={Text("Preset name")},singleLine=true)
            Spacer(Modifier.height(8.dp))
            Text("Bands: "+manualBands.joinToString { "${it.first} ${it.second.toInt()} dB" },fontSize=12.sp,color=Muted)
        }},
        confirmButton={TextButton(onClick={
            val name=newPresetName.trim()
            if(name.isNotEmpty()) { if(name !in customPresets) customPresets=customPresets+name; preset=name }
            showPresetEditor=false
        }) { Text("Save") }},
        dismissButton={TextButton(onClick={showPresetEditor=false}) { Text("Cancel") }}
    )
    if(firmwareDialog) AlertDialog(
        onDismissRequest={firmwareDialog=false},title={Text("Firmware update safety")},
        text={Text("Firmware version reading and OTA transfer are not yet verified. Budsy will not download or flash firmware until the exact model, trusted image, packet sequence and recovery procedure are confirmed.")},
        confirmButton={TextButton(onClick={firmwareDialog=false}) { Text("OK") }}
    )
}

private fun propertyLabels(properties: Int): String = buildList {
    if (properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_READ != 0) add("READ")
    if (properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("WRITE")
    if (properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("WRITE_NO_RESPONSE")
    if (properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("NOTIFY")
    if (properties and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("INDICATE")
}.joinToString()

@Composable private fun BatteryItem(label: String, level: Int?) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Default.BatteryFull, null, tint=if(level == null) Muted else Blue)
        Text(label, fontSize=12.sp, color=Muted)
        Text(level?.let { "$it%" } ?: "—", fontSize=17.sp, fontWeight=FontWeight.SemiBold)
    }
}
@Composable private fun Section(title:String, content:@Composable ColumnScope.()->Unit) {
    Column { Text(title,color=Muted,fontSize=14.sp,modifier=Modifier.padding(start=8.dp,bottom=8.dp))
        Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=5.dp),content=content)
        }
    }
}
@Composable private fun SettingRow(title:String,summary:String?=null,onClick:(()->Unit)?=null,trailing:@Composable (() -> Unit)?=null) {
    Row(Modifier.fillMaxWidth().then(if(onClick!=null) Modifier.clickable(onClick=onClick) else Modifier).padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title,fontSize=16.sp,fontWeight=FontWeight.Medium); if(summary!=null) Text(summary,fontSize=13.sp,color=Muted) }
        if(trailing!=null) trailing() else if(onClick!=null) Icon(Icons.Default.ChevronRight,null,tint=Muted)
    }
}
@Composable private fun RadioRow(label:String,selected:Boolean,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
        Text(label,Modifier.weight(1f),fontSize=16.sp); RadioButton(selected=selected,onClick=onClick)
    }
}
