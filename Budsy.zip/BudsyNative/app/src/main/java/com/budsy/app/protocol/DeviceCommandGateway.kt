package com.budsy.app.protocol

/**
 * Feature-command registry for Budsy.
 *
 * IMPORTANT: this intentionally contains no guessed ANC/Game/Find/Touch/Firmware/
 * call command IDs. Add a FeatureCommand only after confirming its ID, payload,
 * acknowledgement, and compatibility for the exact earbuds model.
 */
class DeviceCommandGateway(
    private val sendPacket: (ByteArray) -> Boolean,
) {
    enum class Feature {
        BATTERY_STATUS,
        NOISE_CONTROL,
        GAME_MODE,
        EQUALIZER,
        TOUCH_CONTROLS,
        FIND_MY_BUDS,
        FIRMWARE_UPDATE,
        CALL_CONTROLS,
    }

    data class FeatureCommand(
        val commandId: Int,
        val buildPayload: () -> ByteArray,
        val modelIds: Set<String>,
        val requiresAcknowledgement: Boolean = true,
    )

    private val verifiedCommands = mutableMapOf<Pair<String, Feature>, FeatureCommand>()
    private var sequence = 0

    fun registerVerifiedCommand(
        modelId: String,
        feature: Feature,
        command: FeatureCommand,
    ) {
        require(modelId.isNotBlank())
        require(command.commandId in 0..0xFFFF)
        require(command.modelIds.contains(modelId)) {
            "Command is not explicitly approved for model $modelId"
        }
        verifiedCommands[modelId to feature] = command
    }

    fun isSupported(modelId: String, feature: Feature): Boolean =
        verifiedCommands.containsKey(modelId to feature)

    fun execute(modelId: String, feature: Feature): Result {
        val command = verifiedCommands[modelId to feature]
            ?: return Result.Unsupported(
                "$feature is not enabled: command ID/payload has not been verified for $modelId."
            )
        val payload = try {
            command.buildPayload()
        } catch (e: Exception) {
            return Result.Failed("Could not build $feature payload: ${e.message ?: "invalid payload"}")
        }
        val packet = HeyMelodyProtocol.encodePacket(command.commandId, sequence, payload)
        sequence = (sequence + 1) and 0xFF
        return if (sendPacket(packet)) {
            Result.Sent(command.commandId, command.requiresAcknowledgement)
        } else {
            Result.Failed("BLE write could not be queued")
        }
    }

    sealed class Result {
        data class Unsupported(val reason: String) : Result()
        data class Sent(val commandId: Int, val acknowledgementRequired: Boolean) : Result()
        data class Failed(val reason: String) : Result()
    }
}
