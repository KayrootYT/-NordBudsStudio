package com.budsy.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.budsy.app.protocol.HeyMelodyProtocol
import java.util.UUID

/**
 * Conservative BLE foundation. It scans with source-derived HeyMelody filters,
 * connects to a user-selected device, and inventories discovered GATT services.
 * It deliberately sends no writes until characteristic UUIDs and packet framing
 * are verified from the supplied protocol source.
 */
class BudsyBleClient(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onDevice: (BluetoothDevice, String, Int) -> Unit,
    private val onServices: (List<GattServiceInfo>) -> Unit,
    private val onConnectionState: (Boolean) -> Unit = {}
) {
    data class GattServiceInfo(val uuid: UUID, val characteristics: List<GattCharacteristicInfo>)
    data class GattCharacteristicInfo(val uuid: UUID, val properties: Int)

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val main = Handler(Looper.getMainLooper())
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private val subscribedCharacteristics = mutableSetOf<UUID>()
    private val rxDecoder = HeyMelodyProtocol.StreamDecoder()

    fun hasRequiredPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 31) {
            listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return required.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        val a = adapter
        if (a == null) { onStatus("This device has no Bluetooth adapter"); return }
        if (!a.isEnabled) { onStatus("Turn on Bluetooth first"); return }
        val scanner = a.bluetoothLeScanner ?: run { onStatus("BLE scanner unavailable"); return }
        stopScan()
        try {
            scanner.startScan(HeyMelodyProtocol.scanFilters(), null, scanCallback)
            scanning = true
            onStatus("Scanning for HeyMelody-compatible earbuds…")
            main.postDelayed({
                if (scanning) {
                    stopScan()
                    onStatus("Scan finished")
                }
            }, 12_000L)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not start BLE scan: ${e.message ?: "unknown error"}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        if (!scanning) return
        try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name } catch (_: SecurityException) { null } ?: result.scanRecord?.deviceName ?: "Unknown BLE device"
            main.post { onDevice(d, name, result.rssi) }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            main.post { onStatus("BLE scan failed (code $errorCode)") }
        }
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        stopScan()
        closeGatt()
        onStatus("Connecting to selected device…")
        try {
            gatt = if (Build.VERSION.SDK_INT >= 23)
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(context, false, gattCallback)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not connect: ${e.message ?: "unknown error"}")
        }
    }


    /**
     * Sends a caller-supplied, source-verified protocol packet to the configured
     * write characteristic. Feature command IDs are intentionally not guessed.
     * The caller must only pass packets verified for the exact earbud model.
     */
    @SuppressLint("MissingPermission")
    fun writeVerifiedPacket(packet: ByteArray, writeCharacteristicUuid: UUID = HeyMelodyProtocol.defaultWriteCharacteristicUuid): Boolean {
        if (!hasRequiredPermissions()) {
            onStatus("Bluetooth permission required")
            return false
        }
        val activeGatt = gatt ?: run {
            onStatus("Not connected to a BLE device")
            return false
        }
        val characteristic = activeGatt.services
            .asSequence()
            .flatMap { it.characteristics.asSequence() }
            .firstOrNull { it.uuid == writeCharacteristicUuid }
        if (characteristic == null) {
            onStatus("Verified write characteristic $writeCharacteristicUuid not found")
            return false
        }
        val canWrite = (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
            (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        if (!canWrite) {
            onStatus("Characteristic does not advertise write support")
            return false
        }
        return try {
            val writeType = if ((characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) {
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            } else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            val result = if (Build.VERSION.SDK_INT >= 33) {
                activeGatt.writeCharacteristic(characteristic, packet, writeType) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                run {
                    characteristic.writeType = writeType
                    characteristic.value = packet
                    activeGatt.writeCharacteristic(characteristic)
                }
            }
            onStatus(if (result) "Packet queued to BLE characteristic; device acknowledgement not yet verified" else "BLE write request failed")
            result
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied during write")
            false
        } catch (e: RuntimeException) {
            onStatus("BLE write failed: ${e.message ?: "unknown error"}")
            false
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        try { gatt?.disconnect() } catch (_: Exception) { }
    }

    @SuppressLint("MissingPermission")
    fun close() {
        stopScan()
        closeGatt()
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try { gatt?.disconnect() } catch (_: Exception) { }
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
        subscribedCharacteristics.clear()
        rxDecoder.reset()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                when {
                    status != BluetoothGatt.GATT_SUCCESS -> {
                        onConnectionState(false)
                        onStatus("GATT connection error: $status")
                        try { g.close() } catch (_: Exception) { }
                        if (gatt === g) gatt = null
                    }
                    newState == BluetoothProfile.STATE_CONNECTED -> {
                        onConnectionState(true)
                        onStatus("Connected; discovering GATT services…")
                        try {
                            if (!g.discoverServices()) onStatus("GATT service discovery could not start")
                        } catch (_: SecurityException) { onStatus("Bluetooth permission denied") }
                    }
                    newState == BluetoothProfile.STATE_DISCONNECTED -> {
                        onConnectionState(false)
                        onServices(emptyList())
                        onStatus("Disconnected from earbuds")
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                main.post { onStatus("GATT discovery failed: $status") }
                return
            }
            val inventory = g.services.map { service ->
                GattServiceInfo(service.uuid, service.characteristics.map { c ->
                    GattCharacteristicInfo(c.uuid, c.properties)
                })
            }
            main.post {
                onServices(inventory)
                val notifyCharacteristic = g.services.asSequence()
                    .flatMap { it.characteristics.asSequence() }
                    .firstOrNull { it.uuid == HeyMelodyProtocol.defaultNotifyCharacteristicUuid && (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 }
                if (notifyCharacteristic != null) {
                    enableNotifications(g, notifyCharacteristic)
                } else {
                    onStatus("GATT services discovered; expected notify characteristic not found. Device/model support is unconfirmed.")
                }
            }
        }

        @SuppressLint("MissingPermission")
        private fun enableNotifications(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            try {
                if (!g.setCharacteristicNotification(characteristic, true)) {
                    onStatus("Could not enable local GATT notifications")
                    return
                }
                val cccd = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                if (cccd == null) {
                    onStatus("Notify characteristic has no CCCD descriptor; receive stream unavailable")
                    return
                }
                val value = if ((characteristic.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 &&
                    (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0) {
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                } else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                val result = if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(cccd, value)
                } else {
                    @Suppress("DEPRECATION")
                    run { cccd.value = value; if (g.writeDescriptor(cccd)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE }
                }
                if (result == BluetoothGatt.GATT_SUCCESS) {
                    subscribedCharacteristics.add(characteristic.uuid)
                    onStatus("GATT notifications requested. Incoming bytes will be logged; no device commands are sent.")
                } else onStatus("Could not write notification descriptor (status $result)")
            } catch (e: SecurityException) {
                onStatus("Bluetooth permission denied while enabling notifications")
            } catch (e: RuntimeException) {
                onStatus("Notification setup failed: ${e.message ?: "unknown error"}")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            main.post { onStatus(if (status == BluetoothGatt.GATT_SUCCESS) "Notifications enabled; waiting for device data" else "Notification descriptor failed: $status") }
        }

        @Deprecated("Deprecated by Android API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val value = characteristic.value?.copyOf() ?: return
            handleIncoming(characteristic.uuid, value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleIncoming(characteristic.uuid, value.copyOf())
        }

        private fun handleIncoming(uuid: UUID, bytes: ByteArray) {
            val decoded = rxDecoder.append(bytes)
            val raw = HeyMelodyProtocol.toHex(bytes)
            val packetSummary = decoded.packets.joinToString(separator = " | ") { packet ->
                "cmd=0x${packet.commandId.toString(16).uppercase().padStart(4, '0')} seq=${packet.sequence} len=${packet.declaredPayloadLength} payload=${HeyMelodyProtocol.toHex(packet.payload)}"
            }
            val summary = buildString {
                append("RX [$uuid] bytes=${bytes.size} raw=$raw")
                if (packetSummary.isNotEmpty()) append(" | PACKET: $packetSummary")
                if (decoded.bufferedBytes > 0) append(" | buffered=${decoded.bufferedBytes}B awaiting frame")
                if (decoded.discardedBytes > 0) append(" | resync discarded=${decoded.discardedBytes}B")
                if (decoded.packets.isEmpty() && decoded.bufferedBytes == 0) append(" | no complete packet")
            }
            main.post { onStatus(summary) }
        }
    }
}
