# BLE stream decoder test vectors

Header: `command LE16 | sequence U8 | payload length LE16 | payload`.

1. Complete frame `18 04 07 03 00 AA BB CC` => command `0x0418`, sequence 7, payload `AA BB CC`.
2. Split frame: chunks `18 04 07 03` then `00 AA BB CC` => one complete packet after second chunk.
3. Two frames in one chunk: `18 04 07 01 00 AA 19 04 08 00 00` => commands `0x0418` and `0x0419`.
4. Declared payload over 4096 bytes is treated as implausible and byte-wise resynchronization is attempted.
5. Closing GATT resets pending bytes so sessions cannot contaminate each other.

These are parser test vectors, not claims about exact commands emitted by a Nord Buds model.
