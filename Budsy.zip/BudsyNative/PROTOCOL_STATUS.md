# Budsy protocol implementation status

This document distinguishes source findings from device-tested behavior.

## Source findings in supplied `jadx-sources.zip`

- BLE discovery filters: manufacturer IDs `1839 (0x072F)`, `1946 (0x079A)`, service UUID `00009801-0000-1000-8000-00805f9b34fb`.
- Custom EQ set: command `1048 (0x0418)`, payload builder based on `HeadsetCoreService.M0(String, EqInfo, int)`.
- EQ preset: command `1030 (0x0406)`, one-byte `equalizerModeType` from `HeadsetCoreService.N0(...)`.
- Find mode: command `1024 (0x0400)`, payload byte `1`/`0` in `HeadsetCoreService.O0(...)`.
- BassWave set: command `1051 (0x041B)`, `HeadsetCoreService.F0(i10, i11, i12, address)` sends a three-byte payload `[i10, i11, i12]`.
- BassWave response: response command `1288 (0x0508)` is parsed as three values: minimum, maximum, current value. `BassEngineInfo` exposes these fields.
- Multi-connection info response: response command `1287 (0x0507)` appears in the request-command response handler. Dual-connection set operation is routed through `HeadsetCoreService.s0(...)` and command `1065 (0x0429)` per the prior source inspection; exact operation/address payload and model compatibility still require end-to-end validation.
- Game Mode UI entry points: `GameSetViewModel.setGameModeMainEnable(...)` and `setGameSoundEnable(...)`. The exact outbound command mapping is not yet independently verified here, so Budsy intentionally does not send a guessed Game Mode command.

## Important transport limitation

The five-byte packet header codec and BLE GATT client are present. The standalone BLE write path, fragmentation, sequencing, acknowledgements, and exact target-model GATT characteristics have not been proven end-to-end against Nord Buds 3 or Nord Buds 3 Pro. Do not treat a queued BLE write as proof the earbuds applied a setting.

## Current app status

- Native Kotlin + Jetpack Compose UI, BLE scan/connect/disconnect, service inventory, notifications and receive stream decoder are included.
- Sound Master EQ, presets, BassWave slider, touch-control UI, Game Mode, Dual Connection and Find My Buds screens are present.
- Several feature controls are UI-only until the complete source path and model-specific packet transport are validated. Manual EQ currently has payload encoding support, but the app does not yet have a complete verified read-modify-write flow for device-specific EQ bands.
- No firmware update is performed. OTA should not be enabled until a trusted firmware image, model/version check, chunk protocol, acknowledgements and recovery path are confirmed.
- No APK build or physical-earbud test is claimed in this package.

## Build

Open `BudsyNative/` in Android Studio with JDK 17 and Android SDK Platform 35 installed. Let Gradle sync, then run `app` on an Android 8.0+ device. Bluetooth scan/connect permissions are requested at runtime. Physical device testing is required before relying on feature controls.
