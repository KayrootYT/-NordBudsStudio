# Start the Budsy MECE wave with OpenCode

Run these commands from the repository root after installing OpenCode and connecting your own provider/account:

```bash
opencode --version
opencode run --dir . "$(cat .mece/cells/UI/TASK.md)"
opencode run --dir . "$(cat .mece/cells/BLE/TASK.md)"
opencode run --dir . "$(cat .mece/cells/FEATURES/TASK.md)"
opencode run --dir . "$(cat .mece/cells/QA/TASK.md)"
```

Use a separate session for each cell. Run them sequentially initially to make failures easier to inspect. Do not run multiple cells that edit the same files concurrently. Review all four reports before parent integration. After integrating, run the actual Gradle build and device tests; never mark proprietary controls as functional based only on UI.

OpenCode executes on the user's machine and uses the user's own provider/account. This ZIP does not remotely start OpenCode or authenticate on the user's behalf.
