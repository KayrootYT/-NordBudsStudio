# Play Integrity and Google Play licensing setup

Budsy includes the Play Integrity client SDK and a small token-acquisition helper. This is **not yet a complete production enforcement system**.

## Configure Play Integrity
1. Publish/register the app in Google Play Console using application ID `com.nordbuds.studio`.
2. Link the correct Google Cloud project in Play Console and enable Play Integrity API for that project.
3. Put the numeric Cloud project number in the local/CI Gradle property `PLAY_CLOUD_PROJECT_NUMBER` (do not commit credentials or service-account keys).
4. The app can request an integrity token with `PlayIntegrityClient.requestToken(context, nonce, callback)`. Use a fresh nonce/challenge from your backend for each protected operation.
5. Send the token and server-issued challenge to your trusted backend over HTTPS. The backend must decode/verify the token using Google's server-side API and validate package name, app recognition, licensing verdict, device integrity and request binding according to your policy.
6. Add rate limiting, replay protection, timeout handling, monitoring and a documented policy for unsupported devices / Play Store unavailable.

## Licensing
- For Google Play-distributed builds, use the **Play Integrity licensing verdict** (`accountDetails.appLicensingVerdict`) on the trusted backend. Do not trust a client-side boolean or a hard-coded response.
- Configure license testers and internal testing tracks in Play Console.
- If Budsy is distributed outside Google Play, decide and document a separate legitimate distribution policy; Play licensing verdicts may not be available.
- Do not embed a Google service-account key, private API key, or backend secret in the APK.

## Release gate
Until a backend validates the integrity token and applies the licensing verdict, the feature is only token acquisition scaffolding. Do not label the app as protected or block legitimate users based solely on the client. The app must remain usable while this setup is unconfigured.
