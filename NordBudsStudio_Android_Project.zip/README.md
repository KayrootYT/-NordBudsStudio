# Nord Buds Studio

Native Android companion-app starter for OnePlus Nord Buds 3, using Java + XML, designed for Android 16 (API 35).

## What's included
- Apple Liquid Glass-inspired dark UI with translucent-style cards and entrance animations.
- Android 12+ Nearby Devices permission handling.
- Real BLE scan, user-confirmed connection, GATT service discovery, and a read attempt for the standard Bluetooth Battery Service (`0x180F` / `0x2A19`).
- UI labels separate verified standard BLE behavior from demo-only audio presets.
- GitHub Actions workflow at `.github/workflows/android-apk.yml`.

## Important hardware limitation
This project does **not** claim that proprietary Nord Buds 3 controls work. ANC/transparency, proprietary EQ, touch remapping, case battery and separate left/right battery may use a vendor-specific protocol that is not established here. The standard Bluetooth Battery Service, if exposed, may report only one battery endpoint. Audio preset buttons are explicitly demo-only and do not send device commands.

The scan filters device names containing `OnePlus` or `Nord Buds 3`; some earbuds may not advertise a name, may use a different advertised name, or may not expose a BLE GATT connection in the same way. If the earbuds are not found, put them in pairing mode and check Android Bluetooth settings.

## Build locally
Requirements: Android Studio with JDK 17 and Android SDK Platform 35.

1. Open this folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Build with Android Studio, or install Gradle 8.11.1 and run `gradle assembleDebug`.
4. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK on GitHub
1. Upload/push the complete project to a GitHub repository.
2. Open **Actions → Build Nord Buds Studio APK → Run workflow**, or push to `main`/`master`.
3. The workflow installs Gradle 8.11.1 and the Android SDK packages, then builds the APK.
4. Download the `NordBudsStudio-debug-apk` artifact from the completed workflow run.

## Next step for genuine proprietary controls
Capture and document the supported GATT services/characteristics and vendor command protocol for this exact earbud model. Implement a dedicated protocol adapter only after UUIDs, payloads, permissions, and safe command behavior are verified on real hardware. Keep the demo layer separate from that adapter.
